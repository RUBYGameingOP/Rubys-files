.class public interface abstract Lp/Ng;
.super Ljava/lang/Object;
.source "SourceFile"
