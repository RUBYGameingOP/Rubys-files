.class public final Lp/P4;
.super Lp/za;
.source "SourceFile"


# instance fields
.field public final q:Landroid/graphics/RectF;


# direct methods
.method public constructor <init>(Lp/P4;)V
    .locals 0

    .line 3
    invoke-direct {p0, p1}, Lp/za;-><init>(Lp/za;)V

    .line 4
    iget-object p1, p1, Lp/P4;->q:Landroid/graphics/RectF;

    iput-object p1, p0, Lp/P4;->q:Landroid/graphics/RectF;

    return-void
.end method

.method public constructor <init>(Lp/be;Landroid/graphics/RectF;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lp/za;-><init>(Lp/be;)V

    .line 2
    iput-object p2, p0, Lp/P4;->q:Landroid/graphics/RectF;

    return-void
.end method


# virtual methods
.method public final newDrawable()Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    new-instance v0, Lp/Q4;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Lp/Aa;-><init>(Lp/za;)V

    .line 4
    .line 5
    .line 6
    iput-object p0, v0, Lp/Q4;->x:Lp/P4;

    .line 7
    .line 8
    invoke-virtual {v0}, Lp/Aa;->invalidateSelf()V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method
