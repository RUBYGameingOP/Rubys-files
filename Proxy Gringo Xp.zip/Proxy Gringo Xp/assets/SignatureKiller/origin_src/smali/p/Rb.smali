.class public final Lp/Rb;
.super Landroid/widget/LinearLayout;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:Ljava/lang/String;

.field public final c:Landroid/widget/TextView;

.field public final synthetic d:Lp/Ub;


# direct methods
.method public constructor <init>(Lp/Ub;Ljava/lang/String;Ljava/lang/String;II)V
    .locals 5

    .line 1
    iput-object p1, p0, Lp/Rb;->d:Lp/Ub;

    .line 2
    .line 3
    iget-object v0, p1, Lp/Ub;->a:Lgringoxp/game/b;

    .line 4
    .line 5
    invoke-direct {p0, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 6
    .line 7
    .line 8
    iput p5, p0, Lp/Rb;->a:I

    .line 9
    .line 10
    iput-object p2, p0, Lp/Rb;->b:Ljava/lang/String;

    .line 11
    .line 12
    const/16 v0, 0x10

    .line 13
    .line 14
    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 15
    .line 16
    .line 17
    const/high16 v0, 0x40c00000    # 6.0f

    .line 18
    .line 19
    invoke-virtual {p1, v0}, Lp/Ub;->d(F)I

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    const/high16 v2, 0x40000000    # 2.0f

    .line 24
    .line 25
    invoke-virtual {p1, v2}, Lp/Ub;->d(F)I

    .line 26
    .line 27
    .line 28
    move-result v3

    .line 29
    invoke-virtual {p1, v0}, Lp/Ub;->d(F)I

    .line 30
    .line 31
    .line 32
    move-result v4

    .line 33
    invoke-virtual {p1, v2}, Lp/Ub;->d(F)I

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    invoke-virtual {p0, v1, v3, v4, v2}, Landroid/view/View;->setPadding(IIII)V

    .line 38
    .line 39
    .line 40
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 41
    .line 42
    const/high16 v2, 0x420c0000    # 35.0f

    .line 43
    .line 44
    invoke-virtual {p1, v2}, Lp/Ub;->d(F)I

    .line 45
    .line 46
    .line 47
    move-result v2

    .line 48
    const/4 v3, -0x1

    .line 49
    invoke-direct {v1, v3, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 50
    .line 51
    .line 52
    const/high16 v2, 0x40800000    # 4.0f

    .line 53
    .line 54
    invoke-virtual {p1, v2}, Lp/Ub;->d(F)I

    .line 55
    .line 56
    .line 57
    move-result v2

    .line 58
    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 59
    .line 60
    invoke-virtual {p0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 61
    .line 62
    .line 63
    const/high16 v1, 0x41500000    # 13.0f

    .line 64
    .line 65
    const v2, -0x3f3f40

    .line 66
    .line 67
    .line 68
    invoke-static {p1, p3, v1, v2}, Lp/Ub;->c(Lp/Ub;Ljava/lang/String;FI)Landroid/widget/TextView;

    .line 69
    .line 70
    .line 71
    move-result-object p3

    .line 72
    iget-object v1, p1, Lp/Ub;->k:Landroid/graphics/Typeface;

    .line 73
    .line 74
    invoke-virtual {p3, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 75
    .line 76
    .line 77
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 78
    .line 79
    const/high16 v4, 0x41b80000    # 23.0f

    .line 80
    .line 81
    invoke-virtual {p1, v4}, Lp/Ub;->d(F)I

    .line 82
    .line 83
    .line 84
    move-result v4

    .line 85
    invoke-direct {v2, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {p0, p3, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 89
    .line 90
    .line 91
    const/high16 p3, 0x41280000    # 10.5f

    .line 92
    .line 93
    invoke-static {p1, p2, p3, v3}, Lp/Ub;->c(Lp/Ub;Ljava/lang/String;FI)Landroid/widget/TextView;

    .line 94
    .line 95
    .line 96
    move-result-object p2

    .line 97
    const p3, 0x800013

    .line 98
    .line 99
    .line 100
    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setGravity(I)V

    .line 101
    .line 102
    .line 103
    invoke-virtual {p1, v0}, Lp/Ub;->d(F)I

    .line 104
    .line 105
    .line 106
    move-result p3

    .line 107
    const/4 v0, 0x0

    .line 108
    invoke-virtual {p2, p3, v0, v0, v0}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 109
    .line 110
    .line 111
    new-instance p3, Landroid/widget/LinearLayout$LayoutParams;

    .line 112
    .line 113
    const/high16 v2, 0x3f800000    # 1.0f

    .line 114
    .line 115
    invoke-direct {p3, v0, v3, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {p0, p2, p3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 119
    .line 120
    .line 121
    const-string p2, ""

    .line 122
    .line 123
    const/high16 p3, 0x41300000    # 11.0f

    .line 124
    .line 125
    invoke-static {p1, p2, p3, v3}, Lp/Ub;->c(Lp/Ub;Ljava/lang/String;FI)Landroid/widget/TextView;

    .line 126
    .line 127
    .line 128
    move-result-object p2

    .line 129
    iput-object p2, p0, Lp/Rb;->c:Landroid/widget/TextView;

    .line 130
    .line 131
    invoke-virtual {p2, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 132
    .line 133
    .line 134
    new-instance p3, Landroid/widget/LinearLayout$LayoutParams;

    .line 135
    .line 136
    const/high16 v0, 0x41a80000    # 21.0f

    .line 137
    .line 138
    invoke-virtual {p1, v0}, Lp/Ub;->d(F)I

    .line 139
    .line 140
    .line 141
    move-result v1

    .line 142
    invoke-virtual {p1, v0}, Lp/Ub;->d(F)I

    .line 143
    .line 144
    .line 145
    move-result p1

    .line 146
    invoke-direct {p3, v1, p1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 147
    .line 148
    .line 149
    invoke-virtual {p0, p2, p3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 150
    .line 151
    .line 152
    new-instance p1, Lp/Qb;

    .line 153
    .line 154
    invoke-direct {p1, p0, p4, p5}, Lp/Qb;-><init>(Lp/Rb;II)V

    .line 155
    .line 156
    .line 157
    invoke-virtual {p0, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 158
    .line 159
    .line 160
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 6

    .line 1
    iget-object v0, p0, Lp/Rb;->d:Lp/Ub;

    .line 2
    .line 3
    iget v1, v0, Lp/Ub;->h:I

    .line 4
    .line 5
    iget v2, p0, Lp/Rb;->a:I

    .line 6
    .line 7
    and-int/2addr v1, v2

    .line 8
    if-eqz v1, :cond_0

    .line 9
    .line 10
    const/4 v1, 0x1

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const/4 v1, 0x0

    .line 13
    :goto_0
    if-eqz v1, :cond_1

    .line 14
    .line 15
    const v2, -0xcccfd0

    .line 16
    .line 17
    .line 18
    goto :goto_1

    .line 19
    :cond_1
    const v2, -0xdfdfe0

    .line 20
    .line 21
    .line 22
    :goto_1
    iget v3, v0, Lp/Ub;->j:I

    .line 23
    .line 24
    if-eqz v1, :cond_2

    .line 25
    .line 26
    move v4, v3

    .line 27
    goto :goto_2

    .line 28
    :cond_2
    const v4, -0xc5c5c6

    .line 29
    .line 30
    .line 31
    :goto_2
    const/4 v5, 0x7

    .line 32
    invoke-static {v0, v2, v4, v5}, Lp/Ub;->b(Lp/Ub;III)Landroid/graphics/drawable/GradientDrawable;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    invoke-virtual {p0, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 37
    .line 38
    .line 39
    iget-object v2, p0, Lp/Rb;->c:Landroid/widget/TextView;

    .line 40
    .line 41
    if-eqz v1, :cond_3

    .line 42
    .line 43
    const-string v4, "\uf00c"

    .line 44
    .line 45
    goto :goto_3

    .line 46
    :cond_3
    const-string v4, ""

    .line 47
    .line 48
    :goto_3
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 49
    .line 50
    .line 51
    if-eqz v1, :cond_4

    .line 52
    .line 53
    move v4, v3

    .line 54
    goto :goto_4

    .line 55
    :cond_4
    const v4, -0xd6d6d7

    .line 56
    .line 57
    .line 58
    :goto_4
    if-eqz v1, :cond_5

    .line 59
    .line 60
    goto :goto_5

    .line 61
    :cond_5
    const v3, -0x959596

    .line 62
    .line 63
    .line 64
    :goto_5
    const/4 v5, 0x5

    .line 65
    invoke-static {v0, v4, v3, v5}, Lp/Ub;->b(Lp/Ub;III)Landroid/graphics/drawable/GradientDrawable;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    invoke-virtual {v2, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 70
    .line 71
    .line 72
    new-instance v0, Ljava/lang/StringBuilder;

    .line 73
    .line 74
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 75
    .line 76
    .line 77
    iget-object v2, p0, Lp/Rb;->b:Ljava/lang/String;

    .line 78
    .line 79
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 80
    .line 81
    .line 82
    if-eqz v1, :cond_6

    .line 83
    .line 84
    const-string v2, ", marcado"

    .line 85
    .line 86
    goto :goto_6

    .line 87
    :cond_6
    const-string v2, ", desmarcado"

    .line 88
    .line 89
    :goto_6
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 90
    .line 91
    .line 92
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    invoke-virtual {p0, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {p0, v1}, Landroid/view/View;->setSelected(Z)V

    .line 100
    .line 101
    .line 102
    return-void
.end method

.method public final onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 3

    .line 1
    invoke-super {p0, p1}, Landroid/view/View;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 2
    .line 3
    .line 4
    const-string v0, "android.widget.CheckBox"

    .line 5
    .line 6
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClassName(Ljava/lang/CharSequence;)V

    .line 7
    .line 8
    .line 9
    const/4 v0, 0x1

    .line 10
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setCheckable(Z)V

    .line 11
    .line 12
    .line 13
    iget-object v1, p0, Lp/Rb;->d:Lp/Ub;

    .line 14
    .line 15
    iget v1, v1, Lp/Ub;->h:I

    .line 16
    .line 17
    iget v2, p0, Lp/Rb;->a:I

    .line 18
    .line 19
    and-int/2addr v1, v2

    .line 20
    if-eqz v1, :cond_0

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const/4 v0, 0x0

    .line 24
    :goto_0
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setChecked(Z)V

    .line 25
    .line 26
    .line 27
    return-void
.end method
