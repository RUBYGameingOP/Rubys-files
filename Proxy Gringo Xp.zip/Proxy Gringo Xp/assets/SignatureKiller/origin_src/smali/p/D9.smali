.class public final Lp/D9;
.super Lp/E9;
.source "SourceFile"


# virtual methods
.method public final e()Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    return v0
.end method
