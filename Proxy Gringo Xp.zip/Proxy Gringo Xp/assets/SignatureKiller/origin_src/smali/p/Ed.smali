.class public final synthetic Lp/Ed;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;II)V
    .locals 0

    .line 1
    iput p3, p0, Lp/Ed;->a:I

    iput-object p1, p0, Lp/Ed;->c:Ljava/lang/Object;

    iput p2, p0, Lp/Ed;->b:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 1
    iget v0, p0, Lp/Ed;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lp/Ed;->c:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lakn/main/UpdateActivity;

    .line 9
    .line 10
    iget-object v0, v0, Lakn/main/UpdateActivity;->a:Landroid/widget/ProgressBar;

    .line 11
    .line 12
    iget v1, p0, Lp/Ed;->b:I

    .line 13
    .line 14
    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_0
    iget-object v0, p0, Lp/Ed;->c:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v0, Lcom/google/android/material/sidesheet/SideSheetBehavior;

    .line 21
    .line 22
    iget-object v1, v0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->p:Ljava/lang/ref/WeakReference;

    .line 23
    .line 24
    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    check-cast v1, Landroid/view/View;

    .line 29
    .line 30
    if-eqz v1, :cond_0

    .line 31
    .line 32
    const/4 v2, 0x0

    .line 33
    iget v3, p0, Lp/Ed;->b:I

    .line 34
    .line 35
    invoke-virtual {v0, v1, v3, v2}, Lcom/google/android/material/sidesheet/SideSheetBehavior;->t(Landroid/view/View;IZ)V

    .line 36
    .line 37
    .line 38
    :cond_0
    return-void

    .line 39
    :pswitch_1
    iget-object v0, p0, Lp/Ed;->c:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast v0, Lp/mc;

    .line 42
    .line 43
    iget v1, p0, Lp/Ed;->b:I

    .line 44
    .line 45
    invoke-virtual {v0, v1}, Lp/mc;->p(I)V

    .line 46
    .line 47
    .line 48
    return-void

    .line 49
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
