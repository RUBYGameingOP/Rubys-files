.class public interface abstract Lp/Jb;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Lp/y4;)Lp/y4;
.end method
