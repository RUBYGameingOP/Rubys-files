.class public final Lp/Pb;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:I

.field public final d:I

.field public final e:I

.field public final f:Landroid/widget/LinearLayout;

.field public final g:Landroid/widget/TextView;

.field public final h:Landroid/widget/TextView;

.field public final i:Landroid/widget/TextView;

.field public final j:Lp/Rb;

.field public final k:Lp/Rb;

.field public final l:Lp/Rb;

.field public final m:Lp/Rb;

.field public final n:Landroid/widget/LinearLayout;

.field public final o:Landroid/widget/LinearLayout;

.field public final p:Landroid/widget/TextView;

.field public final q:Landroid/widget/TextView;

.field public final r:Landroid/widget/TextView;

.field public final s:Lp/Sb;

.field public final t:Landroid/view/WindowManager$LayoutParams;

.field public u:Z

.field public v:Ljava/lang/String;

.field public w:Z

.field public x:I

.field public final synthetic y:Lp/Ub;


# direct methods
.method public constructor <init>(Lp/Ub;Ljava/lang/String;I)V
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v7, p1

    .line 4
    .line 5
    move-object/from16 v1, p2

    .line 6
    .line 7
    move/from16 v2, p3

    .line 8
    .line 9
    invoke-direct/range {p0 .. p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    iput-object v7, v0, Lp/Pb;->y:Lp/Ub;

    .line 13
    .line 14
    const/4 v3, -0x1

    .line 15
    iput v3, v0, Lp/Pb;->x:I

    .line 16
    .line 17
    iput-object v1, v0, Lp/Pb;->a:Ljava/lang/String;

    .line 18
    .line 19
    iput v2, v0, Lp/Pb;->c:I

    .line 20
    .line 21
    const/16 v4, 0x59

    .line 22
    .line 23
    const/4 v8, 0x1

    .line 24
    if-ne v2, v4, :cond_0

    .line 25
    .line 26
    move v9, v8

    .line 27
    goto :goto_0

    .line 28
    :cond_0
    const/4 v9, 0x0

    .line 29
    :goto_0
    const/16 v4, 0x5e

    .line 30
    .line 31
    if-ne v2, v4, :cond_1

    .line 32
    .line 33
    move v10, v8

    .line 34
    goto :goto_1

    .line 35
    :cond_1
    const/4 v10, 0x0

    .line 36
    :goto_1
    if-eqz v9, :cond_2

    .line 37
    .line 38
    const-string v4, "ghost"

    .line 39
    .line 40
    :goto_2
    move-object v11, v4

    .line 41
    goto :goto_3

    .line 42
    :cond_2
    if-eqz v10, :cond_3

    .line 43
    .line 44
    const-string v4, "teleport"

    .line 45
    .line 46
    goto :goto_2

    .line 47
    :cond_3
    const-string v4, "freeze"

    .line 48
    .line 49
    goto :goto_2

    .line 50
    :goto_3
    iput-object v11, v0, Lp/Pb;->b:Ljava/lang/String;

    .line 51
    .line 52
    if-eqz v9, :cond_4

    .line 53
    .line 54
    move v4, v8

    .line 55
    goto :goto_4

    .line 56
    :cond_4
    if-eqz v10, :cond_5

    .line 57
    .line 58
    const/16 v4, 0x20

    .line 59
    .line 60
    goto :goto_4

    .line 61
    :cond_5
    const/4 v4, 0x2

    .line 62
    :goto_4
    iput v4, v0, Lp/Pb;->d:I

    .line 63
    .line 64
    if-eqz v9, :cond_6

    .line 65
    .line 66
    const-string v4, "#BAA7FF"

    .line 67
    .line 68
    goto :goto_5

    .line 69
    :cond_6
    if-eqz v10, :cond_7

    .line 70
    .line 71
    const-string v4, "#FFCB79"

    .line 72
    .line 73
    goto :goto_5

    .line 74
    :cond_7
    const-string v4, "#79DEFF"

    .line 75
    .line 76
    :goto_5
    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 77
    .line 78
    .line 79
    move-result v4

    .line 80
    iput v4, v0, Lp/Pb;->e:I

    .line 81
    .line 82
    new-instance v12, Landroid/widget/LinearLayout;

    .line 83
    .line 84
    iget-object v6, v7, Lp/Ub;->a:Lgringoxp/game/b;

    .line 85
    .line 86
    invoke-direct {v12, v6}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 87
    .line 88
    .line 89
    iput-object v12, v0, Lp/Pb;->f:Landroid/widget/LinearLayout;

    .line 90
    .line 91
    invoke-virtual {v12, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 92
    .line 93
    .line 94
    const/high16 v6, 0x41000000    # 8.0f

    .line 95
    .line 96
    invoke-virtual {v7, v6}, Lp/Ub;->d(F)I

    .line 97
    .line 98
    .line 99
    move-result v13

    .line 100
    const/high16 v14, 0x40a00000    # 5.0f

    .line 101
    .line 102
    invoke-virtual {v7, v14}, Lp/Ub;->d(F)I

    .line 103
    .line 104
    .line 105
    move-result v15

    .line 106
    invoke-virtual {v7, v6}, Lp/Ub;->d(F)I

    .line 107
    .line 108
    .line 109
    move-result v14

    .line 110
    const/high16 v8, 0x40e00000    # 7.0f

    .line 111
    .line 112
    invoke-virtual {v7, v8}, Lp/Ub;->d(F)I

    .line 113
    .line 114
    .line 115
    move-result v6

    .line 116
    invoke-virtual {v12, v13, v15, v14, v6}, Landroid/view/View;->setPadding(IIII)V

    .line 117
    .line 118
    .line 119
    const/16 v6, 0xa

    .line 120
    .line 121
    const v13, -0xfdadadb

    .line 122
    .line 123
    .line 124
    const v14, -0xbababb

    .line 125
    .line 126
    .line 127
    invoke-static {v7, v13, v14, v6}, Lp/Ub;->b(Lp/Ub;III)Landroid/graphics/drawable/GradientDrawable;

    .line 128
    .line 129
    .line 130
    move-result-object v6

    .line 131
    invoke-virtual {v12, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 132
    .line 133
    .line 134
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    .line 135
    .line 136
    const/4 v13, -0x2

    .line 137
    invoke-direct {v6, v3, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 138
    .line 139
    .line 140
    const/high16 v13, 0x40c00000    # 6.0f

    .line 141
    .line 142
    invoke-virtual {v7, v13}, Lp/Ub;->d(F)I

    .line 143
    .line 144
    .line 145
    move-result v14

    .line 146
    const/high16 v15, 0x40800000    # 4.0f

    .line 147
    .line 148
    invoke-virtual {v7, v15}, Lp/Ub;->d(F)I

    .line 149
    .line 150
    .line 151
    move-result v5

    .line 152
    invoke-virtual {v7, v13}, Lp/Ub;->d(F)I

    .line 153
    .line 154
    .line 155
    move-result v8

    .line 156
    invoke-virtual {v7, v15}, Lp/Ub;->d(F)I

    .line 157
    .line 158
    .line 159
    move-result v15

    .line 160
    invoke-virtual {v6, v14, v5, v8, v15}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 161
    .line 162
    .line 163
    invoke-virtual {v12, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 164
    .line 165
    .line 166
    new-instance v5, Landroid/widget/LinearLayout;

    .line 167
    .line 168
    iget-object v8, v7, Lp/Ub;->a:Lgringoxp/game/b;

    .line 169
    .line 170
    invoke-direct {v5, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 171
    .line 172
    .line 173
    const/16 v6, 0x10

    .line 174
    .line 175
    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 176
    .line 177
    .line 178
    new-instance v14, Lp/Tb;

    .line 179
    .line 180
    invoke-direct {v14, v7, v2, v4}, Lp/Tb;-><init>(Lp/Ub;II)V

    .line 181
    .line 182
    .line 183
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    .line 184
    .line 185
    const/high16 v15, 0x41c00000    # 24.0f

    .line 186
    .line 187
    invoke-virtual {v7, v15}, Lp/Ub;->d(F)I

    .line 188
    .line 189
    .line 190
    move-result v13

    .line 191
    invoke-virtual {v7, v15}, Lp/Ub;->d(F)I

    .line 192
    .line 193
    .line 194
    move-result v15

    .line 195
    invoke-direct {v4, v13, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 196
    .line 197
    .line 198
    invoke-virtual {v5, v14, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 199
    .line 200
    .line 201
    const/high16 v4, 0x41400000    # 12.0f

    .line 202
    .line 203
    invoke-static {v7, v1, v4, v3}, Lp/Ub;->c(Lp/Ub;Ljava/lang/String;FI)Landroid/widget/TextView;

    .line 204
    .line 205
    .line 206
    move-result-object v4

    .line 207
    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setGravity(I)V

    .line 208
    .line 209
    .line 210
    const/high16 v6, 0x40e00000    # 7.0f

    .line 211
    .line 212
    invoke-virtual {v7, v6}, Lp/Ub;->d(F)I

    .line 213
    .line 214
    .line 215
    move-result v6

    .line 216
    const/4 v13, 0x0

    .line 217
    invoke-virtual {v4, v6, v13, v13, v13}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 218
    .line 219
    .line 220
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    .line 221
    .line 222
    const/high16 v14, 0x42080000    # 34.0f

    .line 223
    .line 224
    invoke-virtual {v7, v14}, Lp/Ub;->d(F)I

    .line 225
    .line 226
    .line 227
    move-result v14

    .line 228
    const/high16 v15, 0x3f800000    # 1.0f

    .line 229
    .line 230
    invoke-direct {v6, v13, v14, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 231
    .line 232
    .line 233
    invoke-virtual {v5, v4, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 234
    .line 235
    .line 236
    const-string v4, "OFF"

    .line 237
    .line 238
    const/high16 v13, 0x41100000    # 9.0f

    .line 239
    .line 240
    invoke-static {v7, v4, v13, v3}, Lp/Ub;->c(Lp/Ub;Ljava/lang/String;FI)Landroid/widget/TextView;

    .line 241
    .line 242
    .line 243
    move-result-object v4

    .line 244
    iput-object v4, v0, Lp/Pb;->g:Landroid/widget/TextView;

    .line 245
    .line 246
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    .line 247
    .line 248
    const/high16 v14, 0x42440000    # 49.0f

    .line 249
    .line 250
    invoke-virtual {v7, v14}, Lp/Ub;->d(F)I

    .line 251
    .line 252
    .line 253
    move-result v14

    .line 254
    const/high16 v13, 0x41b00000    # 22.0f

    .line 255
    .line 256
    invoke-virtual {v7, v13}, Lp/Ub;->d(F)I

    .line 257
    .line 258
    .line 259
    move-result v13

    .line 260
    invoke-direct {v6, v14, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 261
    .line 262
    .line 263
    invoke-virtual {v5, v4, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 264
    .line 265
    .line 266
    new-instance v4, Ljava/lang/StringBuilder;

    .line 267
    .line 268
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 269
    .line 270
    .line 271
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 272
    .line 273
    .line 274
    const-string v1, ": toque para ligar ou desligar"

    .line 275
    .line 276
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 277
    .line 278
    .line 279
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 280
    .line 281
    .line 282
    move-result-object v1

    .line 283
    invoke-virtual {v5, v1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 284
    .line 285
    .line 286
    new-instance v1, Lp/Nb;

    .line 287
    .line 288
    const/4 v4, 0x1

    .line 289
    invoke-direct {v1, v0, v4}, Lp/Nb;-><init>(Lp/Pb;I)V

    .line 290
    .line 291
    .line 292
    invoke-virtual {v5, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 293
    .line 294
    .line 295
    invoke-virtual {v12, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 296
    .line 297
    .line 298
    new-instance v1, Landroid/widget/LinearLayout;

    .line 299
    .line 300
    invoke-direct {v1, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 301
    .line 302
    .line 303
    const/high16 v13, 0x40000000    # 2.0f

    .line 304
    .line 305
    invoke-virtual {v7, v13}, Lp/Ub;->d(F)I

    .line 306
    .line 307
    .line 308
    move-result v4

    .line 309
    const/high16 v14, 0x40400000    # 3.0f

    .line 310
    .line 311
    invoke-virtual {v7, v14}, Lp/Ub;->d(F)I

    .line 312
    .line 313
    .line 314
    move-result v5

    .line 315
    invoke-virtual {v7, v13}, Lp/Ub;->d(F)I

    .line 316
    .line 317
    .line 318
    move-result v6

    .line 319
    invoke-virtual {v7, v14}, Lp/Ub;->d(F)I

    .line 320
    .line 321
    .line 322
    move-result v13

    .line 323
    invoke-virtual {v1, v4, v5, v6, v13}, Landroid/view/View;->setPadding(IIII)V

    .line 324
    .line 325
    .line 326
    const v4, -0xe6e6e7

    .line 327
    .line 328
    .line 329
    const v5, -0xc5c5c6

    .line 330
    .line 331
    .line 332
    const/16 v6, 0x8

    .line 333
    .line 334
    invoke-static {v7, v4, v5, v6}, Lp/Ub;->b(Lp/Ub;III)Landroid/graphics/drawable/GradientDrawable;

    .line 335
    .line 336
    .line 337
    move-result-object v13

    .line 338
    invoke-virtual {v1, v13}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 339
    .line 340
    .line 341
    const-string v13, "Menu"

    .line 342
    .line 343
    const/high16 v4, 0x41200000    # 10.0f

    .line 344
    .line 345
    invoke-static {v7, v13, v4, v3}, Lp/Ub;->c(Lp/Ub;Ljava/lang/String;FI)Landroid/widget/TextView;

    .line 346
    .line 347
    .line 348
    move-result-object v13

    .line 349
    iput-object v13, v0, Lp/Pb;->h:Landroid/widget/TextView;

    .line 350
    .line 351
    const-string v5, "Flutuante"

    .line 352
    .line 353
    invoke-static {v7, v5, v4, v3}, Lp/Ub;->c(Lp/Ub;Ljava/lang/String;FI)Landroid/widget/TextView;

    .line 354
    .line 355
    .line 356
    move-result-object v5

    .line 357
    iput-object v5, v0, Lp/Pb;->i:Landroid/widget/TextView;

    .line 358
    .line 359
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    .line 360
    .line 361
    const/high16 v4, 0x41e80000    # 29.0f

    .line 362
    .line 363
    invoke-virtual {v7, v4}, Lp/Ub;->d(F)I

    .line 364
    .line 365
    .line 366
    move-result v6

    .line 367
    const/4 v14, 0x0

    .line 368
    invoke-direct {v3, v14, v6, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 369
    .line 370
    .line 371
    invoke-virtual {v1, v13, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 372
    .line 373
    .line 374
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    .line 375
    .line 376
    invoke-virtual {v7, v4}, Lp/Ub;->d(F)I

    .line 377
    .line 378
    .line 379
    move-result v6

    .line 380
    invoke-direct {v3, v14, v6, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 381
    .line 382
    .line 383
    invoke-virtual {v1, v5, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 384
    .line 385
    .line 386
    new-instance v3, Lp/Nb;

    .line 387
    .line 388
    const/4 v6, 0x2

    .line 389
    invoke-direct {v3, v0, v6}, Lp/Nb;-><init>(Lp/Pb;I)V

    .line 390
    .line 391
    .line 392
    invoke-virtual {v13, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 393
    .line 394
    .line 395
    new-instance v3, Lp/Nb;

    .line 396
    .line 397
    const/4 v6, 0x3

    .line 398
    invoke-direct {v3, v0, v6}, Lp/Nb;-><init>(Lp/Pb;I)V

    .line 399
    .line 400
    .line 401
    invoke-virtual {v5, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 402
    .line 403
    .line 404
    invoke-virtual {v12, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 405
    .line 406
    .line 407
    const/16 v1, 0x55

    .line 408
    .line 409
    if-ne v2, v1, :cond_8

    .line 410
    .line 411
    const-string v1, "COMO O FREEZE FUNCIONA"

    .line 412
    .line 413
    const v2, -0x585859

    .line 414
    .line 415
    .line 416
    const/high16 v3, 0x41000000    # 8.0f

    .line 417
    .line 418
    invoke-static {v7, v1, v3, v2}, Lp/Ub;->c(Lp/Ub;Ljava/lang/String;FI)Landroid/widget/TextView;

    .line 419
    .line 420
    .line 421
    move-result-object v1

    .line 422
    const v2, 0x800013

    .line 423
    .line 424
    .line 425
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setGravity(I)V

    .line 426
    .line 427
    .line 428
    const/high16 v2, 0x40400000    # 3.0f

    .line 429
    .line 430
    invoke-virtual {v7, v2}, Lp/Ub;->d(F)I

    .line 431
    .line 432
    .line 433
    move-result v5

    .line 434
    invoke-virtual {v7, v3}, Lp/Ub;->d(F)I

    .line 435
    .line 436
    .line 437
    move-result v3

    .line 438
    invoke-virtual {v7, v2}, Lp/Ub;->d(F)I

    .line 439
    .line 440
    .line 441
    move-result v6

    .line 442
    const/4 v2, 0x0

    .line 443
    invoke-virtual {v1, v5, v3, v2, v6}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 444
    .line 445
    .line 446
    invoke-virtual {v12, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 447
    .line 448
    .line 449
    new-instance v1, Landroid/widget/LinearLayout;

    .line 450
    .line 451
    invoke-direct {v1, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 452
    .line 453
    .line 454
    const/high16 v2, 0x40000000    # 2.0f

    .line 455
    .line 456
    invoke-virtual {v7, v2}, Lp/Ub;->d(F)I

    .line 457
    .line 458
    .line 459
    move-result v3

    .line 460
    invoke-virtual {v7, v2}, Lp/Ub;->d(F)I

    .line 461
    .line 462
    .line 463
    move-result v5

    .line 464
    invoke-virtual {v7, v2}, Lp/Ub;->d(F)I

    .line 465
    .line 466
    .line 467
    move-result v6

    .line 468
    invoke-virtual {v7, v2}, Lp/Ub;->d(F)I

    .line 469
    .line 470
    .line 471
    move-result v13

    .line 472
    invoke-virtual {v1, v3, v5, v6, v13}, Landroid/view/View;->setPadding(IIII)V

    .line 473
    .line 474
    .line 475
    const v2, -0xe6e6e7

    .line 476
    .line 477
    .line 478
    const v3, -0xc5c5c6

    .line 479
    .line 480
    .line 481
    const/16 v5, 0x8

    .line 482
    .line 483
    invoke-static {v7, v2, v3, v5}, Lp/Ub;->b(Lp/Ub;III)Landroid/graphics/drawable/GradientDrawable;

    .line 484
    .line 485
    .line 486
    move-result-object v2

    .line 487
    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 488
    .line 489
    .line 490
    const-string v2, "Manual"

    .line 491
    .line 492
    const/4 v3, -0x1

    .line 493
    const/high16 v5, 0x41200000    # 10.0f

    .line 494
    .line 495
    invoke-static {v7, v2, v5, v3}, Lp/Ub;->c(Lp/Ub;Ljava/lang/String;FI)Landroid/widget/TextView;

    .line 496
    .line 497
    .line 498
    move-result-object v2

    .line 499
    iput-object v2, v0, Lp/Pb;->p:Landroid/widget/TextView;

    .line 500
    .line 501
    const-string v6, "Autom\u00e1tico"

    .line 502
    .line 503
    invoke-static {v7, v6, v5, v3}, Lp/Ub;->c(Lp/Ub;Ljava/lang/String;FI)Landroid/widget/TextView;

    .line 504
    .line 505
    .line 506
    move-result-object v3

    .line 507
    iput-object v3, v0, Lp/Pb;->q:Landroid/widget/TextView;

    .line 508
    .line 509
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    .line 510
    .line 511
    invoke-virtual {v7, v4}, Lp/Ub;->d(F)I

    .line 512
    .line 513
    .line 514
    move-result v6

    .line 515
    const/4 v13, 0x0

    .line 516
    invoke-direct {v5, v13, v6, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 517
    .line 518
    .line 519
    invoke-virtual {v1, v2, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 520
    .line 521
    .line 522
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    .line 523
    .line 524
    invoke-virtual {v7, v4}, Lp/Ub;->d(F)I

    .line 525
    .line 526
    .line 527
    move-result v4

    .line 528
    invoke-direct {v5, v13, v4, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 529
    .line 530
    .line 531
    invoke-virtual {v1, v3, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 532
    .line 533
    .line 534
    new-instance v4, Lp/Nb;

    .line 535
    .line 536
    const/4 v5, 0x4

    .line 537
    invoke-direct {v4, v0, v5}, Lp/Nb;-><init>(Lp/Pb;I)V

    .line 538
    .line 539
    .line 540
    invoke-virtual {v2, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 541
    .line 542
    .line 543
    new-instance v2, Lp/Nb;

    .line 544
    .line 545
    const/4 v4, 0x5

    .line 546
    invoke-direct {v2, v0, v4}, Lp/Nb;-><init>(Lp/Pb;I)V

    .line 547
    .line 548
    .line 549
    invoke-virtual {v3, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 550
    .line 551
    .line 552
    invoke-virtual {v12, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 553
    .line 554
    .line 555
    new-instance v13, Landroid/widget/LinearLayout;

    .line 556
    .line 557
    invoke-direct {v13, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 558
    .line 559
    .line 560
    iput-object v13, v0, Lp/Pb;->n:Landroid/widget/LinearLayout;

    .line 561
    .line 562
    const/4 v1, 0x1

    .line 563
    invoke-virtual {v13, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 564
    .line 565
    .line 566
    new-instance v14, Lp/Rb;

    .line 567
    .line 568
    const-string v3, "Ao atirar"

    .line 569
    .line 570
    const-string v4, "\uf05b"

    .line 571
    .line 572
    const/16 v5, 0x5c

    .line 573
    .line 574
    const/4 v6, 0x4

    .line 575
    move-object v1, v14

    .line 576
    move-object/from16 v2, p1

    .line 577
    .line 578
    invoke-direct/range {v1 .. v6}, Lp/Rb;-><init>(Lp/Ub;Ljava/lang/String;Ljava/lang/String;II)V

    .line 579
    .line 580
    .line 581
    iput-object v14, v0, Lp/Pb;->j:Lp/Rb;

    .line 582
    .line 583
    new-instance v15, Lp/Rb;

    .line 584
    .line 585
    const-string v3, "Ao mirar"

    .line 586
    .line 587
    const-string v4, "\uf140"

    .line 588
    .line 589
    const/16 v5, 0x5d

    .line 590
    .line 591
    const/16 v6, 0x8

    .line 592
    .line 593
    move-object v1, v15

    .line 594
    invoke-direct/range {v1 .. v6}, Lp/Rb;-><init>(Lp/Ub;Ljava/lang/String;Ljava/lang/String;II)V

    .line 595
    .line 596
    .line 597
    iput-object v15, v0, Lp/Pb;->k:Lp/Rb;

    .line 598
    .line 599
    invoke-virtual {v13, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 600
    .line 601
    .line 602
    invoke-virtual {v13, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 603
    .line 604
    .line 605
    invoke-virtual {v12, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 606
    .line 607
    .line 608
    new-instance v13, Landroid/widget/LinearLayout;

    .line 609
    .line 610
    invoke-direct {v13, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 611
    .line 612
    .line 613
    iput-object v13, v0, Lp/Pb;->o:Landroid/widget/LinearLayout;

    .line 614
    .line 615
    const/4 v1, 0x1

    .line 616
    invoke-virtual {v13, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 617
    .line 618
    .line 619
    new-instance v8, Lp/Rb;

    .line 620
    .line 621
    const-string v3, "Soltar 1,3 s ap\u00f3s parar de atirar"

    .line 622
    .line 623
    const-string v4, "\uf017"

    .line 624
    .line 625
    const/16 v5, 0x75

    .line 626
    .line 627
    const/16 v6, 0x100

    .line 628
    .line 629
    move-object v1, v8

    .line 630
    move-object/from16 v2, p1

    .line 631
    .line 632
    invoke-direct/range {v1 .. v6}, Lp/Rb;-><init>(Lp/Ub;Ljava/lang/String;Ljava/lang/String;II)V

    .line 633
    .line 634
    .line 635
    iput-object v8, v0, Lp/Pb;->l:Lp/Rb;

    .line 636
    .line 637
    invoke-virtual {v13, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 638
    .line 639
    .line 640
    new-instance v8, Lp/Rb;

    .line 641
    .line 642
    const-string v3, "Soltar 3 s ap\u00f3s ativar"

    .line 643
    .line 644
    const-string v4, "\uf2f2"

    .line 645
    .line 646
    const/16 v5, 0x7a

    .line 647
    .line 648
    const/16 v6, 0x200

    .line 649
    .line 650
    move-object v1, v8

    .line 651
    invoke-direct/range {v1 .. v6}, Lp/Rb;-><init>(Lp/Ub;Ljava/lang/String;Ljava/lang/String;II)V

    .line 652
    .line 653
    .line 654
    iput-object v8, v0, Lp/Pb;->m:Lp/Rb;

    .line 655
    .line 656
    invoke-virtual {v13, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 657
    .line 658
    .line 659
    invoke-virtual {v12, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 660
    .line 661
    .line 662
    const-string v1, ""

    .line 663
    .line 664
    const v2, -0x49494a

    .line 665
    .line 666
    .line 667
    const/high16 v3, 0x41100000    # 9.0f

    .line 668
    .line 669
    invoke-static {v7, v1, v3, v2}, Lp/Ub;->c(Lp/Ub;Ljava/lang/String;FI)Landroid/widget/TextView;

    .line 670
    .line 671
    .line 672
    move-result-object v1

    .line 673
    iput-object v1, v0, Lp/Pb;->r:Landroid/widget/TextView;

    .line 674
    .line 675
    const v2, 0x800003

    .line 676
    .line 677
    .line 678
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setGravity(I)V

    .line 679
    .line 680
    .line 681
    const/high16 v2, 0x40a00000    # 5.0f

    .line 682
    .line 683
    invoke-virtual {v7, v2}, Lp/Ub;->d(F)I

    .line 684
    .line 685
    .line 686
    move-result v2

    .line 687
    const/high16 v3, 0x40c00000    # 6.0f

    .line 688
    .line 689
    invoke-virtual {v7, v3}, Lp/Ub;->d(F)I

    .line 690
    .line 691
    .line 692
    move-result v3

    .line 693
    const/high16 v4, 0x40400000    # 3.0f

    .line 694
    .line 695
    invoke-virtual {v7, v4}, Lp/Ub;->d(F)I

    .line 696
    .line 697
    .line 698
    move-result v4

    .line 699
    const/high16 v5, 0x40000000    # 2.0f

    .line 700
    .line 701
    invoke-virtual {v7, v5}, Lp/Ub;->d(F)I

    .line 702
    .line 703
    .line 704
    move-result v5

    .line 705
    invoke-virtual {v1, v2, v3, v4, v5}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 706
    .line 707
    .line 708
    invoke-virtual {v12, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 709
    .line 710
    .line 711
    :cond_8
    new-instance v1, Landroid/view/WindowManager$LayoutParams;

    .line 712
    .line 713
    const/high16 v2, 0x42800000    # 64.0f

    .line 714
    .line 715
    invoke-virtual {v7, v2}, Lp/Ub;->d(F)I

    .line 716
    .line 717
    .line 718
    move-result v14

    .line 719
    const/high16 v2, 0x429c0000    # 78.0f

    .line 720
    .line 721
    invoke-virtual {v7, v2}, Lp/Ub;->d(F)I

    .line 722
    .line 723
    .line 724
    move-result v15

    .line 725
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 726
    .line 727
    const/16 v3, 0x1a

    .line 728
    .line 729
    if-lt v2, v3, :cond_9

    .line 730
    .line 731
    const/16 v2, 0x7f6

    .line 732
    .line 733
    :goto_6
    move/from16 v16, v2

    .line 734
    .line 735
    goto :goto_7

    .line 736
    :cond_9
    const/16 v2, 0x7d2

    .line 737
    .line 738
    goto :goto_6

    .line 739
    :goto_7
    const/16 v17, 0x128

    .line 740
    .line 741
    const/16 v18, -0x3

    .line 742
    .line 743
    move-object v13, v1

    .line 744
    invoke-direct/range {v13 .. v18}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    .line 745
    .line 746
    .line 747
    iput-object v1, v0, Lp/Pb;->t:Landroid/view/WindowManager$LayoutParams;

    .line 748
    .line 749
    const/16 v2, 0x33

    .line 750
    .line 751
    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 752
    .line 753
    const-string v2, "_x"

    .line 754
    .line 755
    invoke-virtual {v11, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 756
    .line 757
    .line 758
    move-result-object v2

    .line 759
    const/high16 v3, 0x41900000    # 18.0f

    .line 760
    .line 761
    invoke-virtual {v7, v3}, Lp/Ub;->d(F)I

    .line 762
    .line 763
    .line 764
    move-result v3

    .line 765
    iget-object v4, v7, Lp/Ub;->d:Landroid/content/SharedPreferences;

    .line 766
    .line 767
    invoke-interface {v4, v2, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    .line 768
    .line 769
    .line 770
    move-result v2

    .line 771
    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 772
    .line 773
    const-string v2, "_y"

    .line 774
    .line 775
    invoke-virtual {v11, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 776
    .line 777
    .line 778
    move-result-object v2

    .line 779
    if-eqz v9, :cond_a

    .line 780
    .line 781
    const/high16 v3, 0x432a0000    # 170.0f

    .line 782
    .line 783
    goto :goto_8

    .line 784
    :cond_a
    if-eqz v10, :cond_b

    .line 785
    .line 786
    const/high16 v3, 0x43ad0000    # 346.0f

    .line 787
    .line 788
    goto :goto_8

    .line 789
    :cond_b
    const/high16 v3, 0x43810000    # 258.0f

    .line 790
    .line 791
    :goto_8
    invoke-virtual {v7, v3}, Lp/Ub;->d(F)I

    .line 792
    .line 793
    .line 794
    move-result v3

    .line 795
    invoke-interface {v4, v2, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    .line 796
    .line 797
    .line 798
    move-result v2

    .line 799
    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 800
    .line 801
    new-instance v1, Lp/Sb;

    .line 802
    .line 803
    invoke-direct {v1, v7, v0}, Lp/Sb;-><init>(Lp/Ub;Lp/Pb;)V

    .line 804
    .line 805
    .line 806
    iput-object v1, v0, Lp/Pb;->s:Lp/Sb;

    .line 807
    .line 808
    new-instance v2, Lp/Nb;

    .line 809
    .line 810
    const/4 v3, 0x0

    .line 811
    invoke-direct {v2, v0, v3}, Lp/Nb;-><init>(Lp/Pb;I)V

    .line 812
    .line 813
    .line 814
    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 815
    .line 816
    .line 817
    new-instance v2, Lp/Ob;

    .line 818
    .line 819
    invoke-direct {v2, v0}, Lp/Ob;-><init>(Lp/Pb;)V

    .line 820
    .line 821
    .line 822
    invoke-virtual {v1, v2}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 823
    .line 824
    .line 825
    return-void
.end method


# virtual methods
.method public final a(Z)V
    .locals 2

    .line 1
    iget-object v0, p0, Lp/Pb;->y:Lp/Ub;

    .line 2
    .line 3
    iget-boolean v1, v0, Lp/Ub;->g:Z

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    if-eqz p1, :cond_1

    .line 9
    .line 10
    invoke-virtual {p0}, Lp/Pb;->f()V

    .line 11
    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_1
    iget-boolean p1, p0, Lp/Pb;->u:Z

    .line 15
    .line 16
    if-nez p1, :cond_2

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_2
    :try_start_0
    iget-object p1, v0, Lp/Ub;->b:Landroid/view/WindowManager;

    .line 20
    .line 21
    iget-object v1, p0, Lp/Pb;->s:Lp/Sb;

    .line 22
    .line 23
    invoke-interface {p1, v1}, Landroid/view/WindowManager;->removeViewImmediate(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 24
    .line 25
    .line 26
    :catch_0
    const/4 p1, 0x0

    .line 27
    iput-boolean p1, p0, Lp/Pb;->u:Z

    .line 28
    .line 29
    :goto_0
    iget-object p1, v0, Lp/Ub;->d:Landroid/content/SharedPreferences;

    .line 30
    .line 31
    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    iget-object v0, p0, Lp/Pb;->b:Ljava/lang/String;

    .line 36
    .line 37
    const-string v1, "_visible"

    .line 38
    .line 39
    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    iget-boolean v1, p0, Lp/Pb;->u:Z

    .line 44
    .line 45
    invoke-interface {p1, v0, v1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 50
    .line 51
    .line 52
    invoke-virtual {p0}, Lp/Pb;->d()V

    .line 53
    .line 54
    .line 55
    return-void
.end method

.method public final b()V
    .locals 9

    .line 1
    new-instance v0, Landroid/graphics/Rect;

    .line 2
    .line 3
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 4
    .line 5
    .line 6
    const/high16 v1, 0x41c00000    # 24.0f

    .line 7
    .line 8
    iget-object v2, p0, Lp/Pb;->y:Lp/Ub;

    .line 9
    .line 10
    invoke-virtual {v2, v1}, Lp/Ub;->d(F)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    const/high16 v3, 0x42400000    # 48.0f

    .line 15
    .line 16
    invoke-virtual {v2, v3}, Lp/Ub;->d(F)I

    .line 17
    .line 18
    .line 19
    move-result v3

    .line 20
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 21
    .line 22
    const/16 v5, 0x1e

    .line 23
    .line 24
    iget-object v2, v2, Lp/Ub;->b:Landroid/view/WindowManager;

    .line 25
    .line 26
    if-lt v4, v5, :cond_0

    .line 27
    .line 28
    invoke-static {v2}, Lp/u;->m(Landroid/view/WindowManager;)Landroid/view/WindowMetrics;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    invoke-static {v1}, Lp/u;->g(Landroid/view/WindowMetrics;)Landroid/graphics/Rect;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    invoke-virtual {v0, v2}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 37
    .line 38
    .line 39
    invoke-static {v1}, Lp/u;->i(Landroid/view/WindowMetrics;)Landroid/view/WindowInsets;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    invoke-static {}, Lp/u;->b()I

    .line 44
    .line 45
    .line 46
    move-result v2

    .line 47
    invoke-static {}, Lp/qi;->a()I

    .line 48
    .line 49
    .line 50
    move-result v3

    .line 51
    or-int/2addr v2, v3

    .line 52
    invoke-static {v1, v2}, Lp/u;->e(Landroid/view/WindowInsets;I)Landroid/graphics/Insets;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    invoke-static {v1}, Lp/t;->b(Landroid/graphics/Insets;)I

    .line 57
    .line 58
    .line 59
    move-result v2

    .line 60
    invoke-static {v1}, Lp/t;->u(Landroid/graphics/Insets;)I

    .line 61
    .line 62
    .line 63
    move-result v3

    .line 64
    invoke-static {v1}, Lp/t;->y(Landroid/graphics/Insets;)I

    .line 65
    .line 66
    .line 67
    move-result v4

    .line 68
    invoke-static {v1}, Lp/t;->C(Landroid/graphics/Insets;)I

    .line 69
    .line 70
    .line 71
    move-result v1

    .line 72
    move v8, v3

    .line 73
    move v3, v1

    .line 74
    move v1, v8

    .line 75
    goto :goto_0

    .line 76
    :cond_0
    invoke-interface {v2}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    .line 77
    .line 78
    .line 79
    move-result-object v2

    .line 80
    invoke-virtual {v2, v0}, Landroid/view/Display;->getRectSize(Landroid/graphics/Rect;)V

    .line 81
    .line 82
    .line 83
    const/4 v2, 0x0

    .line 84
    move v4, v2

    .line 85
    :goto_0
    iget-object v5, p0, Lp/Pb;->t:Landroid/view/WindowManager$LayoutParams;

    .line 86
    .line 87
    iget v6, v5, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 88
    .line 89
    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    .line 90
    .line 91
    .line 92
    move-result v7

    .line 93
    sub-int/2addr v7, v4

    .line 94
    iget v4, v5, Landroid/view/WindowManager$LayoutParams;->width:I

    .line 95
    .line 96
    sub-int/2addr v7, v4

    .line 97
    invoke-static {v6, v7}, Ljava/lang/Math;->min(II)I

    .line 98
    .line 99
    .line 100
    move-result v4

    .line 101
    invoke-static {v2, v4}, Ljava/lang/Math;->max(II)I

    .line 102
    .line 103
    .line 104
    move-result v2

    .line 105
    iput v2, v5, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 106
    .line 107
    iget v2, v5, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 108
    .line 109
    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    sub-int/2addr v0, v3

    .line 114
    iget v3, v5, Landroid/view/WindowManager$LayoutParams;->height:I

    .line 115
    .line 116
    sub-int/2addr v0, v3

    .line 117
    invoke-static {v2, v0}, Ljava/lang/Math;->min(II)I

    .line 118
    .line 119
    .line 120
    move-result v0

    .line 121
    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    .line 122
    .line 123
    .line 124
    move-result v0

    .line 125
    iput v0, v5, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 126
    .line 127
    return-void
.end method

.method public final c()V
    .locals 3

    .line 1
    invoke-virtual {p0}, Lp/Pb;->b()V

    .line 2
    .line 3
    .line 4
    iget-boolean v0, p0, Lp/Pb;->u:Z

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    :try_start_0
    iget-object v0, p0, Lp/Pb;->y:Lp/Ub;

    .line 9
    .line 10
    iget-object v0, v0, Lp/Ub;->b:Landroid/view/WindowManager;

    .line 11
    .line 12
    iget-object v1, p0, Lp/Pb;->s:Lp/Sb;

    .line 13
    .line 14
    iget-object v2, p0, Lp/Pb;->t:Landroid/view/WindowManager$LayoutParams;

    .line 15
    .line 16
    invoke-interface {v0, v1, v2}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 17
    .line 18
    .line 19
    goto :goto_0

    .line 20
    :catch_0
    const/4 v0, 0x0

    .line 21
    iput-boolean v0, p0, Lp/Pb;->u:Z

    .line 22
    .line 23
    :cond_0
    :goto_0
    return-void
.end method

.method public final d()V
    .locals 14

    .line 1
    iget-object v0, p0, Lp/Pb;->y:Lp/Ub;

    .line 2
    .line 3
    iget v1, v0, Lp/Ub;->h:I

    .line 4
    .line 5
    iget v2, p0, Lp/Pb;->d:I

    .line 6
    .line 7
    and-int/2addr v2, v1

    .line 8
    const/4 v3, 0x1

    .line 9
    const/4 v4, 0x0

    .line 10
    if-eqz v2, :cond_0

    .line 11
    .line 12
    move v2, v3

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    move v2, v4

    .line 15
    :goto_0
    const/16 v5, 0x55

    .line 16
    .line 17
    iget v6, p0, Lp/Pb;->c:I

    .line 18
    .line 19
    if-ne v6, v5, :cond_1

    .line 20
    .line 21
    and-int/lit16 v7, v1, 0x80

    .line 22
    .line 23
    if-eqz v7, :cond_1

    .line 24
    .line 25
    move v7, v3

    .line 26
    goto :goto_1

    .line 27
    :cond_1
    move v7, v4

    .line 28
    :goto_1
    const/16 v8, 0x5e

    .line 29
    .line 30
    if-ne v6, v8, :cond_2

    .line 31
    .line 32
    and-int/lit8 v8, v1, 0x40

    .line 33
    .line 34
    if-eqz v8, :cond_2

    .line 35
    .line 36
    move v8, v3

    .line 37
    goto :goto_2

    .line 38
    :cond_2
    move v8, v4

    .line 39
    :goto_2
    if-ne v6, v5, :cond_5

    .line 40
    .line 41
    and-int/lit8 v9, v1, 0x10

    .line 42
    .line 43
    if-eqz v9, :cond_4

    .line 44
    .line 45
    :cond_3
    :goto_3
    move v9, v3

    .line 46
    goto :goto_4

    .line 47
    :cond_4
    move v9, v4

    .line 48
    goto :goto_4

    .line 49
    :cond_5
    if-nez v2, :cond_3

    .line 50
    .line 51
    if-eqz v8, :cond_4

    .line 52
    .line 53
    goto :goto_3

    .line 54
    :goto_4
    if-eqz v8, :cond_6

    .line 55
    .line 56
    if-nez v2, :cond_6

    .line 57
    .line 58
    const-string v10, "FILA"

    .line 59
    .line 60
    goto :goto_5

    .line 61
    :cond_6
    if-nez v2, :cond_7

    .line 62
    .line 63
    const-string v10, "OFF"

    .line 64
    .line 65
    goto :goto_5

    .line 66
    :cond_7
    if-eqz v7, :cond_8

    .line 67
    .line 68
    const-string v10, "AUTO"

    .line 69
    .line 70
    goto :goto_5

    .line 71
    :cond_8
    const-string v10, "ON"

    .line 72
    .line 73
    :goto_5
    if-ne v6, v5, :cond_9

    .line 74
    .line 75
    and-int/lit16 v11, v1, 0x400

    .line 76
    .line 77
    if-eqz v11, :cond_9

    .line 78
    .line 79
    move v11, v3

    .line 80
    goto :goto_6

    .line 81
    :cond_9
    move v11, v4

    .line 82
    :goto_6
    if-ne v6, v5, :cond_a

    .line 83
    .line 84
    and-int/lit16 v1, v1, 0x800

    .line 85
    .line 86
    if-eqz v1, :cond_a

    .line 87
    .line 88
    move v1, v3

    .line 89
    goto :goto_7

    .line 90
    :cond_a
    move v1, v4

    .line 91
    :goto_7
    const/16 v5, 0xbb8

    .line 92
    .line 93
    if-nez v11, :cond_b

    .line 94
    .line 95
    if-eqz v1, :cond_d

    .line 96
    .line 97
    :cond_b
    if-eqz v11, :cond_c

    .line 98
    .line 99
    iget v1, v0, Lp/Ub;->i:I

    .line 100
    .line 101
    goto :goto_8

    .line 102
    :cond_c
    move v1, v4

    .line 103
    :goto_8
    invoke-static {v5, v1}, Ljava/lang/Math;->min(II)I

    .line 104
    .line 105
    .line 106
    move-result v1

    .line 107
    invoke-static {v4, v1}, Ljava/lang/Math;->max(II)I

    .line 108
    .line 109
    .line 110
    move-result v1

    .line 111
    new-instance v6, Ljava/lang/StringBuilder;

    .line 112
    .line 113
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 114
    .line 115
    .line 116
    div-int/lit16 v10, v1, 0x3e8

    .line 117
    .line 118
    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 119
    .line 120
    .line 121
    const-string v10, "."

    .line 122
    .line 123
    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 124
    .line 125
    .line 126
    rem-int/lit16 v1, v1, 0x3e8

    .line 127
    .line 128
    add-int/lit16 v1, v1, 0x3e8

    .line 129
    .line 130
    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    move-result-object v1

    .line 134
    invoke-virtual {v1, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v1

    .line 138
    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 139
    .line 140
    .line 141
    const-string v1, "s"

    .line 142
    .line 143
    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 144
    .line 145
    .line 146
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object v10

    .line 150
    :cond_d
    if-eqz v11, :cond_f

    .line 151
    .line 152
    iget v1, v0, Lp/Ub;->h:I

    .line 153
    .line 154
    and-int/lit16 v1, v1, 0x1000

    .line 155
    .line 156
    if-eqz v1, :cond_e

    .line 157
    .line 158
    goto :goto_9

    .line 159
    :cond_e
    const/16 v5, 0x514

    .line 160
    .line 161
    goto :goto_9

    .line 162
    :cond_f
    move v5, v4

    .line 163
    :goto_9
    iget-object v1, p0, Lp/Pb;->s:Lp/Sb;

    .line 164
    .line 165
    iget v6, v1, Lp/Sb;->d:I

    .line 166
    .line 167
    if-eqz v11, :cond_10

    .line 168
    .line 169
    iget v12, v0, Lp/Ub;->i:I

    .line 170
    .line 171
    goto :goto_a

    .line 172
    :cond_10
    move v12, v4

    .line 173
    :goto_a
    if-ne v6, v12, :cond_12

    .line 174
    .line 175
    iget v6, v1, Lp/Sb;->e:I

    .line 176
    .line 177
    if-eq v6, v5, :cond_11

    .line 178
    .line 179
    goto :goto_b

    .line 180
    :cond_11
    move v6, v4

    .line 181
    goto :goto_c

    .line 182
    :cond_12
    :goto_b
    move v6, v3

    .line 183
    :goto_c
    if-eqz v11, :cond_13

    .line 184
    .line 185
    iget v11, v0, Lp/Ub;->i:I

    .line 186
    .line 187
    goto :goto_d

    .line 188
    :cond_13
    move v11, v4

    .line 189
    :goto_d
    iput v11, v1, Lp/Sb;->d:I

    .line 190
    .line 191
    iput v5, v1, Lp/Sb;->e:I

    .line 192
    .line 193
    iget v5, v0, Lp/Ub;->h:I

    .line 194
    .line 195
    and-int/lit16 v5, v5, 0x38c

    .line 196
    .line 197
    iget-boolean v11, p0, Lp/Pb;->u:Z

    .line 198
    .line 199
    iget-boolean v12, p0, Lp/Pb;->w:Z

    .line 200
    .line 201
    if-ne v11, v12, :cond_15

    .line 202
    .line 203
    iget-boolean v11, v1, Lp/Sb;->g:Z

    .line 204
    .line 205
    if-ne v11, v9, :cond_15

    .line 206
    .line 207
    iget-boolean v11, v1, Lp/Sb;->f:Z

    .line 208
    .line 209
    if-ne v11, v2, :cond_15

    .line 210
    .line 211
    iget v11, p0, Lp/Pb;->x:I

    .line 212
    .line 213
    if-eq v5, v11, :cond_14

    .line 214
    .line 215
    goto :goto_e

    .line 216
    :cond_14
    move v11, v4

    .line 217
    goto :goto_f

    .line 218
    :cond_15
    :goto_e
    move v11, v3

    .line 219
    :goto_f
    iget-object v12, p0, Lp/Pb;->v:Ljava/lang/String;

    .line 220
    .line 221
    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 222
    .line 223
    .line 224
    move-result v12

    .line 225
    iget-object v13, p0, Lp/Pb;->g:Landroid/widget/TextView;

    .line 226
    .line 227
    if-nez v12, :cond_16

    .line 228
    .line 229
    iput-object v10, p0, Lp/Pb;->v:Ljava/lang/String;

    .line 230
    .line 231
    invoke-virtual {v13, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 232
    .line 233
    .line 234
    iput-object v10, v1, Lp/Sb;->c:Ljava/lang/String;

    .line 235
    .line 236
    :cond_16
    if-nez v11, :cond_19

    .line 237
    .line 238
    if-eqz v12, :cond_17

    .line 239
    .line 240
    if-eqz v6, :cond_18

    .line 241
    .line 242
    :cond_17
    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    .line 243
    .line 244
    .line 245
    :cond_18
    return-void

    .line 246
    :cond_19
    iput-object v10, p0, Lp/Pb;->v:Ljava/lang/String;

    .line 247
    .line 248
    iget-boolean v6, p0, Lp/Pb;->u:Z

    .line 249
    .line 250
    iput-boolean v6, p0, Lp/Pb;->w:Z

    .line 251
    .line 252
    iput v5, p0, Lp/Pb;->x:I

    .line 253
    .line 254
    invoke-virtual {v13, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 255
    .line 256
    .line 257
    if-eqz v2, :cond_1a

    .line 258
    .line 259
    const/4 v5, -0x1

    .line 260
    goto :goto_10

    .line 261
    :cond_1a
    const v5, -0x555556

    .line 262
    .line 263
    .line 264
    :goto_10
    invoke-virtual {v13, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 265
    .line 266
    .line 267
    iget v5, v0, Lp/Ub;->j:I

    .line 268
    .line 269
    if-eqz v2, :cond_1b

    .line 270
    .line 271
    move v6, v5

    .line 272
    goto :goto_11

    .line 273
    :cond_1b
    const v6, -0xcfcfd0

    .line 274
    .line 275
    .line 276
    :goto_11
    if-eqz v2, :cond_1c

    .line 277
    .line 278
    move v11, v5

    .line 279
    goto :goto_12

    .line 280
    :cond_1c
    const v11, -0xb4b4b5

    .line 281
    .line 282
    .line 283
    :goto_12
    const/16 v12, 0xb

    .line 284
    .line 285
    invoke-static {v0, v6, v11, v12}, Lp/Ub;->b(Lp/Ub;III)Landroid/graphics/drawable/GradientDrawable;

    .line 286
    .line 287
    .line 288
    move-result-object v6

    .line 289
    invoke-virtual {v13, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 290
    .line 291
    .line 292
    iget-object v6, p0, Lp/Pb;->f:Landroid/widget/LinearLayout;

    .line 293
    .line 294
    if-eqz v2, :cond_1d

    .line 295
    .line 296
    move v11, v5

    .line 297
    goto :goto_13

    .line 298
    :cond_1d
    const v11, -0xbababb

    .line 299
    .line 300
    .line 301
    :goto_13
    const/16 v12, 0xa

    .line 302
    .line 303
    const v13, -0xfdadadb

    .line 304
    .line 305
    .line 306
    invoke-static {v0, v13, v11, v12}, Lp/Ub;->b(Lp/Ub;III)Landroid/graphics/drawable/GradientDrawable;

    .line 307
    .line 308
    .line 309
    move-result-object v11

    .line 310
    invoke-virtual {v6, v11}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 311
    .line 312
    .line 313
    iget-object v6, p0, Lp/Pb;->h:Landroid/widget/TextView;

    .line 314
    .line 315
    iget-boolean v11, p0, Lp/Pb;->u:Z

    .line 316
    .line 317
    if-eqz v11, :cond_1e

    .line 318
    .line 319
    move v11, v4

    .line 320
    goto :goto_14

    .line 321
    :cond_1e
    move v11, v5

    .line 322
    :goto_14
    const/4 v12, 0x6

    .line 323
    invoke-static {v0, v11, v4, v12}, Lp/Ub;->b(Lp/Ub;III)Landroid/graphics/drawable/GradientDrawable;

    .line 324
    .line 325
    .line 326
    move-result-object v11

    .line 327
    invoke-virtual {v6, v11}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 328
    .line 329
    .line 330
    iget-object v11, p0, Lp/Pb;->i:Landroid/widget/TextView;

    .line 331
    .line 332
    iget-boolean v13, p0, Lp/Pb;->u:Z

    .line 333
    .line 334
    if-eqz v13, :cond_1f

    .line 335
    .line 336
    move v13, v5

    .line 337
    goto :goto_15

    .line 338
    :cond_1f
    move v13, v4

    .line 339
    :goto_15
    invoke-static {v0, v13, v4, v12}, Lp/Ub;->b(Lp/Ub;III)Landroid/graphics/drawable/GradientDrawable;

    .line 340
    .line 341
    .line 342
    move-result-object v13

    .line 343
    invoke-virtual {v11, v13}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 344
    .line 345
    .line 346
    iget-boolean v13, p0, Lp/Pb;->u:Z

    .line 347
    .line 348
    xor-int/2addr v3, v13

    .line 349
    invoke-virtual {v6, v3}, Landroid/widget/TextView;->setSelected(Z)V

    .line 350
    .line 351
    .line 352
    iget-boolean v3, p0, Lp/Pb;->u:Z

    .line 353
    .line 354
    invoke-virtual {v11, v3}, Landroid/widget/TextView;->setSelected(Z)V

    .line 355
    .line 356
    .line 357
    iget-object v3, p0, Lp/Pb;->j:Lp/Rb;

    .line 358
    .line 359
    if-eqz v3, :cond_2a

    .line 360
    .line 361
    iget-object v6, p0, Lp/Pb;->p:Landroid/widget/TextView;

    .line 362
    .line 363
    if-eqz v7, :cond_20

    .line 364
    .line 365
    move v11, v4

    .line 366
    goto :goto_16

    .line 367
    :cond_20
    move v11, v5

    .line 368
    :goto_16
    invoke-static {v0, v11, v4, v12}, Lp/Ub;->b(Lp/Ub;III)Landroid/graphics/drawable/GradientDrawable;

    .line 369
    .line 370
    .line 371
    move-result-object v11

    .line 372
    invoke-virtual {v6, v11}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 373
    .line 374
    .line 375
    iget-object v11, p0, Lp/Pb;->q:Landroid/widget/TextView;

    .line 376
    .line 377
    if-eqz v7, :cond_21

    .line 378
    .line 379
    goto :goto_17

    .line 380
    :cond_21
    move v5, v4

    .line 381
    :goto_17
    invoke-static {v0, v5, v4, v12}, Lp/Ub;->b(Lp/Ub;III)Landroid/graphics/drawable/GradientDrawable;

    .line 382
    .line 383
    .line 384
    move-result-object v5

    .line 385
    invoke-virtual {v11, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 386
    .line 387
    .line 388
    xor-int/lit8 v5, v7, 0x1

    .line 389
    .line 390
    invoke-virtual {v6, v5}, Landroid/widget/TextView;->setSelected(Z)V

    .line 391
    .line 392
    .line 393
    invoke-virtual {v11, v7}, Landroid/widget/TextView;->setSelected(Z)V

    .line 394
    .line 395
    .line 396
    iget-object v5, p0, Lp/Pb;->n:Landroid/widget/LinearLayout;

    .line 397
    .line 398
    const/16 v6, 0x8

    .line 399
    .line 400
    if-eqz v7, :cond_22

    .line 401
    .line 402
    move v11, v4

    .line 403
    goto :goto_18

    .line 404
    :cond_22
    move v11, v6

    .line 405
    :goto_18
    invoke-virtual {v5, v11}, Landroid/view/View;->setVisibility(I)V

    .line 406
    .line 407
    .line 408
    iget-object v5, p0, Lp/Pb;->o:Landroid/widget/LinearLayout;

    .line 409
    .line 410
    if-eqz v7, :cond_23

    .line 411
    .line 412
    move v4, v6

    .line 413
    :cond_23
    invoke-virtual {v5, v4}, Landroid/view/View;->setVisibility(I)V

    .line 414
    .line 415
    .line 416
    iget-object v4, p0, Lp/Pb;->r:Landroid/widget/TextView;

    .line 417
    .line 418
    if-eqz v7, :cond_26

    .line 419
    .line 420
    if-nez v2, :cond_24

    .line 421
    .line 422
    const-string v0, "Toque no Freeze para armar os gatilhos."

    .line 423
    .line 424
    goto :goto_19

    .line 425
    :cond_24
    iget v0, v0, Lp/Ub;->h:I

    .line 426
    .line 427
    and-int/lit8 v0, v0, 0xc

    .line 428
    .line 429
    if-nez v0, :cond_25

    .line 430
    .line 431
    const-string v0, "Selecione tiro, mira ou os dois."

    .line 432
    .line 433
    goto :goto_19

    .line 434
    :cond_25
    const-string v0, "Armado: funciona durante as a\u00e7\u00f5es marcadas."

    .line 435
    .line 436
    goto :goto_19

    .line 437
    :cond_26
    iget v0, v0, Lp/Ub;->h:I

    .line 438
    .line 439
    and-int/lit16 v5, v0, 0x300

    .line 440
    .line 441
    const/16 v6, 0x300

    .line 442
    .line 443
    if-ne v5, v6, :cond_27

    .line 444
    .line 445
    const-string v0, "As duas marcadas: solta no primeiro prazo."

    .line 446
    .line 447
    goto :goto_19

    .line 448
    :cond_27
    and-int/lit16 v5, v0, 0x200

    .line 449
    .line 450
    if-eqz v5, :cond_28

    .line 451
    .line 452
    const-string v0, "Solta em 3 s, mesmo sem disparar."

    .line 453
    .line 454
    goto :goto_19

    .line 455
    :cond_28
    and-int/lit16 v0, v0, 0x100

    .line 456
    .line 457
    if-eqz v0, :cond_29

    .line 458
    .line 459
    const-string v0, "Ligue por toque. Ap\u00f3s um disparo, solta sozinho."

    .line 460
    .line 461
    goto :goto_19

    .line 462
    :cond_29
    const-string v0, "Toque para congelar. Toque novamente para soltar."

    .line 463
    .line 464
    :goto_19
    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 465
    .line 466
    .line 467
    invoke-virtual {v3}, Lp/Rb;->a()V

    .line 468
    .line 469
    .line 470
    iget-object v0, p0, Lp/Pb;->k:Lp/Rb;

    .line 471
    .line 472
    invoke-virtual {v0}, Lp/Rb;->a()V

    .line 473
    .line 474
    .line 475
    iget-object v0, p0, Lp/Pb;->l:Lp/Rb;

    .line 476
    .line 477
    invoke-virtual {v0}, Lp/Rb;->a()V

    .line 478
    .line 479
    .line 480
    iget-object v0, p0, Lp/Pb;->m:Lp/Rb;

    .line 481
    .line 482
    invoke-virtual {v0}, Lp/Rb;->a()V

    .line 483
    .line 484
    .line 485
    :cond_2a
    iput-object v10, v1, Lp/Sb;->c:Ljava/lang/String;

    .line 486
    .line 487
    iput-boolean v2, v1, Lp/Sb;->f:Z

    .line 488
    .line 489
    iput-boolean v9, v1, Lp/Sb;->g:Z

    .line 490
    .line 491
    if-eqz v8, :cond_2b

    .line 492
    .line 493
    if-nez v2, :cond_2b

    .line 494
    .line 495
    const-string v0, "liberando fila"

    .line 496
    .line 497
    goto :goto_1a

    .line 498
    :cond_2b
    if-nez v2, :cond_2c

    .line 499
    .line 500
    const-string v0, "desligado"

    .line 501
    .line 502
    goto :goto_1a

    .line 503
    :cond_2c
    if-eqz v7, :cond_2e

    .line 504
    .line 505
    if-eqz v9, :cond_2d

    .line 506
    .line 507
    const-string v0, "autom\u00e1tico, a\u00e7\u00e3o detectada"

    .line 508
    .line 509
    goto :goto_1a

    .line 510
    :cond_2d
    const-string v0, "autom\u00e1tico, esperando disparo o mira"

    .line 511
    .line 512
    goto :goto_1a

    .line 513
    :cond_2e
    const-string v0, "ligado"

    .line 514
    .line 515
    :goto_1a
    new-instance v2, Ljava/lang/StringBuilder;

    .line 516
    .line 517
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 518
    .line 519
    .line 520
    iget-object v3, p0, Lp/Pb;->a:Ljava/lang/String;

    .line 521
    .line 522
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 523
    .line 524
    .line 525
    const-string v3, ", "

    .line 526
    .line 527
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 528
    .line 529
    .line 530
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 531
    .line 532
    .line 533
    const-string v0, ". Toque para alternar; arraste para mover."

    .line 534
    .line 535
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 536
    .line 537
    .line 538
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 539
    .line 540
    .line 541
    move-result-object v0

    .line 542
    invoke-virtual {v1, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 543
    .line 544
    .line 545
    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    .line 546
    .line 547
    .line 548
    return-void
.end method

.method public final e(Z)V
    .locals 8

    .line 1
    iget-object v0, p0, Lp/Pb;->y:Lp/Ub;

    .line 2
    .line 3
    :try_start_0
    iget-object v1, v0, Lp/Ub;->c:Lp/Di;

    .line 4
    .line 5
    const-string v7, "quick_control"

    .line 6
    .line 7
    iget-object v1, v1, Lp/Di;->a:Ljava/lang/Object;

    .line 8
    .line 9
    move-object v3, v1

    .line 10
    check-cast v3, Lgringoxp/game/b;

    .line 11
    .line 12
    const/16 v4, 0x73

    .line 13
    .line 14
    const/4 v5, 0x0

    .line 15
    move-object v2, v3

    .line 16
    move v6, p1

    .line 17
    invoke-virtual/range {v2 .. v7}, Lgringoxp/game/b;->Cases(Landroid/content/Context;IIZLjava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_0} :catch_0

    .line 18
    .line 19
    .line 20
    invoke-virtual {v0}, Lp/Ub;->e()V

    .line 21
    .line 22
    .line 23
    iget-object p1, v0, Lp/Ub;->f:Ljava/util/ArrayList;

    .line 24
    .line 25
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    if-eqz v1, :cond_0

    .line 34
    .line 35
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    check-cast v1, Lp/Pb;

    .line 40
    .line 41
    invoke-virtual {v1}, Lp/Pb;->d()V

    .line 42
    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_0
    iget-boolean p1, v0, Lp/Ub;->g:Z

    .line 46
    .line 47
    if-eqz p1, :cond_1

    .line 48
    .line 49
    goto :goto_1

    .line 50
    :cond_1
    iget-object p1, v0, Lp/Ub;->e:Landroid/os/Handler;

    .line 51
    .line 52
    iget-object v0, v0, Lp/Ub;->l:Lp/v2;

    .line 53
    .line 54
    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 58
    .line 59
    .line 60
    :catch_0
    :goto_1
    return-void
.end method

.method public final f()V
    .locals 4

    .line 1
    iget-boolean v0, p0, Lp/Pb;->u:Z

    .line 2
    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    iget-object v0, p0, Lp/Pb;->y:Lp/Ub;

    .line 6
    .line 7
    iget-boolean v1, v0, Lp/Ub;->g:Z

    .line 8
    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    invoke-virtual {p0}, Lp/Pb;->b()V

    .line 13
    .line 14
    .line 15
    :try_start_0
    iget-object v1, v0, Lp/Ub;->b:Landroid/view/WindowManager;

    .line 16
    .line 17
    iget-object v2, p0, Lp/Pb;->s:Lp/Sb;

    .line 18
    .line 19
    iget-object v3, p0, Lp/Pb;->t:Landroid/view/WindowManager$LayoutParams;

    .line 20
    .line 21
    invoke-interface {v1, v2, v3}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 22
    .line 23
    .line 24
    const/4 v1, 0x1

    .line 25
    iput-boolean v1, p0, Lp/Pb;->u:Z
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :catch_0
    new-instance v1, Ljava/lang/StringBuilder;

    .line 29
    .line 30
    const-string v2, "N\u00e3o foi poss\u00edvel exibir o bot\u00e3o "

    .line 31
    .line 32
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    iget-object v2, p0, Lp/Pb;->a:Ljava/lang/String;

    .line 36
    .line 37
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    const/4 v2, 0x0

    .line 45
    iget-object v0, v0, Lp/Ub;->a:Lgringoxp/game/b;

    .line 46
    .line 47
    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 52
    .line 53
    .line 54
    :cond_1
    :goto_0
    return-void
.end method

.method public final g()V
    .locals 12

    .line 1
    iget-object v0, p0, Lp/Pb;->y:Lp/Ub;

    .line 2
    .line 3
    iget-boolean v1, v0, Lp/Ub;->g:Z

    .line 4
    .line 5
    iget-object v2, v0, Lp/Ub;->a:Lgringoxp/game/b;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    return-void

    .line 10
    :cond_0
    invoke-virtual {v0}, Lp/Ub;->e()V

    .line 11
    .line 12
    .line 13
    iget v1, v0, Lp/Ub;->h:I

    .line 14
    .line 15
    iget v3, p0, Lp/Pb;->d:I

    .line 16
    .line 17
    and-int/2addr v1, v3

    .line 18
    const/4 v4, 0x1

    .line 19
    const/4 v5, 0x0

    .line 20
    if-nez v1, :cond_1

    .line 21
    .line 22
    move v1, v4

    .line 23
    goto :goto_0

    .line 24
    :cond_1
    move v1, v5

    .line 25
    :goto_0
    :try_start_0
    iget-object v6, v0, Lp/Ub;->c:Lp/Di;

    .line 26
    .line 27
    iget v8, p0, Lp/Pb;->c:I

    .line 28
    .line 29
    const-string v11, "quick_control"

    .line 30
    .line 31
    iget-object v6, v6, Lp/Di;->a:Ljava/lang/Object;

    .line 32
    .line 33
    move-object v7, v6

    .line 34
    check-cast v7, Lgringoxp/game/b;

    .line 35
    .line 36
    const/4 v9, 0x0

    .line 37
    move-object v6, v7

    .line 38
    move v10, v1

    .line 39
    invoke-virtual/range {v6 .. v11}, Lgringoxp/game/b;->Cases(Landroid/content/Context;IIZLjava/lang/String;)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v0}, Lp/Ub;->e()V
    :try_end_0
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_0} :catch_0

    .line 43
    .line 44
    .line 45
    goto :goto_1

    .line 46
    :catch_0
    const-string v6, "Controle indispon\u00edvel nesta vers\u00e3o"

    .line 47
    .line 48
    invoke-static {v2, v6, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 49
    .line 50
    .line 51
    move-result-object v6

    .line 52
    invoke-virtual {v6}, Landroid/widget/Toast;->show()V

    .line 53
    .line 54
    .line 55
    :goto_1
    iget v6, v0, Lp/Ub;->h:I

    .line 56
    .line 57
    and-int/2addr v3, v6

    .line 58
    if-eqz v3, :cond_2

    .line 59
    .line 60
    goto :goto_2

    .line 61
    :cond_2
    move v4, v5

    .line 62
    :goto_2
    iget-object v3, v0, Lp/Ub;->f:Ljava/util/ArrayList;

    .line 63
    .line 64
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 65
    .line 66
    .line 67
    move-result-object v3

    .line 68
    :goto_3
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 69
    .line 70
    .line 71
    move-result v6

    .line 72
    if-eqz v6, :cond_3

    .line 73
    .line 74
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v6

    .line 78
    check-cast v6, Lp/Pb;

    .line 79
    .line 80
    invoke-virtual {v6}, Lp/Pb;->d()V

    .line 81
    .line 82
    .line 83
    goto :goto_3

    .line 84
    :cond_3
    if-eq v4, v1, :cond_4

    .line 85
    .line 86
    new-instance v1, Ljava/lang/StringBuilder;

    .line 87
    .line 88
    const-string v3, "N\u00e3o foi poss\u00edvel alterar "

    .line 89
    .line 90
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    iget-object v3, p0, Lp/Pb;->a:Ljava/lang/String;

    .line 94
    .line 95
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 96
    .line 97
    .line 98
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object v1

    .line 102
    invoke-static {v2, v1, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 103
    .line 104
    .line 105
    move-result-object v1

    .line 106
    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 107
    .line 108
    .line 109
    :cond_4
    iget-boolean v1, v0, Lp/Ub;->g:Z

    .line 110
    .line 111
    if-eqz v1, :cond_5

    .line 112
    .line 113
    goto :goto_4

    .line 114
    :cond_5
    iget-object v1, v0, Lp/Ub;->e:Landroid/os/Handler;

    .line 115
    .line 116
    iget-object v0, v0, Lp/Ub;->l:Lp/v2;

    .line 117
    .line 118
    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 122
    .line 123
    .line 124
    :goto_4
    return-void
.end method
