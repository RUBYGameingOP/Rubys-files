.class public final Lp/Jh;
.super Lp/Ih;
.source "SourceFile"


# virtual methods
.method public final P(Landroid/view/View;F)V
    .locals 0

    .line 1
    invoke-static {p1, p2}, Lp/t;->i(Landroid/view/View;F)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final Q(Landroid/view/View;I)V
    .locals 0

    .line 1
    invoke-static {p1, p2}, Lp/t;->j(Landroid/view/View;I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final W(Landroid/view/View;IIII)V
    .locals 0

    .line 1
    invoke-static {p1, p2, p3, p4, p5}, Lp/t;->k(Landroid/view/View;IIII)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final X(Landroid/view/View;Landroid/graphics/Matrix;)V
    .locals 0

    .line 1
    invoke-static {p1, p2}, Lp/t;->w(Landroid/view/View;Landroid/graphics/Matrix;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final Y(Landroid/view/View;Landroid/graphics/Matrix;)V
    .locals 0

    .line 1
    invoke-static {p1, p2}, Lp/t;->A(Landroid/view/View;Landroid/graphics/Matrix;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final v(Landroid/view/View;)F
    .locals 0

    .line 1
    invoke-static {p1}, Lp/t;->a(Landroid/view/View;)F

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    return p1
.end method
