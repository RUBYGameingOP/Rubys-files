.class public final synthetic Lp/Qf;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/ToLongFunction;


# virtual methods
.method public final applyAsLong(Ljava/lang/Object;)J
    .locals 2

    .line 1
    check-cast p1, Lp/Sf;

    .line 2
    .line 3
    iget-wide v0, p1, Lp/Sf;->h:J

    .line 4
    .line 5
    return-wide v0
.end method
