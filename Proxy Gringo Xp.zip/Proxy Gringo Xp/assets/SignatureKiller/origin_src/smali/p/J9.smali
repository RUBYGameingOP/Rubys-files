.class public final synthetic Lp/J9;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lp/L9;

.field public final synthetic b:Ljava/net/DatagramSocket;

.field public final synthetic c:Ljava/net/DatagramSocket;

.field public final synthetic d:Ljava/util/concurrent/atomic/AtomicReference;

.field public final synthetic e:Ljava/util/concurrent/ConcurrentHashMap;


# direct methods
.method public synthetic constructor <init>(Lp/L9;Ljava/net/DatagramSocket;Ljava/net/DatagramSocket;Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/ConcurrentHashMap;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lp/J9;->a:Lp/L9;

    iput-object p2, p0, Lp/J9;->b:Ljava/net/DatagramSocket;

    iput-object p3, p0, Lp/J9;->c:Ljava/net/DatagramSocket;

    iput-object p4, p0, Lp/J9;->d:Ljava/util/concurrent/atomic/AtomicReference;

    iput-object p5, p0, Lp/J9;->e:Ljava/util/concurrent/ConcurrentHashMap;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 23

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget-object v2, v1, Lp/J9;->a:Lp/L9;

    .line 4
    .line 5
    iget-object v0, v1, Lp/J9;->b:Ljava/net/DatagramSocket;

    .line 6
    .line 7
    iget-object v9, v1, Lp/J9;->c:Ljava/net/DatagramSocket;

    .line 8
    .line 9
    iget-object v10, v1, Lp/J9;->d:Ljava/util/concurrent/atomic/AtomicReference;

    .line 10
    .line 11
    iget-object v11, v1, Lp/J9;->e:Ljava/util/concurrent/ConcurrentHashMap;

    .line 12
    .line 13
    const v12, 0xffff

    .line 14
    .line 15
    .line 16
    new-array v13, v12, [B

    .line 17
    .line 18
    :cond_0
    :goto_0
    iget-boolean v3, v2, Lp/L9;->h:Z

    .line 19
    .line 20
    if-eqz v3, :cond_8

    .line 21
    .line 22
    invoke-virtual {v9}, Ljava/net/DatagramSocket;->isClosed()Z

    .line 23
    .line 24
    .line 25
    move-result v3

    .line 26
    if-nez v3, :cond_8

    .line 27
    .line 28
    :try_start_0
    new-instance v3, Ljava/net/DatagramPacket;

    .line 29
    .line 30
    invoke-direct {v3, v13, v12}, Ljava/net/DatagramPacket;-><init>([BI)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v9, v3}, Ljava/net/DatagramSocket;->receive(Ljava/net/DatagramPacket;)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {v10}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v4

    .line 40
    move-object v14, v4

    .line 41
    check-cast v14, Ljava/net/InetSocketAddress;

    .line 42
    .line 43
    if-nez v14, :cond_1

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_1
    invoke-virtual {v3}, Ljava/net/DatagramPacket;->getSocketAddress()Ljava/net/SocketAddress;

    .line 47
    .line 48
    .line 49
    move-result-object v4

    .line 50
    move-object v8, v4

    .line 51
    check-cast v8, Ljava/net/InetSocketAddress;

    .line 52
    .line 53
    monitor-enter v11
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_2

    .line 54
    :try_start_1
    invoke-virtual {v9}, Ljava/net/DatagramSocket;->isClosed()Z

    .line 55
    .line 56
    .line 57
    move-result v4

    .line 58
    if-eqz v4, :cond_2

    .line 59
    .line 60
    monitor-exit v11

    .line 61
    goto/16 :goto_9

    .line 62
    .line 63
    :catchall_0
    move-exception v0

    .line 64
    goto/16 :goto_8

    .line 65
    .line 66
    :cond_2
    new-instance v4, Lp/K9;

    .line 67
    .line 68
    const/4 v5, 0x1

    .line 69
    invoke-direct {v4, v5}, Lp/K9;-><init>(I)V

    .line 70
    .line 71
    .line 72
    invoke-virtual {v11, v8, v4}, Ljava/util/concurrent/ConcurrentHashMap;->computeIfAbsent(Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v4

    .line 76
    check-cast v4, Ljava/lang/Integer;

    .line 77
    .line 78
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 79
    .line 80
    .line 81
    move-result v21
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 82
    const/16 v22, 0x0

    .line 83
    .line 84
    :try_start_2
    invoke-virtual {v3}, Ljava/net/DatagramPacket;->getData()[B

    .line 85
    .line 86
    .line 87
    move-result-object v18

    .line 88
    invoke-virtual {v3}, Ljava/net/DatagramPacket;->getOffset()I

    .line 89
    .line 90
    .line 91
    move-result v19

    .line 92
    invoke-virtual {v3}, Ljava/net/DatagramPacket;->getLength()I

    .line 93
    .line 94
    .line 95
    move-result v20

    .line 96
    const/4 v15, 0x0

    .line 97
    move/from16 v16, v21

    .line 98
    .line 99
    move-object/from16 v17, v8

    .line 100
    .line 101
    invoke-static/range {v15 .. v20}, Lgringoxp/game/b;->r(ZILjava/net/InetSocketAddress;[BII)[B

    .line 102
    .line 103
    .line 104
    move-result-object v4
    :try_end_2
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 105
    goto :goto_1

    .line 106
    :catch_0
    move-object/from16 v4, v22

    .line 107
    .line 108
    :goto_1
    :try_start_3
    monitor-exit v11
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 109
    if-eqz v4, :cond_3

    .line 110
    .line 111
    :try_start_4
    array-length v5, v4

    .line 112
    if-nez v5, :cond_3

    .line 113
    .line 114
    goto :goto_0

    .line 115
    :cond_3
    if-eqz v4, :cond_4

    .line 116
    .line 117
    move-object v6, v4

    .line 118
    goto :goto_2

    .line 119
    :cond_4
    invoke-virtual {v3}, Ljava/net/DatagramPacket;->getData()[B

    .line 120
    .line 121
    .line 122
    move-result-object v5

    .line 123
    move-object v6, v5

    .line 124
    :goto_2
    const/4 v15, 0x0

    .line 125
    if-eqz v4, :cond_5

    .line 126
    .line 127
    move v7, v15

    .line 128
    goto :goto_3

    .line 129
    :cond_5
    invoke-virtual {v3}, Ljava/net/DatagramPacket;->getOffset()I

    .line 130
    .line 131
    .line 132
    move-result v5

    .line 133
    move v7, v5

    .line 134
    :goto_3
    if-eqz v4, :cond_6

    .line 135
    .line 136
    array-length v3, v4

    .line 137
    :goto_4
    move/from16 v16, v3

    .line 138
    .line 139
    goto :goto_5

    .line 140
    :cond_6
    invoke-virtual {v3}, Ljava/net/DatagramPacket;->getLength()I

    .line 141
    .line 142
    .line 143
    move-result v3

    .line 144
    goto :goto_4

    .line 145
    :goto_5
    move-object v3, v0

    .line 146
    move-object v4, v14

    .line 147
    move-object v5, v8

    .line 148
    move-object/from16 v17, v8

    .line 149
    .line 150
    move/from16 v8, v16

    .line 151
    .line 152
    invoke-static/range {v3 .. v8}, Lp/L9;->g(Ljava/net/DatagramSocket;Ljava/net/InetSocketAddress;Ljava/net/InetSocketAddress;[BII)V

    .line 153
    .line 154
    .line 155
    iget-object v3, v2, Lp/L9;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 156
    .line 157
    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_2

    .line 158
    .line 159
    .line 160
    :goto_6
    const/16 v3, 0x8

    .line 161
    .line 162
    if-ge v15, v3, :cond_0

    .line 163
    .line 164
    :try_start_5
    invoke-static/range {v21 .. v21}, Lgringoxp/game/b;->takeNativeMarkerUdp(I)[B

    .line 165
    .line 166
    .line 167
    move-result-object v3
    :try_end_5
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_5 .. :try_end_5} :catch_1
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_2

    .line 168
    move-object v6, v3

    .line 169
    goto :goto_7

    .line 170
    :catch_1
    move-object/from16 v6, v22

    .line 171
    .line 172
    :goto_7
    if-eqz v6, :cond_0

    .line 173
    .line 174
    :try_start_6
    array-length v3, v6

    .line 175
    if-eqz v3, :cond_0

    .line 176
    .line 177
    array-length v3, v6

    .line 178
    const/16 v4, 0x1000

    .line 179
    .line 180
    if-le v3, v4, :cond_7

    .line 181
    .line 182
    goto/16 :goto_0

    .line 183
    .line 184
    :cond_7
    array-length v8, v6

    .line 185
    const/4 v7, 0x0

    .line 186
    move-object v3, v0

    .line 187
    move-object v4, v14

    .line 188
    move-object/from16 v5, v17

    .line 189
    .line 190
    invoke-static/range {v3 .. v8}, Lp/L9;->g(Ljava/net/DatagramSocket;Ljava/net/InetSocketAddress;Ljava/net/InetSocketAddress;[BII)V

    .line 191
    .line 192
    .line 193
    iget-object v3, v2, Lp/L9;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 194
    .line 195
    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_2

    .line 196
    .line 197
    .line 198
    add-int/lit8 v15, v15, 0x1

    .line 199
    .line 200
    goto :goto_6

    .line 201
    :goto_8
    :try_start_7
    monitor-exit v11
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    .line 202
    :try_start_8
    throw v0
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_2

    .line 203
    :catch_2
    iget-boolean v0, v2, Lp/L9;->h:Z

    .line 204
    .line 205
    if-eqz v0, :cond_8

    .line 206
    .line 207
    invoke-virtual {v9}, Ljava/net/DatagramSocket;->isClosed()Z

    .line 208
    .line 209
    .line 210
    move-result v0

    .line 211
    if-nez v0, :cond_8

    .line 212
    .line 213
    iget-object v0, v2, Lp/L9;->f:Ljava/util/concurrent/atomic/AtomicLong;

    .line 214
    .line 215
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    .line 216
    .line 217
    .line 218
    :cond_8
    :goto_9
    return-void
.end method
