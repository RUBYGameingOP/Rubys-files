.class public final Lp/L4;
.super Lp/M4;
.source "SourceFile"


# static fields
.field public static final b:Lp/L4;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lp/L4;

    .line 2
    .line 3
    invoke-direct {v0}, Lp/M4;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lp/L4;->b:Lp/L4;

    .line 7
    .line 8
    return-void
.end method
