.class public final synthetic Lp/Nb;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lp/Pb;


# direct methods
.method public synthetic constructor <init>(Lp/Pb;I)V
    .locals 0

    .line 1
    iput p2, p0, Lp/Nb;->a:I

    iput-object p1, p0, Lp/Nb;->b:Lp/Pb;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 1
    iget p1, p0, Lp/Nb;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const/4 p1, 0x1

    .line 7
    iget-object v0, p0, Lp/Nb;->b:Lp/Pb;

    .line 8
    .line 9
    invoke-virtual {v0, p1}, Lp/Pb;->e(Z)V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :pswitch_0
    const/4 p1, 0x0

    .line 14
    iget-object v0, p0, Lp/Nb;->b:Lp/Pb;

    .line 15
    .line 16
    invoke-virtual {v0, p1}, Lp/Pb;->e(Z)V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :pswitch_1
    const/4 p1, 0x1

    .line 21
    iget-object v0, p0, Lp/Nb;->b:Lp/Pb;

    .line 22
    .line 23
    invoke-virtual {v0, p1}, Lp/Pb;->a(Z)V

    .line 24
    .line 25
    .line 26
    return-void

    .line 27
    :pswitch_2
    const/4 p1, 0x0

    .line 28
    iget-object v0, p0, Lp/Nb;->b:Lp/Pb;

    .line 29
    .line 30
    invoke-virtual {v0, p1}, Lp/Pb;->a(Z)V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :pswitch_3
    iget-object p1, p0, Lp/Nb;->b:Lp/Pb;

    .line 35
    .line 36
    invoke-virtual {p1}, Lp/Pb;->g()V

    .line 37
    .line 38
    .line 39
    return-void

    .line 40
    :pswitch_4
    iget-object p1, p0, Lp/Nb;->b:Lp/Pb;

    .line 41
    .line 42
    invoke-virtual {p1}, Lp/Pb;->g()V

    .line 43
    .line 44
    .line 45
    return-void

    .line 46
    nop

    .line 47
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
