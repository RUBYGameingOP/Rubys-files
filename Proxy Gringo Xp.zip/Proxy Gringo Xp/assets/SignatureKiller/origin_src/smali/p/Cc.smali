.class public abstract Lp/Cc;
.super Ljava/lang/Object;
.source "SourceFile"
