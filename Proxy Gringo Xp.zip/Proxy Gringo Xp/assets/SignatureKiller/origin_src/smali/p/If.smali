.class public final Lp/If;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/view/WindowManager;Lp/Ji;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Lp/If;->a:I

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lp/If;->b:Ljava/lang/Object;

    iput-object p2, p0, Lp/If;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lp/Kf;)V
    .locals 3

    const/4 v0, 0x0

    iput v0, p0, Lp/If;->a:I

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lp/If;->c:Ljava/lang/Object;

    .line 2
    new-instance v0, Lp/W;

    iget-object v1, p1, Lp/Kf;->a:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    iget-object p1, p1, Lp/Kf;->h:Ljava/lang/CharSequence;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/16 v2, 0x1000

    .line 4
    iput v2, v0, Lp/W;->e:I

    .line 5
    iput v2, v0, Lp/W;->g:I

    const/4 v2, 0x0

    .line 6
    iput-object v2, v0, Lp/W;->l:Landroid/content/res/ColorStateList;

    .line 7
    iput-object v2, v0, Lp/W;->m:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x0

    .line 8
    iput-boolean v2, v0, Lp/W;->n:Z

    .line 9
    iput-boolean v2, v0, Lp/W;->o:Z

    const/16 v2, 0x10

    .line 10
    iput v2, v0, Lp/W;->p:I

    .line 11
    iput-object v1, v0, Lp/W;->i:Landroid/content/Context;

    .line 12
    iput-object p1, v0, Lp/W;->a:Ljava/lang/CharSequence;

    .line 13
    iput-object v0, p0, Lp/If;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 2

    .line 1
    iget p1, p0, Lp/If;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Lp/If;->c:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p1, Lp/Ji;

    .line 9
    .line 10
    iget-object v0, p0, Lp/If;->b:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, Landroid/view/WindowManager;

    .line 13
    .line 14
    invoke-interface {v0, p1}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_0
    iget-object p1, p0, Lp/If;->c:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast p1, Lp/Kf;

    .line 21
    .line 22
    iget-object v0, p1, Lp/Kf;->k:Landroid/view/Window$Callback;

    .line 23
    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    iget-boolean p1, p1, Lp/Kf;->l:Z

    .line 27
    .line 28
    if-eqz p1, :cond_0

    .line 29
    .line 30
    const/4 p1, 0x0

    .line 31
    iget-object v1, p0, Lp/If;->b:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast v1, Lp/W;

    .line 34
    .line 35
    invoke-interface {v0, p1, v1}, Landroid/view/Window$Callback;->onMenuItemSelected(ILandroid/view/MenuItem;)Z

    .line 36
    .line 37
    .line 38
    :cond_0
    return-void

    .line 39
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
