.class public abstract Lp/Pe;
.super Lp/Oe;
.source "SourceFile"
