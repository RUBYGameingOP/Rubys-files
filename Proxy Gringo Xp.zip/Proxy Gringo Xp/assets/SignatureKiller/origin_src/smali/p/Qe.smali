.class public abstract Lp/Qe;
.super Lp/Pe;
.source "SourceFile"
