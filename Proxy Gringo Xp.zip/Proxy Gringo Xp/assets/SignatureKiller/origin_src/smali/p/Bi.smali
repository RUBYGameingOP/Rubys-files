.class public final synthetic Lp/Bi;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnShowListener;


# instance fields
.field public final synthetic a:Lgringoxp/game/b;

.field public final synthetic b:Landroid/app/AlertDialog;

.field public final synthetic c:[Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Landroid/app/AlertDialog;Lgringoxp/game/b;[Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lp/Bi;->a:Lgringoxp/game/b;

    iput-object p1, p0, Lp/Bi;->b:Landroid/app/AlertDialog;

    iput-object p3, p0, Lp/Bi;->c:[Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final onShow(Landroid/content/DialogInterface;)V
    .locals 4

    .line 1
    sget-object p1, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 2
    .line 3
    iget-object p1, p0, Lp/Bi;->a:Lgringoxp/game/b;

    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Lp/Bi;->b:Landroid/app/AlertDialog;

    .line 9
    .line 10
    invoke-virtual {v0}, Landroid/app/AlertDialog;->getListView()Landroid/widget/ListView;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    new-instance v2, Lp/Ci;

    .line 15
    .line 16
    iget-object v3, p0, Lp/Bi;->c:[Ljava/lang/String;

    .line 17
    .line 18
    invoke-direct {v2, v0, p1, v3}, Lp/Ci;-><init>(Landroid/app/AlertDialog;Lgringoxp/game/b;[Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v1, v2}, Landroid/widget/AdapterView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 22
    .line 23
    .line 24
    return-void
.end method
