.class public final Lp/Qd;
.super Landroid/view/View;
.source "SourceFile"


# instance fields
.field public a:F

.field public b:F

.field public c:F

.field public d:Lp/g2;

.field public e:Landroid/graphics/Paint;


# virtual methods
.method public final a(I)I
    .locals 2

    .line 1
    int-to-float p1, p1

    .line 2
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    const/4 v1, 0x1

    .line 11
    invoke-static {v1, p1, v0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    float-to-int p1, p1

    .line 16
    return p1
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v7, p1

    .line 4
    .line 5
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    new-instance v3, Landroid/graphics/LinearGradient;

    .line 14
    .line 15
    int-to-float v6, v1

    .line 16
    iget v1, v0, Lp/Qd;->a:F

    .line 17
    .line 18
    const/high16 v16, 0x3f800000    # 1.0f

    .line 19
    .line 20
    const/4 v4, 0x3

    .line 21
    new-array v4, v4, [F

    .line 22
    .line 23
    const/4 v5, 0x0

    .line 24
    aput v1, v4, v5

    .line 25
    .line 26
    const/4 v1, 0x1

    .line 27
    aput v16, v4, v1

    .line 28
    .line 29
    const/4 v1, 0x2

    .line 30
    aput v16, v4, v1

    .line 31
    .line 32
    invoke-static {v4}, Landroid/graphics/Color;->HSVToColor([F)I

    .line 33
    .line 34
    .line 35
    move-result v14

    .line 36
    sget-object v24, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    .line 37
    .line 38
    const/4 v9, 0x0

    .line 39
    const/4 v10, 0x0

    .line 40
    const/4 v12, 0x0

    .line 41
    const/4 v13, -0x1

    .line 42
    move-object v8, v3

    .line 43
    move v11, v6

    .line 44
    move-object/from16 v15, v24

    .line 45
    .line 46
    invoke-direct/range {v8 .. v15}, Landroid/graphics/LinearGradient;-><init>(FFFFIILandroid/graphics/Shader$TileMode;)V

    .line 47
    .line 48
    .line 49
    new-instance v8, Landroid/graphics/LinearGradient;

    .line 50
    .line 51
    int-to-float v9, v2

    .line 52
    const/16 v22, 0x0

    .line 53
    .line 54
    const/high16 v23, -0x1000000

    .line 55
    .line 56
    const/16 v18, 0x0

    .line 57
    .line 58
    const/16 v19, 0x0

    .line 59
    .line 60
    const/16 v20, 0x0

    .line 61
    .line 62
    move-object/from16 v17, v8

    .line 63
    .line 64
    move/from16 v21, v9

    .line 65
    .line 66
    invoke-direct/range {v17 .. v24}, Landroid/graphics/LinearGradient;-><init>(FFFFIILandroid/graphics/Shader$TileMode;)V

    .line 67
    .line 68
    .line 69
    new-instance v10, Landroid/graphics/Paint;

    .line 70
    .line 71
    invoke-direct {v10}, Landroid/graphics/Paint;-><init>()V

    .line 72
    .line 73
    .line 74
    invoke-virtual {v10, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 75
    .line 76
    .line 77
    const/4 v2, 0x0

    .line 78
    const/4 v3, 0x0

    .line 79
    move-object/from16 v1, p1

    .line 80
    .line 81
    move v4, v6

    .line 82
    move v5, v9

    .line 83
    move-object v6, v10

    .line 84
    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v10, v8}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 88
    .line 89
    .line 90
    move v4, v11

    .line 91
    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 92
    .line 93
    .line 94
    iget v1, v0, Lp/Qd;->b:F

    .line 95
    .line 96
    mul-float/2addr v1, v11

    .line 97
    iget v2, v0, Lp/Qd;->c:F

    .line 98
    .line 99
    sub-float v16, v16, v2

    .line 100
    .line 101
    mul-float v2, v16, v9

    .line 102
    .line 103
    new-instance v3, Landroid/graphics/Paint;

    .line 104
    .line 105
    invoke-direct {v3}, Landroid/graphics/Paint;-><init>()V

    .line 106
    .line 107
    .line 108
    const/high16 v4, -0x1000000

    .line 109
    .line 110
    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 111
    .line 112
    .line 113
    const/16 v4, 0x50

    .line 114
    .line 115
    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 116
    .line 117
    .line 118
    const/4 v4, 0x7

    .line 119
    invoke-virtual {v0, v4}, Lp/Qd;->a(I)I

    .line 120
    .line 121
    .line 122
    move-result v4

    .line 123
    int-to-float v4, v4

    .line 124
    invoke-virtual {v7, v1, v2, v4, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 125
    .line 126
    .line 127
    const/4 v3, 0x6

    .line 128
    invoke-virtual {v0, v3}, Lp/Qd;->a(I)I

    .line 129
    .line 130
    .line 131
    move-result v3

    .line 132
    int-to-float v3, v3

    .line 133
    iget-object v4, v0, Lp/Qd;->e:Landroid/graphics/Paint;

    .line 134
    .line 135
    invoke-virtual {v7, v1, v2, v3, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 136
    .line 137
    .line 138
    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 6

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 7
    .line 8
    .line 9
    move-result v2

    .line 10
    int-to-float v2, v2

    .line 11
    div-float/2addr v1, v2

    .line 12
    const/high16 v2, 0x3f800000    # 1.0f

    .line 13
    .line 14
    invoke-static {v2, v1}, Ljava/lang/Math;->min(FF)F

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    const/4 v3, 0x0

    .line 19
    invoke-static {v3, v1}, Ljava/lang/Math;->max(FF)F

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    iput v1, p0, Lp/Qd;->b:F

    .line 24
    .line 25
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 26
    .line 27
    .line 28
    move-result p1

    .line 29
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    int-to-float v1, v1

    .line 34
    div-float/2addr p1, v1

    .line 35
    sub-float p1, v2, p1

    .line 36
    .line 37
    invoke-static {v2, p1}, Ljava/lang/Math;->min(FF)F

    .line 38
    .line 39
    .line 40
    move-result p1

    .line 41
    invoke-static {v3, p1}, Ljava/lang/Math;->max(FF)F

    .line 42
    .line 43
    .line 44
    move-result p1

    .line 45
    iput p1, p0, Lp/Qd;->c:F

    .line 46
    .line 47
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 48
    .line 49
    .line 50
    iget-object p1, p0, Lp/Qd;->d:Lp/g2;

    .line 51
    .line 52
    if-eqz p1, :cond_0

    .line 53
    .line 54
    iget v1, p0, Lp/Qd;->a:F

    .line 55
    .line 56
    iget v2, p0, Lp/Qd;->b:F

    .line 57
    .line 58
    iget v3, p0, Lp/Qd;->c:F

    .line 59
    .line 60
    const/4 v4, 0x3

    .line 61
    new-array v4, v4, [F

    .line 62
    .line 63
    const/4 v5, 0x0

    .line 64
    aput v1, v4, v5

    .line 65
    .line 66
    aput v2, v4, v0

    .line 67
    .line 68
    const/4 v1, 0x2

    .line 69
    aput v3, v4, v1

    .line 70
    .line 71
    invoke-static {v4}, Landroid/graphics/Color;->HSVToColor([F)I

    .line 72
    .line 73
    .line 74
    move-result v1

    .line 75
    invoke-virtual {p1, v1}, Lp/g2;->z(I)V

    .line 76
    .line 77
    .line 78
    :cond_0
    return v0
.end method

.method public setHue(F)V
    .locals 5

    .line 1
    iput p1, p0, Lp/Qd;->a:F

    .line 2
    .line 3
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Lp/Qd;->d:Lp/g2;

    .line 7
    .line 8
    if-eqz p1, :cond_0

    .line 9
    .line 10
    iget v0, p0, Lp/Qd;->a:F

    .line 11
    .line 12
    iget v1, p0, Lp/Qd;->b:F

    .line 13
    .line 14
    iget v2, p0, Lp/Qd;->c:F

    .line 15
    .line 16
    const/4 v3, 0x3

    .line 17
    new-array v3, v3, [F

    .line 18
    .line 19
    const/4 v4, 0x0

    .line 20
    aput v0, v3, v4

    .line 21
    .line 22
    const/4 v0, 0x1

    .line 23
    aput v1, v3, v0

    .line 24
    .line 25
    const/4 v0, 0x2

    .line 26
    aput v2, v3, v0

    .line 27
    .line 28
    invoke-static {v3}, Landroid/graphics/Color;->HSVToColor([F)I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    invoke-virtual {p1, v0}, Lp/g2;->z(I)V

    .line 33
    .line 34
    .line 35
    :cond_0
    return-void
.end method
