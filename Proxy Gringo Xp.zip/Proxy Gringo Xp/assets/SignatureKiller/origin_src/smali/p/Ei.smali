.class public final Lp/Ei;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:[Z

.field public final synthetic b:Lp/s1;

.field public final synthetic c:Landroid/widget/TextView;

.field public final synthetic d:Landroid/graphics/drawable/GradientDrawable;

.field public final synthetic e:Landroid/widget/LinearLayout;

.field public final synthetic f:Landroid/graphics/drawable/GradientDrawable;

.field public final synthetic g:Landroid/graphics/drawable/GradientDrawable;

.field public final synthetic h:Landroid/graphics/drawable/GradientDrawable;


# direct methods
.method public constructor <init>([ZLp/s1;Landroid/widget/TextView;Landroid/graphics/drawable/GradientDrawable;Landroid/widget/LinearLayout;Landroid/graphics/drawable/GradientDrawable;Landroid/graphics/drawable/GradientDrawable;Landroid/graphics/drawable/GradientDrawable;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lp/Ei;->a:[Z

    .line 5
    .line 6
    iput-object p2, p0, Lp/Ei;->b:Lp/s1;

    .line 7
    .line 8
    iput-object p3, p0, Lp/Ei;->c:Landroid/widget/TextView;

    .line 9
    .line 10
    iput-object p4, p0, Lp/Ei;->d:Landroid/graphics/drawable/GradientDrawable;

    .line 11
    .line 12
    iput-object p5, p0, Lp/Ei;->e:Landroid/widget/LinearLayout;

    .line 13
    .line 14
    iput-object p6, p0, Lp/Ei;->f:Landroid/graphics/drawable/GradientDrawable;

    .line 15
    .line 16
    iput-object p7, p0, Lp/Ei;->g:Landroid/graphics/drawable/GradientDrawable;

    .line 17
    .line 18
    iput-object p8, p0, Lp/Ei;->h:Landroid/graphics/drawable/GradientDrawable;

    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    .line 1
    iget-object p1, p0, Lp/Ei;->a:[Z

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    aget-boolean v1, p1, v0

    .line 5
    .line 6
    xor-int/lit8 v1, v1, 0x1

    .line 7
    .line 8
    aput-boolean v1, p1, v0

    .line 9
    .line 10
    iget-object v2, p0, Lp/Ei;->b:Lp/s1;

    .line 11
    .line 12
    invoke-virtual {v2, v0, v1}, Lp/s1;->a(IZ)V

    .line 13
    .line 14
    .line 15
    aget-boolean p1, p1, v0

    .line 16
    .line 17
    iget-object v0, p0, Lp/Ei;->e:Landroid/widget/LinearLayout;

    .line 18
    .line 19
    iget-object v1, p0, Lp/Ei;->c:Landroid/widget/TextView;

    .line 20
    .line 21
    if-eqz p1, :cond_0

    .line 22
    .line 23
    const-string p1, "ON"

    .line 24
    .line 25
    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 26
    .line 27
    .line 28
    iget-object p1, p0, Lp/Ei;->d:Landroid/graphics/drawable/GradientDrawable;

    .line 29
    .line 30
    invoke-virtual {v1, p1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 31
    .line 32
    .line 33
    iget-object p1, p0, Lp/Ei;->f:Landroid/graphics/drawable/GradientDrawable;

    .line 34
    .line 35
    invoke-virtual {v0, p1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 36
    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_0
    const-string p1, "OFF"

    .line 40
    .line 41
    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 42
    .line 43
    .line 44
    iget-object p1, p0, Lp/Ei;->g:Landroid/graphics/drawable/GradientDrawable;

    .line 45
    .line 46
    invoke-virtual {v1, p1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 47
    .line 48
    .line 49
    iget-object p1, p0, Lp/Ei;->h:Landroid/graphics/drawable/GradientDrawable;

    .line 50
    .line 51
    invoke-virtual {v0, p1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 52
    .line 53
    .line 54
    :goto_0
    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    const v1, 0x3f333333    # 0.7f

    .line 59
    .line 60
    .line 61
    invoke-virtual {p1, v1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    const-wide/16 v1, 0x50

    .line 66
    .line 67
    invoke-virtual {p1, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    new-instance v1, Lp/i0;

    .line 72
    .line 73
    const/16 v2, 0x10

    .line 74
    .line 75
    invoke-direct {v1, v2, v0}, Lp/i0;-><init>(ILjava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    invoke-virtual {p1, v1}, Landroid/view/ViewPropertyAnimator;->withEndAction(Ljava/lang/Runnable;)Landroid/view/ViewPropertyAnimator;

    .line 79
    .line 80
    .line 81
    return-void
.end method
