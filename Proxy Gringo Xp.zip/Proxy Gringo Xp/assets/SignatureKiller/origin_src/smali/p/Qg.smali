.class public final synthetic Lp/Qg;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lp/Jb;


# virtual methods
.method public final a(Lp/y4;)Lp/y4;
    .locals 0

    .line 1
    return-object p1
.end method
