.class public final Lp/Ob;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# instance fields
.field public final synthetic a:I

.field public b:F

.field public c:F

.field public d:I

.field public e:I

.field public final f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/view/WindowManager$LayoutParams;Landroid/graphics/drawable/GradientDrawable;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Lp/Ob;->a:I

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lp/Ob;->f:Ljava/lang/Object;

    iput-object p2, p0, Lp/Ob;->g:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lp/Pb;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Lp/Ob;->a:I

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lp/Ob;->g:Ljava/lang/Object;

    .line 2
    new-instance v0, Lp/Bc;

    iget-object p1, p1, Lp/Pb;->y:Lp/Ub;

    .line 3
    iget-object p1, p1, Lp/Ub;->a:Lgringoxp/game/b;

    .line 4
    invoke-static {p1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result p1

    int-to-float p1, p1

    invoke-direct {v0, p1}, Lp/Bc;-><init>(F)V

    iput-object v0, p0, Lp/Ob;->f:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 7

    .line 1
    const/high16 p1, 0x3f800000    # 1.0f

    .line 2
    .line 3
    iget-object v0, p0, Lp/Ob;->g:Ljava/lang/Object;

    .line 4
    .line 5
    const/4 v1, 0x2

    .line 6
    const/4 v2, 0x0

    .line 7
    const/4 v3, 0x1

    .line 8
    iget-object v4, p0, Lp/Ob;->f:Ljava/lang/Object;

    .line 9
    .line 10
    const/16 v5, 0x8

    .line 11
    .line 12
    iget v6, p0, Lp/Ob;->a:I

    .line 13
    .line 14
    packed-switch v6, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    .line 18
    .line 19
    .line 20
    move-result v6

    .line 21
    check-cast v4, Landroid/view/WindowManager$LayoutParams;

    .line 22
    .line 23
    if-eqz v6, :cond_4

    .line 24
    .line 25
    if-eq v6, v3, :cond_1

    .line 26
    .line 27
    if-eq v6, v1, :cond_0

    .line 28
    .line 29
    goto/16 :goto_2

    .line 30
    .line 31
    :cond_0
    iget p1, p0, Lp/Ob;->d:I

    .line 32
    .line 33
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    iget v1, p0, Lp/Ob;->b:F

    .line 38
    .line 39
    sub-float/2addr v0, v1

    .line 40
    float-to-int v0, v0

    .line 41
    add-int/2addr p1, v0

    .line 42
    iput p1, v4, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 43
    .line 44
    iget p1, p0, Lp/Ob;->e:I

    .line 45
    .line 46
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    .line 47
    .line 48
    .line 49
    move-result p2

    .line 50
    iget v0, p0, Lp/Ob;->c:F

    .line 51
    .line 52
    sub-float/2addr p2, v0

    .line 53
    float-to-int p2, p2

    .line 54
    add-int/2addr p1, p2

    .line 55
    iput p1, v4, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 56
    .line 57
    sget-object p1, Lgringoxp/game/b;->e:Landroid/view/WindowManager;

    .line 58
    .line 59
    sget-object p2, Lgringoxp/game/b;->g:Landroid/widget/LinearLayout;

    .line 60
    .line 61
    invoke-interface {p1, p2, v4}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 62
    .line 63
    .line 64
    :goto_0
    move v2, v3

    .line 65
    goto :goto_2

    .line 66
    :cond_1
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    .line 67
    .line 68
    .line 69
    move-result v1

    .line 70
    iget v4, p0, Lp/Ob;->b:F

    .line 71
    .line 72
    sub-float/2addr v1, v4

    .line 73
    float-to-int v1, v1

    .line 74
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    .line 75
    .line 76
    .line 77
    move-result p2

    .line 78
    iget v4, p0, Lp/Ob;->c:F

    .line 79
    .line 80
    sub-float/2addr p2, v4

    .line 81
    float-to-int p2, p2

    .line 82
    const/16 v4, 0xa

    .line 83
    .line 84
    if-ge v1, v4, :cond_3

    .line 85
    .line 86
    if-ge p2, v4, :cond_3

    .line 87
    .line 88
    sget-object p2, Lgringoxp/game/b;->f:Landroid/widget/FrameLayout;

    .line 89
    .line 90
    invoke-virtual {p2}, Landroid/view/View;->getVisibility()I

    .line 91
    .line 92
    .line 93
    move-result p2

    .line 94
    check-cast v0, Landroid/graphics/drawable/GradientDrawable;

    .line 95
    .line 96
    if-nez p2, :cond_2

    .line 97
    .line 98
    new-array p2, v5, [F

    .line 99
    .line 100
    fill-array-data p2, :array_0

    .line 101
    .line 102
    .line 103
    invoke-virtual {v0, p2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 104
    .line 105
    .line 106
    sget-object p2, Lgringoxp/game/b;->f:Landroid/widget/FrameLayout;

    .line 107
    .line 108
    invoke-virtual {p2, v5}, Landroid/view/View;->setVisibility(I)V

    .line 109
    .line 110
    .line 111
    goto :goto_1

    .line 112
    :cond_2
    new-array p2, v5, [F

    .line 113
    .line 114
    fill-array-data p2, :array_1

    .line 115
    .line 116
    .line 117
    invoke-virtual {v0, p2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 118
    .line 119
    .line 120
    sget-object p2, Lgringoxp/game/b;->f:Landroid/widget/FrameLayout;

    .line 121
    .line 122
    invoke-virtual {p2, v2}, Landroid/view/View;->setVisibility(I)V

    .line 123
    .line 124
    .line 125
    :cond_3
    :goto_1
    sget-object p2, Lgringoxp/game/b;->g:Landroid/widget/LinearLayout;

    .line 126
    .line 127
    invoke-virtual {p2, p1}, Landroid/view/View;->setAlpha(F)V

    .line 128
    .line 129
    .line 130
    goto :goto_0

    .line 131
    :cond_4
    iget p1, v4, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 132
    .line 133
    iput p1, p0, Lp/Ob;->d:I

    .line 134
    .line 135
    iget p1, v4, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 136
    .line 137
    iput p1, p0, Lp/Ob;->e:I

    .line 138
    .line 139
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    .line 140
    .line 141
    .line 142
    move-result p1

    .line 143
    iput p1, p0, Lp/Ob;->b:F

    .line 144
    .line 145
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    .line 146
    .line 147
    .line 148
    move-result p1

    .line 149
    iput p1, p0, Lp/Ob;->c:F

    .line 150
    .line 151
    sget-object p1, Lgringoxp/game/b;->g:Landroid/widget/LinearLayout;

    .line 152
    .line 153
    const/high16 p2, 0x3f000000    # 0.5f

    .line 154
    .line 155
    invoke-virtual {p1, p2}, Landroid/view/View;->setAlpha(F)V

    .line 156
    .line 157
    .line 158
    goto :goto_0

    .line 159
    :goto_2
    return v2

    .line 160
    :pswitch_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 161
    .line 162
    .line 163
    move-result v5

    .line 164
    check-cast v4, Lp/Bc;

    .line 165
    .line 166
    check-cast v0, Lp/Pb;

    .line 167
    .line 168
    if-eqz v5, :cond_a

    .line 169
    .line 170
    if-eq v5, v3, :cond_7

    .line 171
    .line 172
    if-eq v5, v1, :cond_6

    .line 173
    .line 174
    const/4 p2, 0x3

    .line 175
    if-eq v5, p2, :cond_5

    .line 176
    .line 177
    const/4 p2, 0x5

    .line 178
    if-eq v5, p2, :cond_5

    .line 179
    .line 180
    goto/16 :goto_4

    .line 181
    .line 182
    :cond_5
    iput-boolean v2, v4, Lp/Bc;->d:Z

    .line 183
    .line 184
    iget-object p2, v0, Lp/Pb;->s:Lp/Sb;

    .line 185
    .line 186
    invoke-virtual {p2, p1}, Landroid/view/View;->setAlpha(F)V

    .line 187
    .line 188
    .line 189
    goto/16 :goto_4

    .line 190
    .line 191
    :cond_6
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    .line 192
    .line 193
    .line 194
    move-result p1

    .line 195
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    .line 196
    .line 197
    .line 198
    move-result v1

    .line 199
    invoke-virtual {v4, p1, v1}, Lp/Bc;->a(FF)Z

    .line 200
    .line 201
    .line 202
    move-result p1

    .line 203
    if-eqz p1, :cond_b

    .line 204
    .line 205
    iget-object p1, v0, Lp/Pb;->t:Landroid/view/WindowManager$LayoutParams;

    .line 206
    .line 207
    iget v1, p0, Lp/Ob;->d:I

    .line 208
    .line 209
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    .line 210
    .line 211
    .line 212
    move-result v2

    .line 213
    iget v4, p0, Lp/Ob;->b:F

    .line 214
    .line 215
    sub-float/2addr v2, v4

    .line 216
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    .line 217
    .line 218
    .line 219
    move-result v2

    .line 220
    add-int/2addr v2, v1

    .line 221
    iput v2, p1, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 222
    .line 223
    iget-object p1, v0, Lp/Pb;->t:Landroid/view/WindowManager$LayoutParams;

    .line 224
    .line 225
    iget v1, p0, Lp/Ob;->e:I

    .line 226
    .line 227
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    .line 228
    .line 229
    .line 230
    move-result p2

    .line 231
    iget v2, p0, Lp/Ob;->c:F

    .line 232
    .line 233
    sub-float/2addr p2, v2

    .line 234
    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    .line 235
    .line 236
    .line 237
    move-result p2

    .line 238
    add-int/2addr p2, v1

    .line 239
    iput p2, p1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 240
    .line 241
    invoke-virtual {v0}, Lp/Pb;->c()V

    .line 242
    .line 243
    .line 244
    goto/16 :goto_4

    .line 245
    .line 246
    :cond_7
    iget-object v1, v0, Lp/Pb;->s:Lp/Sb;

    .line 247
    .line 248
    invoke-virtual {v1, p1}, Landroid/view/View;->setAlpha(F)V

    .line 249
    .line 250
    .line 251
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    .line 252
    .line 253
    .line 254
    move-result p1

    .line 255
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    .line 256
    .line 257
    .line 258
    move-result p2

    .line 259
    iget-boolean v1, v4, Lp/Bc;->d:Z

    .line 260
    .line 261
    if-nez v1, :cond_8

    .line 262
    .line 263
    goto :goto_3

    .line 264
    :cond_8
    invoke-virtual {v4, p1, p2}, Lp/Bc;->a(FF)Z

    .line 265
    .line 266
    .line 267
    iget-boolean p1, v4, Lp/Bc;->e:Z

    .line 268
    .line 269
    xor-int/2addr p1, v3

    .line 270
    iput-boolean v2, v4, Lp/Bc;->d:Z

    .line 271
    .line 272
    move v2, p1

    .line 273
    :goto_3
    if-eqz v2, :cond_9

    .line 274
    .line 275
    iget-object p1, v0, Lp/Pb;->s:Lp/Sb;

    .line 276
    .line 277
    invoke-virtual {p1}, Landroid/view/View;->performClick()Z

    .line 278
    .line 279
    .line 280
    goto :goto_4

    .line 281
    :cond_9
    iget-object p1, v0, Lp/Pb;->y:Lp/Ub;

    .line 282
    .line 283
    iget-object p1, p1, Lp/Ub;->d:Landroid/content/SharedPreferences;

    .line 284
    .line 285
    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 286
    .line 287
    .line 288
    move-result-object p1

    .line 289
    iget-object p2, v0, Lp/Pb;->b:Ljava/lang/String;

    .line 290
    .line 291
    const-string v1, "_x"

    .line 292
    .line 293
    invoke-virtual {p2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 294
    .line 295
    .line 296
    move-result-object v1

    .line 297
    iget-object v0, v0, Lp/Pb;->t:Landroid/view/WindowManager$LayoutParams;

    .line 298
    .line 299
    iget v2, v0, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 300
    .line 301
    invoke-interface {p1, v1, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 302
    .line 303
    .line 304
    move-result-object p1

    .line 305
    const-string v1, "_y"

    .line 306
    .line 307
    invoke-virtual {p2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 308
    .line 309
    .line 310
    move-result-object p2

    .line 311
    iget v0, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 312
    .line 313
    invoke-interface {p1, p2, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 314
    .line 315
    .line 316
    move-result-object p1

    .line 317
    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 318
    .line 319
    .line 320
    goto :goto_4

    .line 321
    :cond_a
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    .line 322
    .line 323
    .line 324
    move-result p1

    .line 325
    iput p1, p0, Lp/Ob;->b:F

    .line 326
    .line 327
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    .line 328
    .line 329
    .line 330
    move-result p1

    .line 331
    iput p1, p0, Lp/Ob;->c:F

    .line 332
    .line 333
    iget-object p2, v0, Lp/Pb;->t:Landroid/view/WindowManager$LayoutParams;

    .line 334
    .line 335
    iget v1, p2, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 336
    .line 337
    iput v1, p0, Lp/Ob;->d:I

    .line 338
    .line 339
    iget p2, p2, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 340
    .line 341
    iput p2, p0, Lp/Ob;->e:I

    .line 342
    .line 343
    iget p2, p0, Lp/Ob;->b:F

    .line 344
    .line 345
    iput p2, v4, Lp/Bc;->b:F

    .line 346
    .line 347
    iput p1, v4, Lp/Bc;->c:F

    .line 348
    .line 349
    iput-boolean v2, v4, Lp/Bc;->e:Z

    .line 350
    .line 351
    iput-boolean v3, v4, Lp/Bc;->d:Z

    .line 352
    .line 353
    iget-object p1, v0, Lp/Pb;->s:Lp/Sb;

    .line 354
    .line 355
    const p2, 0x3f47ae14    # 0.78f

    .line 356
    .line 357
    .line 358
    invoke-virtual {p1, p2}, Landroid/view/View;->setAlpha(F)V

    .line 359
    .line 360
    .line 361
    :cond_b
    :goto_4
    return v3

    .line 362
    nop

    .line 363
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch

    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x41200000    # 10.0f
        0x41200000    # 10.0f
        0x41200000    # 10.0f
        0x41200000    # 10.0f
    .end array-data

    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    :array_1
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method
