.class public final Lp/P;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, Lp/P;->a:I

    iput-object p2, p0, Lp/P;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    .line 1
    iget v0, p0, Lp/P;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    const/4 v0, 0x1

    .line 8
    iget-object v1, p0, Lp/P;->b:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Lp/s1;

    .line 11
    .line 12
    invoke-virtual {v1, p1, v0}, Lp/s1;->a(IZ)V

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :pswitch_0
    iget-object p1, p0, Lp/P;->b:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p1, Landroidx/appcompat/widget/Toolbar;

    .line 19
    .line 20
    iget-object p1, p1, Landroidx/appcompat/widget/Toolbar;->L:Lp/Ef;

    .line 21
    .line 22
    if-nez p1, :cond_0

    .line 23
    .line 24
    const/4 p1, 0x0

    .line 25
    goto :goto_0

    .line 26
    :cond_0
    iget-object p1, p1, Lp/Ef;->b:Lp/Ka;

    .line 27
    .line 28
    :goto_0
    if-eqz p1, :cond_1

    .line 29
    .line 30
    invoke-virtual {p1}, Lp/Ka;->collapseActionView()Z

    .line 31
    .line 32
    .line 33
    :cond_1
    return-void

    .line 34
    :pswitch_1
    iget-object p1, p0, Lp/P;->b:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast p1, Lp/ra;

    .line 37
    .line 38
    iget v0, p1, Lp/ra;->X:I

    .line 39
    .line 40
    const/4 v1, 0x2

    .line 41
    const/4 v2, 0x1

    .line 42
    if-ne v0, v1, :cond_2

    .line 43
    .line 44
    invoke-virtual {p1, v2}, Lp/ra;->H(I)V

    .line 45
    .line 46
    .line 47
    goto :goto_1

    .line 48
    :cond_2
    if-ne v0, v2, :cond_3

    .line 49
    .line 50
    invoke-virtual {p1, v1}, Lp/ra;->H(I)V

    .line 51
    .line 52
    .line 53
    :cond_3
    :goto_1
    return-void

    .line 54
    :pswitch_2
    iget-object v0, p0, Lp/P;->b:Ljava/lang/Object;

    .line 55
    .line 56
    check-cast v0, Lp/w0;

    .line 57
    .line 58
    iget-object v1, v0, Lp/w0;->h:Landroid/widget/Button;

    .line 59
    .line 60
    iget-object v1, v0, Lp/w0;->i:Landroid/widget/Button;

    .line 61
    .line 62
    if-ne p1, v1, :cond_4

    .line 63
    .line 64
    iget-object p1, v0, Lp/w0;->k:Landroid/os/Message;

    .line 65
    .line 66
    if-eqz p1, :cond_4

    .line 67
    .line 68
    invoke-static {p1}, Landroid/os/Message;->obtain(Landroid/os/Message;)Landroid/os/Message;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    goto :goto_2

    .line 73
    :cond_4
    iget-object p1, v0, Lp/w0;->l:Landroid/widget/Button;

    .line 74
    .line 75
    const/4 p1, 0x0

    .line 76
    :goto_2
    if-eqz p1, :cond_5

    .line 77
    .line 78
    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    .line 79
    .line 80
    .line 81
    :cond_5
    iget-object p1, v0, Lp/w0;->z:Lp/u0;

    .line 82
    .line 83
    const/4 v1, 0x1

    .line 84
    iget-object v0, v0, Lp/w0;->b:Lp/y0;

    .line 85
    .line 86
    invoke-virtual {p1, v1, v0}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    .line 87
    .line 88
    .line 89
    move-result-object p1

    .line 90
    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    .line 91
    .line 92
    .line 93
    return-void

    .line 94
    :pswitch_3
    iget-object p1, p0, Lp/P;->b:Ljava/lang/Object;

    .line 95
    .line 96
    check-cast p1, Lp/h0;

    .line 97
    .line 98
    invoke-virtual {p1}, Lp/h0;->a()V

    .line 99
    .line 100
    .line 101
    return-void

    .line 102
    nop

    .line 103
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
