.class public final Lp/L7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lp/s8;
.implements Lp/Wd;
.implements Lp/sh;


# instance fields
.field public final a:Lp/m7;

.field public final b:Lp/rh;

.field public c:Landroidx/lifecycle/a;

.field public d:Lp/M7;


# direct methods
.method public constructor <init>(Lp/m7;Lp/rh;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, Lp/L7;->c:Landroidx/lifecycle/a;

    .line 6
    .line 7
    iput-object v0, p0, Lp/L7;->d:Lp/M7;

    .line 8
    .line 9
    iput-object p1, p0, Lp/L7;->a:Lp/m7;

    .line 10
    .line 11
    iput-object p2, p0, Lp/L7;->b:Lp/rh;

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final a()Lp/nb;
    .locals 5

    .line 1
    iget-object v0, p0, Lp/L7;->a:Lp/m7;

    .line 2
    .line 3
    invoke-virtual {v0}, Lp/m7;->B()Landroid/content/Context;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    :goto_0
    instance-of v2, v1, Landroid/content/ContextWrapper;

    .line 12
    .line 13
    if-eqz v2, :cond_1

    .line 14
    .line 15
    instance-of v2, v1, Landroid/app/Application;

    .line 16
    .line 17
    if-eqz v2, :cond_0

    .line 18
    .line 19
    check-cast v1, Landroid/app/Application;

    .line 20
    .line 21
    goto :goto_1

    .line 22
    :cond_0
    check-cast v1, Landroid/content/ContextWrapper;

    .line 23
    .line 24
    invoke-virtual {v1}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    goto :goto_0

    .line 29
    :cond_1
    const/4 v1, 0x0

    .line 30
    :goto_1
    new-instance v2, Lp/nb;

    .line 31
    .line 32
    invoke-direct {v2}, Lp/nb;-><init>()V

    .line 33
    .line 34
    .line 35
    iget-object v3, v2, Lp/M4;->a:Ljava/util/LinkedHashMap;

    .line 36
    .line 37
    if-eqz v1, :cond_2

    .line 38
    .line 39
    sget-object v4, Lp/U5;->e:Lp/U5;

    .line 40
    .line 41
    invoke-interface {v3, v4, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    :cond_2
    sget-object v1, Lp/Z9;->l:Lp/U5;

    .line 45
    .line 46
    invoke-interface {v3, v1, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    sget-object v1, Lp/Z9;->m:Lp/U5;

    .line 50
    .line 51
    invoke-interface {v3, v1, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    iget-object v0, v0, Lp/m7;->f:Landroid/os/Bundle;

    .line 55
    .line 56
    if-eqz v0, :cond_3

    .line 57
    .line 58
    sget-object v1, Lp/Z9;->n:Lp/U5;

    .line 59
    .line 60
    invoke-interface {v3, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    :cond_3
    return-object v2
.end method

.method public final b()Lp/P0;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lp/L7;->f()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lp/L7;->d:Lp/M7;

    .line 5
    .line 6
    iget-object v0, v0, Lp/M7;->c:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lp/P0;

    .line 9
    .line 10
    return-object v0
.end method

.method public final c()Lp/rh;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lp/L7;->f()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lp/L7;->b:Lp/rh;

    .line 5
    .line 6
    return-object v0
.end method

.method public final d()Landroidx/lifecycle/a;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lp/L7;->f()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lp/L7;->c:Landroidx/lifecycle/a;

    .line 5
    .line 6
    return-object v0
.end method

.method public final e(Lp/a9;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lp/L7;->c:Landroidx/lifecycle/a;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Landroidx/lifecycle/a;->d(Lp/a9;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final f()V
    .locals 1

    .line 1
    iget-object v0, p0, Lp/L7;->c:Landroidx/lifecycle/a;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Landroidx/lifecycle/a;

    .line 6
    .line 7
    invoke-direct {v0, p0}, Landroidx/lifecycle/a;-><init>(Lp/g9;)V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lp/L7;->c:Landroidx/lifecycle/a;

    .line 11
    .line 12
    new-instance v0, Lp/M7;

    .line 13
    .line 14
    invoke-direct {v0, p0}, Lp/M7;-><init>(Lp/Wd;)V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, Lp/L7;->d:Lp/M7;

    .line 18
    .line 19
    invoke-virtual {v0}, Lp/M7;->a()V

    .line 20
    .line 21
    .line 22
    invoke-static {p0}, Lp/Z9;->k(Lp/Wd;)V

    .line 23
    .line 24
    .line 25
    :cond_0
    return-void
.end method
