.class public interface abstract Lp/M0;
.super Ljava/lang/Object;
.source "SourceFile"
