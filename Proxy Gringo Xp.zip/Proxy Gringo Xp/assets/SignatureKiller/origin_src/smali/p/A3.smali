.class public interface abstract Lp/A3;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Ljava/lang/Class;
.end method
