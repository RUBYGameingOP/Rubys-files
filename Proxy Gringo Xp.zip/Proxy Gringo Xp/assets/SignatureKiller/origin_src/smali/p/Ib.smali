.class public interface abstract Lp/Ib;
.super Ljava/lang/Object;
.source "SourceFile"
