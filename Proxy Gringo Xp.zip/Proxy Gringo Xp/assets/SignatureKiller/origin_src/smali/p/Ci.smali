.class public final synthetic Lp/Ci;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# instance fields
.field public final synthetic a:Lgringoxp/game/b;

.field public final synthetic b:[Ljava/lang/String;

.field public final synthetic c:Landroid/app/AlertDialog;


# direct methods
.method public synthetic constructor <init>(Landroid/app/AlertDialog;Lgringoxp/game/b;[Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lp/Ci;->a:Lgringoxp/game/b;

    iput-object p3, p0, Lp/Ci;->b:[Ljava/lang/String;

    iput-object p1, p0, Lp/Ci;->c:Landroid/app/AlertDialog;

    return-void
.end method


# virtual methods
.method public final onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 6

    .line 1
    iget-object v0, p0, Lp/Ci;->a:Lgringoxp/game/b;

    .line 2
    .line 3
    iget-object p1, p0, Lp/Ci;->b:[Ljava/lang/String;

    .line 4
    .line 5
    iget-object p2, p0, Lp/Ci;->c:Landroid/app/AlertDialog;

    .line 6
    .line 7
    sget-object p4, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    aget-object p1, p1, p3

    .line 13
    .line 14
    const-string p3, "AUTO"

    .line 15
    .line 16
    if-eqz p1, :cond_2

    .line 17
    .line 18
    sget-object p4, Lp/Uf;->a:Ljava/util/concurrent/ConcurrentHashMap;

    .line 19
    .line 20
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    .line 21
    .line 22
    .line 23
    move-result p4

    .line 24
    if-nez p4, :cond_2

    .line 25
    .line 26
    invoke-virtual {p3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result p4

    .line 30
    if-eqz p4, :cond_0

    .line 31
    .line 32
    goto :goto_1

    .line 33
    :cond_0
    sget-object p4, Lp/Uf;->a:Ljava/util/concurrent/ConcurrentHashMap;

    .line 34
    .line 35
    invoke-virtual {p4, p1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p4

    .line 39
    check-cast p4, Lp/Tf;

    .line 40
    .line 41
    if-eqz p4, :cond_1

    .line 42
    .line 43
    const-string p5, "UDP"

    .line 44
    .line 45
    iget-object p4, p4, Lp/Tf;->b:Ljava/lang/String;

    .line 46
    .line 47
    invoke-virtual {p5, p4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result p4

    .line 51
    if-eqz p4, :cond_1

    .line 52
    .line 53
    goto :goto_0

    .line 54
    :cond_1
    move-object p1, p3

    .line 55
    :goto_0
    sput-object p1, Lp/Uf;->b:Ljava/lang/String;

    .line 56
    .line 57
    goto :goto_2

    .line 58
    :cond_2
    :goto_1
    sput-object p3, Lp/Uf;->b:Ljava/lang/String;

    .line 59
    .line 60
    :goto_2
    sget-object v1, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 61
    .line 62
    const/16 v2, 0x1d

    .line 63
    .line 64
    const/4 v3, 0x0

    .line 65
    const/4 v4, 0x0

    .line 66
    const-string v5, ""

    .line 67
    .line 68
    invoke-virtual/range {v0 .. v5}, Lgringoxp/game/b;->Cases(Landroid/content/Context;IIZLjava/lang/String;)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {p2}, Landroid/app/Dialog;->dismiss()V

    .line 72
    .line 73
    .line 74
    return-void
.end method
