.class public abstract Lp/M;
.super Lp/Z9;
.source "SourceFile"
