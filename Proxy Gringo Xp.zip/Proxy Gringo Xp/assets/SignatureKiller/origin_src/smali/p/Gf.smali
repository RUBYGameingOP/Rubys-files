.class public interface abstract Lp/Gf;
.super Ljava/lang/Object;
.source "SourceFile"
