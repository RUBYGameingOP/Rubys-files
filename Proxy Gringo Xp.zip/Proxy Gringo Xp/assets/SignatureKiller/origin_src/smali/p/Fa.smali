.class public interface abstract Lp/Fa;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b(Lp/Ka;)Z
.end method
