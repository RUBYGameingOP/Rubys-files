.class public interface abstract Lp/Ja;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract k(Lp/Ga;Lp/Ka;)V
.end method

.method public abstract r(Lp/Ga;Lp/Ka;)V
.end method
