.class public final Lp/K7;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:I

.field public b:Lp/m7;

.field public c:Z

.field public d:I

.field public e:I

.field public f:I

.field public g:I

.field public h:Lp/b9;

.field public i:Lp/b9;


# direct methods
.method public constructor <init>(ILp/m7;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput p1, p0, Lp/K7;->a:I

    .line 3
    iput-object p2, p0, Lp/K7;->b:Lp/m7;

    const/4 p1, 0x0

    .line 4
    iput-boolean p1, p0, Lp/K7;->c:Z

    .line 5
    sget-object p1, Lp/b9;->e:Lp/b9;

    iput-object p1, p0, Lp/K7;->h:Lp/b9;

    .line 6
    iput-object p1, p0, Lp/K7;->i:Lp/b9;

    return-void
.end method

.method public constructor <init>(ILp/m7;I)V
    .locals 0

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    iput p1, p0, Lp/K7;->a:I

    .line 9
    iput-object p2, p0, Lp/K7;->b:Lp/m7;

    const/4 p1, 0x1

    .line 10
    iput-boolean p1, p0, Lp/K7;->c:Z

    .line 11
    sget-object p1, Lp/b9;->e:Lp/b9;

    iput-object p1, p0, Lp/K7;->h:Lp/b9;

    .line 12
    iput-object p1, p0, Lp/K7;->i:Lp/b9;

    return-void
.end method
