.class public abstract Lp/Ne;
.super Lp/mc;
.source "SourceFile"
