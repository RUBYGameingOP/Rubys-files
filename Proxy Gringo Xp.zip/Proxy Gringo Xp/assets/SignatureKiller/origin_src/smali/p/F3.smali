.class public final synthetic Lp/F3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, Lp/F3;->a:I

    iput-object p2, p0, Lp/F3;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 12

    .line 1
    const/4 p1, 0x0

    .line 2
    iget v0, p0, Lp/F3;->a:I

    .line 3
    .line 4
    packed-switch v0, :pswitch_data_0

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lp/F3;->b:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, Lgringoxp/game/b;

    .line 10
    .line 11
    sget-object v1, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    const-string v1, "UDP"

    .line 17
    .line 18
    invoke-static {v1}, Lp/Uf;->b(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    add-int/lit8 v2, v2, 0x1

    .line 27
    .line 28
    new-array v2, v2, [Ljava/lang/String;

    .line 29
    .line 30
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    add-int/lit8 v3, v3, 0x1

    .line 35
    .line 36
    new-array v3, v3, [Ljava/lang/String;

    .line 37
    .line 38
    const-string v4, "Autom\u00e1tico (padr\u00e3o atual)"

    .line 39
    .line 40
    const/4 v5, 0x0

    .line 41
    aput-object v4, v2, v5

    .line 42
    .line 43
    const-string v4, "AUTO"

    .line 44
    .line 45
    aput-object v4, v3, v5

    .line 46
    .line 47
    :goto_0
    move v4, v5

    .line 48
    :cond_0
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 49
    .line 50
    .line 51
    move-result v6

    .line 52
    if-ge v5, v6, :cond_1

    .line 53
    .line 54
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v6

    .line 58
    check-cast v6, Lp/Sf;

    .line 59
    .line 60
    add-int/lit8 v5, v5, 0x1

    .line 61
    .line 62
    new-instance v7, Ljava/lang/StringBuilder;

    .line 63
    .line 64
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 65
    .line 66
    .line 67
    iget-object v8, v6, Lp/Sf;->b:Ljava/lang/String;

    .line 68
    .line 69
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 70
    .line 71
    .line 72
    const-string v8, "  "

    .line 73
    .line 74
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 75
    .line 76
    .line 77
    iget-object v8, v6, Lp/Sf;->c:Ljava/lang/String;

    .line 78
    .line 79
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 80
    .line 81
    .line 82
    const-string v8, "\nida/volta "

    .line 83
    .line 84
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 85
    .line 86
    .line 87
    iget-wide v8, v6, Lp/Sf;->d:J

    .line 88
    .line 89
    invoke-virtual {v7, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 90
    .line 91
    .line 92
    const-string v8, "/"

    .line 93
    .line 94
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 95
    .line 96
    .line 97
    iget-wide v8, v6, Lp/Sf;->e:J

    .line 98
    .line 99
    invoke-virtual {v7, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 100
    .line 101
    .line 102
    const-string v8, " \u2022 "

    .line 103
    .line 104
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 105
    .line 106
    .line 107
    iget-wide v8, v6, Lp/Sf;->f:J

    .line 108
    .line 109
    iget-wide v10, v6, Lp/Sf;->g:J

    .line 110
    .line 111
    add-long/2addr v8, v10

    .line 112
    const-wide/16 v10, 0x400

    .line 113
    .line 114
    div-long/2addr v8, v10

    .line 115
    invoke-virtual {v7, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 116
    .line 117
    .line 118
    const-string v8, " KiB"

    .line 119
    .line 120
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 121
    .line 122
    .line 123
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object v7

    .line 127
    aput-object v7, v2, v5

    .line 128
    .line 129
    iget-object v6, v6, Lp/Sf;->a:Ljava/lang/String;

    .line 130
    .line 131
    aput-object v6, v3, v5

    .line 132
    .line 133
    sget-object v7, Lp/Uf;->b:Ljava/lang/String;

    .line 134
    .line 135
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 136
    .line 137
    .line 138
    move-result v6

    .line 139
    if-eqz v6, :cond_0

    .line 140
    .line 141
    goto :goto_0

    .line 142
    :cond_1
    new-instance v1, Landroid/app/AlertDialog$Builder;

    .line 143
    .line 144
    sget-object v5, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 145
    .line 146
    invoke-direct {v1, v5}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 147
    .line 148
    .line 149
    const-string v5, "Escolher servidor UDP"

    .line 150
    .line 151
    invoke-virtual {v1, v5}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 152
    .line 153
    .line 154
    move-result-object v1

    .line 155
    invoke-virtual {v1, v2, v4, p1}, Landroid/app/AlertDialog$Builder;->setSingleChoiceItems([Ljava/lang/CharSequence;ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 156
    .line 157
    .line 158
    move-result-object v1

    .line 159
    const-string v2, "Cancelar"

    .line 160
    .line 161
    invoke-virtual {v1, v2, p1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 162
    .line 163
    .line 164
    move-result-object p1

    .line 165
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    .line 166
    .line 167
    .line 168
    move-result-object p1

    .line 169
    new-instance v1, Lp/Bi;

    .line 170
    .line 171
    invoke-direct {v1, p1, v0, v3}, Lp/Bi;-><init>(Landroid/app/AlertDialog;Lgringoxp/game/b;[Ljava/lang/String;)V

    .line 172
    .line 173
    .line 174
    invoke-virtual {p1, v1}, Landroid/app/Dialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    .line 175
    .line 176
    .line 177
    invoke-virtual {p1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 178
    .line 179
    .line 180
    move-result-object v0

    .line 181
    if-eqz v0, :cond_3

    .line 182
    .line 183
    invoke-virtual {p1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 184
    .line 185
    .line 186
    move-result-object v0

    .line 187
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 188
    .line 189
    const/16 v2, 0x1a

    .line 190
    .line 191
    if-lt v1, v2, :cond_2

    .line 192
    .line 193
    const/16 v1, 0x7f6

    .line 194
    .line 195
    goto :goto_1

    .line 196
    :cond_2
    const/16 v1, 0x7d2

    .line 197
    .line 198
    :goto_1
    invoke-virtual {v0, v1}, Landroid/view/Window;->setType(I)V

    .line 199
    .line 200
    .line 201
    :cond_3
    invoke-virtual {p1}, Landroid/app/Dialog;->show()V

    .line 202
    .line 203
    .line 204
    return-void

    .line 205
    :pswitch_0
    iget-object v0, p0, Lp/F3;->b:Ljava/lang/Object;

    .line 206
    .line 207
    check-cast v0, Lp/Zb;

    .line 208
    .line 209
    iget-object v1, v0, Lp/Zb;->f:Landroid/widget/EditText;

    .line 210
    .line 211
    if-nez v1, :cond_4

    .line 212
    .line 213
    goto :goto_3

    .line 214
    :cond_4
    invoke-virtual {v1}, Landroid/widget/TextView;->getSelectionEnd()I

    .line 215
    .line 216
    .line 217
    move-result v1

    .line 218
    iget-object v2, v0, Lp/Zb;->f:Landroid/widget/EditText;

    .line 219
    .line 220
    if-eqz v2, :cond_5

    .line 221
    .line 222
    invoke-virtual {v2}, Landroid/widget/TextView;->getTransformationMethod()Landroid/text/method/TransformationMethod;

    .line 223
    .line 224
    .line 225
    move-result-object v2

    .line 226
    instance-of v2, v2, Landroid/text/method/PasswordTransformationMethod;

    .line 227
    .line 228
    if-eqz v2, :cond_5

    .line 229
    .line 230
    iget-object v2, v0, Lp/Zb;->f:Landroid/widget/EditText;

    .line 231
    .line 232
    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setTransformationMethod(Landroid/text/method/TransformationMethod;)V

    .line 233
    .line 234
    .line 235
    goto :goto_2

    .line 236
    :cond_5
    iget-object p1, v0, Lp/Zb;->f:Landroid/widget/EditText;

    .line 237
    .line 238
    invoke-static {}, Landroid/text/method/PasswordTransformationMethod;->getInstance()Landroid/text/method/PasswordTransformationMethod;

    .line 239
    .line 240
    .line 241
    move-result-object v2

    .line 242
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setTransformationMethod(Landroid/text/method/TransformationMethod;)V

    .line 243
    .line 244
    .line 245
    :goto_2
    if-ltz v1, :cond_6

    .line 246
    .line 247
    iget-object p1, v0, Lp/Zb;->f:Landroid/widget/EditText;

    .line 248
    .line 249
    invoke-virtual {p1, v1}, Landroid/widget/EditText;->setSelection(I)V

    .line 250
    .line 251
    .line 252
    :cond_6
    invoke-virtual {v0}, Lp/D6;->q()V

    .line 253
    .line 254
    .line 255
    :goto_3
    return-void

    .line 256
    :pswitch_1
    iget-object v0, p0, Lp/F3;->b:Ljava/lang/Object;

    .line 257
    .line 258
    check-cast v0, Lp/xa;

    .line 259
    .line 260
    invoke-virtual {v0}, Lp/xa;->H()V

    .line 261
    .line 262
    .line 263
    throw p1

    .line 264
    :pswitch_2
    iget-object p1, p0, Lp/F3;->b:Ljava/lang/Object;

    .line 265
    .line 266
    check-cast p1, Lp/R5;

    .line 267
    .line 268
    invoke-virtual {p1}, Lp/R5;->u()V

    .line 269
    .line 270
    .line 271
    return-void

    .line 272
    :pswitch_3
    iget-object p1, p0, Lp/F3;->b:Ljava/lang/Object;

    .line 273
    .line 274
    check-cast p1, Lp/J3;

    .line 275
    .line 276
    iget-object v0, p1, Lp/J3;->i:Landroid/widget/EditText;

    .line 277
    .line 278
    if-nez v0, :cond_7

    .line 279
    .line 280
    goto :goto_4

    .line 281
    :cond_7
    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    .line 282
    .line 283
    .line 284
    move-result-object v0

    .line 285
    if-eqz v0, :cond_8

    .line 286
    .line 287
    invoke-interface {v0}, Landroid/text/Editable;->clear()V

    .line 288
    .line 289
    .line 290
    :cond_8
    invoke-virtual {p1}, Lp/D6;->q()V

    .line 291
    .line 292
    .line 293
    :goto_4
    return-void

    .line 294
    nop

    .line 295
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
