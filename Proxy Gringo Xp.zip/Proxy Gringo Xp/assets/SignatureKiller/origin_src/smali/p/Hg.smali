.class public abstract Lp/Hg;
.super Lp/Hd;
.source "SourceFile"


# static fields
.field public static final synthetic a:I
