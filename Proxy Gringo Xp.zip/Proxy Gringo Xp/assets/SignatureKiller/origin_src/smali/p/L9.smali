.class public final Lp/L9;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/AutoCloseable;


# static fields
.field public static final j:Ljava/util/concurrent/atomic/AtomicInteger;


# instance fields
.field public final a:Lp/F;

.field public final b:Ljava/util/concurrent/ExecutorService;

.field public final c:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

.field public final d:Ljava/util/concurrent/atomic/AtomicLong;

.field public final e:Ljava/util/concurrent/atomic/AtomicLong;

.field public final f:Ljava/util/concurrent/atomic/AtomicLong;

.field public final g:Ljava/util/concurrent/atomic/AtomicLong;

.field public volatile h:Z

.field public i:Ljava/net/ServerSocket;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lp/L9;->j:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>(Lp/F;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-static {}, Ljava/util/concurrent/Executors;->newCachedThreadPool()Ljava/util/concurrent/ExecutorService;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    iput-object v0, p0, Lp/L9;->b:Ljava/util/concurrent/ExecutorService;

    .line 9
    .line 10
    invoke-static {}, Ljava/util/concurrent/ConcurrentHashMap;->newKeySet()Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, Lp/L9;->c:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    .line 15
    .line 16
    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    .line 17
    .line 18
    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    .line 19
    .line 20
    .line 21
    iput-object v0, p0, Lp/L9;->d:Ljava/util/concurrent/atomic/AtomicLong;

    .line 22
    .line 23
    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    .line 24
    .line 25
    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    .line 26
    .line 27
    .line 28
    iput-object v0, p0, Lp/L9;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 29
    .line 30
    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    .line 31
    .line 32
    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    .line 33
    .line 34
    .line 35
    iput-object v0, p0, Lp/L9;->f:Ljava/util/concurrent/atomic/AtomicLong;

    .line 36
    .line 37
    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    .line 38
    .line 39
    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    .line 40
    .line 41
    .line 42
    iput-object v0, p0, Lp/L9;->g:Ljava/util/concurrent/atomic/AtomicLong;

    .line 43
    .line 44
    iput-object p1, p0, Lp/L9;->a:Lp/F;

    .line 45
    .line 46
    return-void
.end method

.method public static a(Ljava/lang/AutoCloseable;)V
    .locals 0

    .line 1
    :try_start_0
    invoke-interface {p0}, Ljava/lang/AutoCloseable;->close()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 2
    .line 3
    .line 4
    :catch_0
    return-void
.end method

.method public static c(Ljava/io/InputStream;Ljava/io/OutputStream;ZILjava/net/InetSocketAddress;)V
    .locals 7

    .line 1
    const/16 v0, 0x4000

    .line 2
    .line 3
    new-array v0, v0, [B

    .line 4
    .line 5
    :cond_0
    :goto_0
    invoke-virtual {p0, v0}, Ljava/io/InputStream;->read([B)I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-ltz v1, :cond_1

    .line 10
    .line 11
    if-lez v1, :cond_0

    .line 12
    .line 13
    invoke-static {p4}, Lp/Uf;->a(Ljava/net/InetSocketAddress;)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    invoke-static {p4}, Lp/Uf;->a(Ljava/net/InetSocketAddress;)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    new-instance v3, Ljava/lang/StringBuilder;

    .line 21
    .line 22
    const-string v4, "TCP://"

    .line 23
    .line 24
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v3

    .line 34
    sget-object v4, Lp/Uf;->a:Ljava/util/concurrent/ConcurrentHashMap;

    .line 35
    .line 36
    new-instance v5, Lp/Rf;

    .line 37
    .line 38
    const/4 v6, 0x1

    .line 39
    invoke-direct {v5, v2, v6}, Lp/Rf;-><init>(Ljava/lang/String;I)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v4, v3, v5}, Ljava/util/concurrent/ConcurrentHashMap;->computeIfAbsent(Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v2

    .line 46
    check-cast v2, Lp/Tf;

    .line 47
    .line 48
    invoke-virtual {v2, v1, p2}, Lp/Tf;->a(IZ)V

    .line 49
    .line 50
    .line 51
    const/4 v2, 0x0

    .line 52
    :try_start_0
    invoke-static {p2, p3, v0, v2, v1}, Lgringoxp/game/b;->receiveVpnTcp(ZI[BII)V
    :try_end_0
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_0} :catch_0

    .line 53
    .line 54
    .line 55
    :catch_0
    invoke-virtual {p1, v0, v2, v1}, Ljava/io/OutputStream;->write([BII)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {p1}, Ljava/io/OutputStream;->flush()V

    .line 59
    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_1
    return-void
.end method

.method public static f(Ljava/io/OutputStream;ILjava/net/InetAddress;I)V
    .locals 6

    .line 1
    const/4 v0, 0x2

    .line 2
    const/4 v1, 0x4

    .line 3
    const/4 v2, 0x0

    .line 4
    const/4 v3, 0x1

    .line 5
    invoke-virtual {p2}, Ljava/net/InetAddress;->getAddress()[B

    .line 6
    .line 7
    .line 8
    move-result-object p2

    .line 9
    int-to-byte p1, p1

    .line 10
    array-length v4, p2

    .line 11
    const/16 v5, 0x10

    .line 12
    .line 13
    if-ne v4, v5, :cond_0

    .line 14
    .line 15
    move v4, v1

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    move v4, v3

    .line 18
    :goto_0
    int-to-byte v4, v4

    .line 19
    new-array v1, v1, [B

    .line 20
    .line 21
    const/4 v5, 0x5

    .line 22
    aput-byte v5, v1, v2

    .line 23
    .line 24
    aput-byte p1, v1, v3

    .line 25
    .line 26
    aput-byte v2, v1, v0

    .line 27
    .line 28
    const/4 p1, 0x3

    .line 29
    aput-byte v4, v1, p1

    .line 30
    .line 31
    invoke-virtual {p0, v1}, Ljava/io/OutputStream;->write([B)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {p0, p2}, Ljava/io/OutputStream;->write([B)V

    .line 35
    .line 36
    .line 37
    ushr-int/lit8 p1, p3, 0x8

    .line 38
    .line 39
    int-to-byte p1, p1

    .line 40
    int-to-byte p2, p3

    .line 41
    new-array p3, v0, [B

    .line 42
    .line 43
    aput-byte p1, p3, v2

    .line 44
    .line 45
    aput-byte p2, p3, v3

    .line 46
    .line 47
    invoke-virtual {p0, p3}, Ljava/io/OutputStream;->write([B)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {p0}, Ljava/io/OutputStream;->flush()V

    .line 51
    .line 52
    .line 53
    return-void
.end method

.method public static g(Ljava/net/DatagramSocket;Ljava/net/InetSocketAddress;Ljava/net/InetSocketAddress;[BII)V
    .locals 8

    .line 1
    invoke-virtual {p2}, Ljava/net/InetSocketAddress;->getAddress()Ljava/net/InetAddress;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/net/InetAddress;->getAddress()[B

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    array-length v1, v0

    .line 10
    add-int/lit8 v2, v1, 0x6

    .line 11
    .line 12
    add-int v3, v2, p5

    .line 13
    .line 14
    new-array v4, v3, [B

    .line 15
    .line 16
    array-length v5, v0

    .line 17
    const/16 v6, 0x10

    .line 18
    .line 19
    const/4 v7, 0x4

    .line 20
    if-ne v5, v6, :cond_0

    .line 21
    .line 22
    move v5, v7

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    const/4 v5, 0x1

    .line 25
    :goto_0
    int-to-byte v5, v5

    .line 26
    const/4 v6, 0x3

    .line 27
    aput-byte v5, v4, v6

    .line 28
    .line 29
    const/4 v5, 0x0

    .line 30
    array-length v6, v0

    .line 31
    invoke-static {v0, v5, v4, v7, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 32
    .line 33
    .line 34
    add-int/lit8 v0, v1, 0x4

    .line 35
    .line 36
    invoke-virtual {p2}, Ljava/net/InetSocketAddress;->getPort()I

    .line 37
    .line 38
    .line 39
    move-result v5

    .line 40
    ushr-int/lit8 v5, v5, 0x8

    .line 41
    .line 42
    int-to-byte v5, v5

    .line 43
    aput-byte v5, v4, v0

    .line 44
    .line 45
    add-int/lit8 v1, v1, 0x5

    .line 46
    .line 47
    invoke-virtual {p2}, Ljava/net/InetSocketAddress;->getPort()I

    .line 48
    .line 49
    .line 50
    move-result p2

    .line 51
    int-to-byte p2, p2

    .line 52
    aput-byte p2, v4, v1

    .line 53
    .line 54
    invoke-static {p3, p4, v4, v2, p5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 55
    .line 56
    .line 57
    new-instance p2, Ljava/net/DatagramPacket;

    .line 58
    .line 59
    invoke-direct {p2, v4, v3, p1}, Ljava/net/DatagramPacket;-><init>([BILjava/net/SocketAddress;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {p0, p2}, Ljava/net/DatagramSocket;->send(Ljava/net/DatagramPacket;)V

    .line 63
    .line 64
    .line 65
    return-void
.end method

.method public static j(Ljava/io/InputStream;)I
    .locals 1

    .line 1
    invoke-virtual {p0}, Ljava/io/InputStream;->read()I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    if-ltz p0, :cond_0

    .line 6
    .line 7
    return p0

    .line 8
    :cond_0
    new-instance p0, Ljava/io/IOException;

    .line 9
    .line 10
    const-string v0, "EOF"

    .line 11
    .line 12
    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    throw p0
.end method


# virtual methods
.method public final b(Ljava/net/Socket;)V
    .locals 27

    .line 1
    move-object/from16 v8, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    const/4 v7, 0x3

    .line 6
    const/4 v9, 0x4

    .line 7
    const/4 v10, 0x2

    .line 8
    const/4 v11, 0x0

    .line 9
    const/4 v12, 0x1

    .line 10
    const/16 v1, 0x3a98

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 13
    .line 14
    .line 15
    invoke-virtual/range {p1 .. p1}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    .line 16
    .line 17
    .line 18
    move-result-object v13

    .line 19
    invoke-virtual/range {p1 .. p1}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    .line 20
    .line 21
    .line 22
    move-result-object v4

    .line 23
    invoke-static {v13}, Lp/L9;->j(Ljava/io/InputStream;)I

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    const/4 v14, 0x5

    .line 28
    if-ne v1, v14, :cond_1f

    .line 29
    .line 30
    invoke-static {v13}, Lp/L9;->j(Ljava/io/InputStream;)I

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    move v2, v11

    .line 35
    move v3, v2

    .line 36
    :goto_0
    if-ge v2, v1, :cond_1

    .line 37
    .line 38
    invoke-static {v13}, Lp/L9;->j(Ljava/io/InputStream;)I

    .line 39
    .line 40
    .line 41
    move-result v5

    .line 42
    if-nez v5, :cond_0

    .line 43
    .line 44
    move v5, v12

    .line 45
    goto :goto_1

    .line 46
    :cond_0
    move v5, v11

    .line 47
    :goto_1
    or-int/2addr v3, v5

    .line 48
    add-int/2addr v2, v12

    .line 49
    goto :goto_0

    .line 50
    :cond_1
    const/16 v15, 0xff

    .line 51
    .line 52
    if-eqz v3, :cond_2

    .line 53
    .line 54
    move v1, v11

    .line 55
    goto :goto_2

    .line 56
    :cond_2
    move v1, v15

    .line 57
    :goto_2
    int-to-byte v1, v1

    .line 58
    new-array v2, v10, [B

    .line 59
    .line 60
    aput-byte v14, v2, v11

    .line 61
    .line 62
    aput-byte v1, v2, v12

    .line 63
    .line 64
    invoke-virtual {v4, v2}, Ljava/io/OutputStream;->write([B)V

    .line 65
    .line 66
    .line 67
    invoke-virtual {v4}, Ljava/io/OutputStream;->flush()V

    .line 68
    .line 69
    .line 70
    if-eqz v3, :cond_1e

    .line 71
    .line 72
    invoke-static {v13}, Lp/L9;->j(Ljava/io/InputStream;)I

    .line 73
    .line 74
    .line 75
    move-result v1

    .line 76
    if-eq v1, v14, :cond_3

    .line 77
    .line 78
    goto/16 :goto_17

    .line 79
    .line 80
    :cond_3
    invoke-static {v13}, Lp/L9;->j(Ljava/io/InputStream;)I

    .line 81
    .line 82
    .line 83
    move-result v1

    .line 84
    invoke-static {v13}, Lp/L9;->j(Ljava/io/InputStream;)I

    .line 85
    .line 86
    .line 87
    invoke-static {v13}, Lp/L9;->j(Ljava/io/InputStream;)I

    .line 88
    .line 89
    .line 90
    move-result v2

    .line 91
    const/16 v16, 0x10

    .line 92
    .line 93
    if-ne v2, v12, :cond_4

    .line 94
    .line 95
    move v3, v9

    .line 96
    goto :goto_3

    .line 97
    :cond_4
    if-ne v2, v9, :cond_5

    .line 98
    .line 99
    move/from16 v3, v16

    .line 100
    .line 101
    goto :goto_3

    .line 102
    :cond_5
    if-ne v2, v7, :cond_6

    .line 103
    .line 104
    invoke-static {v13}, Lp/L9;->j(Ljava/io/InputStream;)I

    .line 105
    .line 106
    .line 107
    move-result v3

    .line 108
    goto :goto_3

    .line 109
    :cond_6
    move v3, v11

    .line 110
    :goto_3
    if-lez v3, :cond_1d

    .line 111
    .line 112
    if-gt v3, v15, :cond_1d

    .line 113
    .line 114
    new-array v5, v3, [B

    .line 115
    .line 116
    move v6, v11

    .line 117
    :goto_4
    if-ge v6, v3, :cond_8

    .line 118
    .line 119
    sub-int v14, v3, v6

    .line 120
    .line 121
    invoke-virtual {v13, v5, v6, v14}, Ljava/io/InputStream;->read([BII)I

    .line 122
    .line 123
    .line 124
    move-result v14

    .line 125
    if-ltz v14, :cond_7

    .line 126
    .line 127
    add-int/2addr v6, v14

    .line 128
    const/4 v14, 0x5

    .line 129
    goto :goto_4

    .line 130
    :cond_7
    new-instance v0, Ljava/io/IOException;

    .line 131
    .line 132
    const-string v1, "EOF"

    .line 133
    .line 134
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    throw v0

    .line 138
    :cond_8
    invoke-static {v13}, Lp/L9;->j(Ljava/io/InputStream;)I

    .line 139
    .line 140
    .line 141
    move-result v3

    .line 142
    shl-int/lit8 v3, v3, 0x8

    .line 143
    .line 144
    invoke-static {v13}, Lp/L9;->j(Ljava/io/InputStream;)I

    .line 145
    .line 146
    .line 147
    move-result v6

    .line 148
    or-int/2addr v3, v6

    .line 149
    if-ne v1, v12, :cond_b

    .line 150
    .line 151
    if-ne v2, v7, :cond_9

    .line 152
    .line 153
    new-instance v1, Ljava/lang/String;

    .line 154
    .line 155
    sget-object v2, Ljava/nio/charset/StandardCharsets;->US_ASCII:Ljava/nio/charset/Charset;

    .line 156
    .line 157
    invoke-direct {v1, v5, v2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 158
    .line 159
    .line 160
    invoke-static {v1}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    .line 161
    .line 162
    .line 163
    move-result-object v1

    .line 164
    goto :goto_5

    .line 165
    :cond_9
    invoke-static {v5}, Ljava/net/InetAddress;->getByAddress([B)Ljava/net/InetAddress;

    .line 166
    .line 167
    .line 168
    move-result-object v1

    .line 169
    :goto_5
    new-instance v9, Ljava/net/Socket;

    .line 170
    .line 171
    invoke-direct {v9}, Ljava/net/Socket;-><init>()V

    .line 172
    .line 173
    .line 174
    new-instance v10, Ljava/net/InetSocketAddress;

    .line 175
    .line 176
    invoke-direct {v10, v1, v3}, Ljava/net/InetSocketAddress;-><init>(Ljava/net/InetAddress;I)V

    .line 177
    .line 178
    .line 179
    iget-object v14, v8, Lp/L9;->c:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    .line 180
    .line 181
    invoke-interface {v14, v9}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 182
    .line 183
    .line 184
    :try_start_0
    new-instance v1, Ljava/net/InetSocketAddress;

    .line 185
    .line 186
    invoke-direct {v1, v11}, Ljava/net/InetSocketAddress;-><init>(I)V

    .line 187
    .line 188
    .line 189
    invoke-virtual {v9, v1}, Ljava/net/Socket;->bind(Ljava/net/SocketAddress;)V

    .line 190
    .line 191
    .line 192
    iget-object v1, v8, Lp/L9;->a:Lp/F;

    .line 193
    .line 194
    iget-object v1, v1, Lp/F;->b:Ljava/lang/Object;

    .line 195
    .line 196
    check-cast v1, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;

    .line 197
    .line 198
    invoke-virtual {v1, v9}, Landroid/net/VpnService;->protect(Ljava/net/Socket;)Z

    .line 199
    .line 200
    .line 201
    move-result v1

    .line 202
    if-eqz v1, :cond_a

    .line 203
    .line 204
    const/16 v1, 0x1f40

    .line 205
    .line 206
    invoke-virtual {v9, v10, v1}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V

    .line 207
    .line 208
    .line 209
    invoke-virtual {v0, v11}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 210
    .line 211
    .line 212
    invoke-virtual {v9, v11}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 213
    .line 214
    .line 215
    invoke-virtual {v9}, Ljava/net/Socket;->getLocalAddress()Ljava/net/InetAddress;

    .line 216
    .line 217
    .line 218
    move-result-object v1

    .line 219
    invoke-virtual {v9}, Ljava/net/Socket;->getLocalPort()I

    .line 220
    .line 221
    .line 222
    move-result v2

    .line 223
    invoke-static {v4, v11, v1, v2}, Lp/L9;->f(Ljava/io/OutputStream;ILjava/net/InetAddress;I)V

    .line 224
    .line 225
    .line 226
    iget-object v1, v8, Lp/L9;->g:Ljava/util/concurrent/atomic/AtomicLong;

    .line 227
    .line 228
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    .line 229
    .line 230
    .line 231
    move-result-wide v1

    .line 232
    long-to-int v11, v1

    .line 233
    iget-object v15, v8, Lp/L9;->b:Ljava/util/concurrent/ExecutorService;

    .line 234
    .line 235
    new-instance v7, Lp/I9;

    .line 236
    .line 237
    move-object v1, v7

    .line 238
    move-object/from16 v2, p0

    .line 239
    .line 240
    move-object v3, v9

    .line 241
    move-object/from16 v5, p1

    .line 242
    .line 243
    move v6, v11

    .line 244
    move-object v0, v7

    .line 245
    move-object v7, v10

    .line 246
    invoke-direct/range {v1 .. v7}, Lp/I9;-><init>(Lp/L9;Ljava/net/Socket;Ljava/io/OutputStream;Ljava/net/Socket;ILjava/net/InetSocketAddress;)V

    .line 247
    .line 248
    .line 249
    invoke-interface {v15, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 250
    .line 251
    .line 252
    invoke-virtual {v9}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    .line 253
    .line 254
    .line 255
    move-result-object v0

    .line 256
    invoke-static {v13, v0, v12, v11, v10}, Lp/L9;->c(Ljava/io/InputStream;Ljava/io/OutputStream;ZILjava/net/InetSocketAddress;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 257
    .line 258
    .line 259
    invoke-interface {v14, v9}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 260
    .line 261
    .line 262
    invoke-static {v9}, Lp/L9;->a(Ljava/lang/AutoCloseable;)V

    .line 263
    .line 264
    .line 265
    goto/16 :goto_16

    .line 266
    .line 267
    :catchall_0
    move-exception v0

    .line 268
    goto :goto_6

    .line 269
    :cond_a
    :try_start_1
    new-instance v0, Ljava/io/IOException;

    .line 270
    .line 271
    const-string v1, "protect TCP"

    .line 272
    .line 273
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 274
    .line 275
    .line 276
    throw v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 277
    :goto_6
    invoke-interface {v14, v9}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 278
    .line 279
    .line 280
    invoke-static {v9}, Lp/L9;->a(Ljava/lang/AutoCloseable;)V

    .line 281
    .line 282
    .line 283
    throw v0

    .line 284
    :cond_b
    const/4 v0, 0x7

    .line 285
    if-ne v1, v7, :cond_1c

    .line 286
    .line 287
    new-instance v13, Ljava/net/DatagramSocket;

    .line 288
    .line 289
    new-instance v1, Ljava/net/InetSocketAddress;

    .line 290
    .line 291
    const-string v2, "127.0.0.1"

    .line 292
    .line 293
    invoke-static {v2}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    .line 294
    .line 295
    .line 296
    move-result-object v2

    .line 297
    invoke-direct {v1, v2, v11}, Ljava/net/InetSocketAddress;-><init>(Ljava/net/InetAddress;I)V

    .line 298
    .line 299
    .line 300
    invoke-direct {v13, v1}, Ljava/net/DatagramSocket;-><init>(Ljava/net/SocketAddress;)V

    .line 301
    .line 302
    .line 303
    new-instance v14, Ljava/net/DatagramSocket;

    .line 304
    .line 305
    invoke-direct {v14}, Ljava/net/DatagramSocket;-><init>()V

    .line 306
    .line 307
    .line 308
    const/16 v1, 0xa

    .line 309
    .line 310
    invoke-virtual {v13, v1}, Ljava/net/DatagramSocket;->setSoTimeout(I)V

    .line 311
    .line 312
    .line 313
    iget-object v1, v8, Lp/L9;->c:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    .line 314
    .line 315
    invoke-interface {v1, v13}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 316
    .line 317
    .line 318
    iget-object v1, v8, Lp/L9;->c:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    .line 319
    .line 320
    invoke-interface {v1, v14}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 321
    .line 322
    .line 323
    iget-object v1, v8, Lp/L9;->a:Lp/F;

    .line 324
    .line 325
    iget-object v1, v1, Lp/F;->b:Ljava/lang/Object;

    .line 326
    .line 327
    check-cast v1, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;

    .line 328
    .line 329
    invoke-virtual {v1, v14}, Landroid/net/VpnService;->protect(Ljava/net/DatagramSocket;)Z

    .line 330
    .line 331
    .line 332
    move-result v1

    .line 333
    if-eqz v1, :cond_1b

    .line 334
    .line 335
    const-string v1, "127.0.0.1"

    .line 336
    .line 337
    invoke-static {v1}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    .line 338
    .line 339
    .line 340
    move-result-object v1

    .line 341
    invoke-virtual {v13}, Ljava/net/DatagramSocket;->getLocalPort()I

    .line 342
    .line 343
    .line 344
    move-result v2

    .line 345
    invoke-static {v4, v11, v1, v2}, Lp/L9;->f(Ljava/io/OutputStream;ILjava/net/InetAddress;I)V

    .line 346
    .line 347
    .line 348
    new-instance v6, Ljava/util/concurrent/ConcurrentHashMap;

    .line 349
    .line 350
    invoke-direct {v6}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    .line 351
    .line 352
    .line 353
    new-instance v5, Ljava/util/concurrent/atomic/AtomicReference;

    .line 354
    .line 355
    invoke-direct {v5}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    .line 356
    .line 357
    .line 358
    iget-object v4, v8, Lp/L9;->b:Ljava/util/concurrent/ExecutorService;

    .line 359
    .line 360
    new-instance v3, Lp/J9;

    .line 361
    .line 362
    move-object v1, v3

    .line 363
    move-object/from16 v2, p0

    .line 364
    .line 365
    move-object v11, v3

    .line 366
    move-object v3, v13

    .line 367
    move-object v9, v4

    .line 368
    move-object v4, v14

    .line 369
    move-object/from16 p1, v5

    .line 370
    .line 371
    move-object/from16 v19, v6

    .line 372
    .line 373
    invoke-direct/range {v1 .. v6}, Lp/J9;-><init>(Lp/L9;Ljava/net/DatagramSocket;Ljava/net/DatagramSocket;Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/ConcurrentHashMap;)V

    .line 374
    .line 375
    .line 376
    invoke-interface {v9, v11}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 377
    .line 378
    .line 379
    const v1, 0xffff

    .line 380
    .line 381
    .line 382
    new-array v2, v1, [B

    .line 383
    .line 384
    :goto_7
    :try_start_2
    iget-boolean v3, v8, Lp/L9;->h:Z

    .line 385
    .line 386
    if-eqz v3, :cond_18

    .line 387
    .line 388
    invoke-virtual {v13}, Ljava/net/DatagramSocket;->isClosed()Z

    .line 389
    .line 390
    .line 391
    move-result v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    .line 392
    if-nez v3, :cond_18

    .line 393
    .line 394
    move-object/from16 v3, v19

    .line 395
    .line 396
    :try_start_3
    invoke-virtual {v8, v14, v3}, Lp/L9;->d(Ljava/net/DatagramSocket;Ljava/util/concurrent/ConcurrentHashMap;)V

    .line 397
    .line 398
    .line 399
    invoke-virtual {v8, v14, v3}, Lp/L9;->e(Ljava/net/DatagramSocket;Ljava/util/concurrent/ConcurrentHashMap;)V

    .line 400
    .line 401
    .line 402
    new-instance v4, Ljava/net/DatagramPacket;

    .line 403
    .line 404
    invoke-direct {v4, v2, v1}, Ljava/net/DatagramPacket;-><init>([BI)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 405
    .line 406
    .line 407
    :try_start_4
    invoke-virtual {v13, v4}, Ljava/net/DatagramSocket;->receive(Ljava/net/DatagramPacket;)V
    :try_end_4
    .catch Ljava/net/SocketTimeoutException; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 408
    .line 409
    .line 410
    :try_start_5
    invoke-virtual {v4}, Ljava/net/DatagramPacket;->getSocketAddress()Ljava/net/SocketAddress;

    .line 411
    .line 412
    .line 413
    move-result-object v5

    .line 414
    check-cast v5, Ljava/net/InetSocketAddress;

    .line 415
    .line 416
    move-object/from16 v6, p1

    .line 417
    .line 418
    invoke-virtual {v6, v5}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 419
    .line 420
    .line 421
    invoke-virtual {v4}, Ljava/net/DatagramPacket;->getOffset()I

    .line 422
    .line 423
    .line 424
    move-result v5

    .line 425
    invoke-virtual {v4}, Ljava/net/DatagramPacket;->getLength()I

    .line 426
    .line 427
    .line 428
    move-result v4

    .line 429
    add-int/2addr v4, v5

    .line 430
    sub-int v9, v4, v5

    .line 431
    .line 432
    if-lt v9, v0, :cond_17

    .line 433
    .line 434
    aget-byte v9, v2, v5

    .line 435
    .line 436
    if-nez v9, :cond_17

    .line 437
    .line 438
    add-int/lit8 v9, v5, 0x1

    .line 439
    .line 440
    aget-byte v9, v2, v9

    .line 441
    .line 442
    if-nez v9, :cond_17

    .line 443
    .line 444
    add-int/lit8 v9, v5, 0x2

    .line 445
    .line 446
    aget-byte v9, v2, v9

    .line 447
    .line 448
    if-eqz v9, :cond_c

    .line 449
    .line 450
    :goto_8
    move-object/from16 v19, v3

    .line 451
    .line 452
    move-object/from16 p1, v6

    .line 453
    .line 454
    goto :goto_7

    .line 455
    :cond_c
    add-int/lit8 v9, v5, 0x3

    .line 456
    .line 457
    aget-byte v9, v2, v9

    .line 458
    .line 459
    and-int/2addr v9, v15

    .line 460
    const/4 v11, 0x4

    .line 461
    add-int/lit8 v1, v5, 0x4

    .line 462
    .line 463
    if-ne v9, v12, :cond_d

    .line 464
    .line 465
    move v5, v11

    .line 466
    :goto_9
    const/16 v17, 0x5

    .line 467
    .line 468
    goto :goto_a

    .line 469
    :cond_d
    if-ne v9, v11, :cond_e

    .line 470
    .line 471
    move/from16 v5, v16

    .line 472
    .line 473
    goto :goto_9

    .line 474
    :cond_e
    if-ne v9, v7, :cond_f

    .line 475
    .line 476
    if-ge v1, v4, :cond_f

    .line 477
    .line 478
    const/16 v17, 0x5

    .line 479
    .line 480
    add-int/lit8 v5, v5, 0x5

    .line 481
    .line 482
    aget-byte v1, v2, v1

    .line 483
    .line 484
    and-int/2addr v1, v15

    .line 485
    move/from16 v26, v5

    .line 486
    .line 487
    move v5, v1

    .line 488
    move/from16 v1, v26

    .line 489
    .line 490
    goto :goto_a

    .line 491
    :catchall_1
    move-exception v0

    .line 492
    goto/16 :goto_13

    .line 493
    .line 494
    :cond_f
    const/16 v17, 0x5

    .line 495
    .line 496
    const/4 v5, 0x0

    .line 497
    :goto_a
    if-eqz v5, :cond_10

    .line 498
    .line 499
    add-int v18, v1, v5

    .line 500
    .line 501
    add-int/lit8 v11, v18, 0x2

    .line 502
    .line 503
    if-le v11, v4, :cond_11

    .line 504
    .line 505
    :cond_10
    move-object/from16 v19, v3

    .line 506
    .line 507
    move-object/from16 p1, v6

    .line 508
    .line 509
    const v1, 0xffff

    .line 510
    .line 511
    .line 512
    goto/16 :goto_7

    .line 513
    .line 514
    :cond_11
    new-array v10, v5, [B

    .line 515
    .line 516
    const/4 v0, 0x0

    .line 517
    invoke-static {v2, v1, v10, v0, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 518
    .line 519
    .line 520
    add-int/lit8 v0, v18, 0x1

    .line 521
    .line 522
    aget-byte v1, v2, v18

    .line 523
    .line 524
    and-int/2addr v1, v15

    .line 525
    shl-int/lit8 v1, v1, 0x8

    .line 526
    .line 527
    aget-byte v0, v2, v0

    .line 528
    .line 529
    and-int/2addr v0, v15

    .line 530
    or-int/2addr v0, v1

    .line 531
    if-ne v9, v7, :cond_12

    .line 532
    .line 533
    new-instance v1, Ljava/lang/String;

    .line 534
    .line 535
    sget-object v5, Ljava/nio/charset/StandardCharsets;->US_ASCII:Ljava/nio/charset/Charset;

    .line 536
    .line 537
    invoke-direct {v1, v10, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 538
    .line 539
    .line 540
    invoke-static {v1}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    .line 541
    .line 542
    .line 543
    move-result-object v1

    .line 544
    goto :goto_b

    .line 545
    :cond_12
    invoke-static {v10}, Ljava/net/InetAddress;->getByAddress([B)Ljava/net/InetAddress;

    .line 546
    .line 547
    .line 548
    move-result-object v1

    .line 549
    :goto_b
    sub-int/2addr v4, v11

    .line 550
    if-gtz v4, :cond_13

    .line 551
    .line 552
    :goto_c
    move-object/from16 v19, v3

    .line 553
    .line 554
    move-object/from16 p1, v6

    .line 555
    .line 556
    const/4 v0, 0x7

    .line 557
    const v1, 0xffff

    .line 558
    .line 559
    .line 560
    const/4 v10, 0x2

    .line 561
    goto/16 :goto_7

    .line 562
    .line 563
    :cond_13
    new-instance v5, Ljava/net/InetSocketAddress;

    .line 564
    .line 565
    invoke-direct {v5, v1, v0}, Ljava/net/InetSocketAddress;-><init>(Ljava/net/InetAddress;I)V

    .line 566
    .line 567
    .line 568
    monitor-enter v3
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 569
    :try_start_6
    invoke-virtual {v14}, Ljava/net/DatagramSocket;->isClosed()Z

    .line 570
    .line 571
    .line 572
    move-result v9

    .line 573
    if-eqz v9, :cond_14

    .line 574
    .line 575
    monitor-exit v3

    .line 576
    goto/16 :goto_10

    .line 577
    .line 578
    :catchall_2
    move-exception v0

    .line 579
    goto :goto_f

    .line 580
    :cond_14
    new-instance v9, Lp/K9;

    .line 581
    .line 582
    const/4 v10, 0x0

    .line 583
    invoke-direct {v9, v10}, Lp/K9;-><init>(I)V

    .line 584
    .line 585
    .line 586
    invoke-virtual {v3, v5, v9}, Ljava/util/concurrent/ConcurrentHashMap;->computeIfAbsent(Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;

    .line 587
    .line 588
    .line 589
    move-result-object v9

    .line 590
    check-cast v9, Ljava/lang/Integer;

    .line 591
    .line 592
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 593
    .line 594
    .line 595
    move-result v21
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 596
    const/16 v20, 0x1

    .line 597
    .line 598
    move-object/from16 v22, v5

    .line 599
    .line 600
    move-object/from16 v23, v2

    .line 601
    .line 602
    move/from16 v24, v11

    .line 603
    .line 604
    move/from16 v25, v4

    .line 605
    .line 606
    :try_start_7
    invoke-static/range {v20 .. v25}, Lgringoxp/game/b;->r(ZILjava/net/InetSocketAddress;[BII)[B

    .line 607
    .line 608
    .line 609
    move-result-object v5
    :try_end_7
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_7 .. :try_end_7} :catch_0
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    .line 610
    goto :goto_d

    .line 611
    :catch_0
    const/4 v5, 0x0

    .line 612
    :goto_d
    :try_start_8
    monitor-exit v3
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    .line 613
    if-eqz v5, :cond_15

    .line 614
    .line 615
    :try_start_9
    array-length v9, v5

    .line 616
    if-nez v9, :cond_15

    .line 617
    .line 618
    goto :goto_c

    .line 619
    :cond_15
    if-eqz v5, :cond_16

    .line 620
    .line 621
    new-instance v4, Ljava/net/DatagramPacket;

    .line 622
    .line 623
    array-length v9, v5

    .line 624
    invoke-direct {v4, v5, v9, v1, v0}, Ljava/net/DatagramPacket;-><init>([BILjava/net/InetAddress;I)V

    .line 625
    .line 626
    .line 627
    invoke-virtual {v14, v4}, Ljava/net/DatagramSocket;->send(Ljava/net/DatagramPacket;)V

    .line 628
    .line 629
    .line 630
    goto :goto_e

    .line 631
    :cond_16
    new-instance v5, Ljava/net/DatagramPacket;

    .line 632
    .line 633
    move-object/from16 v20, v5

    .line 634
    .line 635
    move-object/from16 v21, v2

    .line 636
    .line 637
    move/from16 v22, v11

    .line 638
    .line 639
    move/from16 v23, v4

    .line 640
    .line 641
    move-object/from16 v24, v1

    .line 642
    .line 643
    move/from16 v25, v0

    .line 644
    .line 645
    invoke-direct/range {v20 .. v25}, Ljava/net/DatagramPacket;-><init>([BIILjava/net/InetAddress;I)V

    .line 646
    .line 647
    .line 648
    invoke-virtual {v14, v5}, Ljava/net/DatagramSocket;->send(Ljava/net/DatagramPacket;)V

    .line 649
    .line 650
    .line 651
    :goto_e
    iget-object v0, v8, Lp/L9;->d:Ljava/util/concurrent/atomic/AtomicLong;

    .line 652
    .line 653
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    .line 654
    .line 655
    .line 656
    goto :goto_c

    .line 657
    :goto_f
    :try_start_a
    monitor-exit v3
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_2

    .line 658
    :try_start_b
    throw v0
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_1

    .line 659
    :cond_17
    const/16 v17, 0x5

    .line 660
    .line 661
    goto/16 :goto_8

    .line 662
    .line 663
    :catch_1
    move-object/from16 v6, p1

    .line 664
    .line 665
    const/16 v17, 0x5

    .line 666
    .line 667
    move-object/from16 v19, v3

    .line 668
    .line 669
    goto/16 :goto_7

    .line 670
    .line 671
    :cond_18
    move-object/from16 v3, v19

    .line 672
    .line 673
    goto :goto_10

    .line 674
    :catchall_3
    move-exception v0

    .line 675
    move-object/from16 v3, v19

    .line 676
    .line 677
    goto :goto_13

    .line 678
    :goto_10
    iget-object v0, v8, Lp/L9;->c:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    .line 679
    .line 680
    invoke-interface {v0, v13}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 681
    .line 682
    .line 683
    iget-object v0, v8, Lp/L9;->c:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    .line 684
    .line 685
    invoke-interface {v0, v14}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 686
    .line 687
    .line 688
    invoke-virtual {v13}, Ljava/net/DatagramSocket;->close()V

    .line 689
    .line 690
    .line 691
    invoke-virtual {v14}, Ljava/net/DatagramSocket;->close()V

    .line 692
    .line 693
    .line 694
    monitor-enter v3

    .line 695
    :try_start_c
    invoke-virtual {v3}, Ljava/util/concurrent/ConcurrentHashMap;->values()Ljava/util/Collection;

    .line 696
    .line 697
    .line 698
    move-result-object v0

    .line 699
    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 700
    .line 701
    .line 702
    move-result-object v0

    .line 703
    :catch_2
    :goto_11
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 704
    .line 705
    .line 706
    move-result v1

    .line 707
    if-eqz v1, :cond_19

    .line 708
    .line 709
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 710
    .line 711
    .line 712
    move-result-object v1

    .line 713
    check-cast v1, Ljava/lang/Integer;

    .line 714
    .line 715
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 716
    .line 717
    .line 718
    move-result v1
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_4

    .line 719
    :try_start_d
    invoke-static {v1}, Lgringoxp/game/b;->releaseVpnUdpAssociation(I)V
    :try_end_d
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_d .. :try_end_d} :catch_2
    .catchall {:try_start_d .. :try_end_d} :catchall_4

    .line 720
    .line 721
    .line 722
    goto :goto_11

    .line 723
    :catchall_4
    move-exception v0

    .line 724
    goto :goto_12

    .line 725
    :cond_19
    :try_start_e
    invoke-virtual {v3}, Ljava/util/concurrent/ConcurrentHashMap;->clear()V

    .line 726
    .line 727
    .line 728
    monitor-exit v3

    .line 729
    goto :goto_16

    .line 730
    :goto_12
    monitor-exit v3
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_4

    .line 731
    throw v0

    .line 732
    :goto_13
    iget-object v1, v8, Lp/L9;->c:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    .line 733
    .line 734
    invoke-interface {v1, v13}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 735
    .line 736
    .line 737
    iget-object v1, v8, Lp/L9;->c:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    .line 738
    .line 739
    invoke-interface {v1, v14}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 740
    .line 741
    .line 742
    invoke-virtual {v13}, Ljava/net/DatagramSocket;->close()V

    .line 743
    .line 744
    .line 745
    invoke-virtual {v14}, Ljava/net/DatagramSocket;->close()V

    .line 746
    .line 747
    .line 748
    monitor-enter v3

    .line 749
    :try_start_f
    invoke-virtual {v3}, Ljava/util/concurrent/ConcurrentHashMap;->values()Ljava/util/Collection;

    .line 750
    .line 751
    .line 752
    move-result-object v1

    .line 753
    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 754
    .line 755
    .line 756
    move-result-object v1

    .line 757
    :catch_3
    :goto_14
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 758
    .line 759
    .line 760
    move-result v2

    .line 761
    if-eqz v2, :cond_1a

    .line 762
    .line 763
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 764
    .line 765
    .line 766
    move-result-object v2

    .line 767
    check-cast v2, Ljava/lang/Integer;

    .line 768
    .line 769
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 770
    .line 771
    .line 772
    move-result v2
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_5

    .line 773
    :try_start_10
    invoke-static {v2}, Lgringoxp/game/b;->releaseVpnUdpAssociation(I)V
    :try_end_10
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_10 .. :try_end_10} :catch_3
    .catchall {:try_start_10 .. :try_end_10} :catchall_5

    .line 774
    .line 775
    .line 776
    goto :goto_14

    .line 777
    :catchall_5
    move-exception v0

    .line 778
    goto :goto_15

    .line 779
    :cond_1a
    :try_start_11
    invoke-virtual {v3}, Ljava/util/concurrent/ConcurrentHashMap;->clear()V

    .line 780
    .line 781
    .line 782
    monitor-exit v3
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_5

    .line 783
    throw v0

    .line 784
    :goto_15
    :try_start_12
    monitor-exit v3
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_5

    .line 785
    throw v0

    .line 786
    :cond_1b
    new-instance v0, Ljava/io/IOException;

    .line 787
    .line 788
    const-string v1, "protect UDP"

    .line 789
    .line 790
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 791
    .line 792
    .line 793
    throw v0

    .line 794
    :cond_1c
    const-string v0, "0.0.0.0"

    .line 795
    .line 796
    invoke-static {v0}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    .line 797
    .line 798
    .line 799
    move-result-object v0

    .line 800
    const/4 v1, 0x7

    .line 801
    const/4 v2, 0x0

    .line 802
    invoke-static {v4, v1, v0, v2}, Lp/L9;->f(Ljava/io/OutputStream;ILjava/net/InetAddress;I)V

    .line 803
    .line 804
    .line 805
    :goto_16
    return-void

    .line 806
    :cond_1d
    new-instance v0, Ljava/io/IOException;

    .line 807
    .line 808
    const-string v1, "address type"

    .line 809
    .line 810
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 811
    .line 812
    .line 813
    throw v0

    .line 814
    :cond_1e
    :goto_17
    return-void

    .line 815
    :cond_1f
    new-instance v0, Ljava/io/IOException;

    .line 816
    .line 817
    const-string v1, "SOCKS version"

    .line 818
    .line 819
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 820
    .line 821
    .line 822
    throw v0
.end method

.method public final close()V
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lp/L9;->h:Z

    .line 3
    .line 4
    iget-object v0, p0, Lp/L9;->c:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    .line 5
    .line 6
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-eqz v1, :cond_0

    .line 15
    .line 16
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    check-cast v1, Ljava/lang/AutoCloseable;

    .line 21
    .line 22
    invoke-static {v1}, Lp/L9;->a(Ljava/lang/AutoCloseable;)V

    .line 23
    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    iget-object v0, p0, Lp/L9;->c:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    .line 27
    .line 28
    invoke-interface {v0}, Ljava/util/Set;->clear()V

    .line 29
    .line 30
    .line 31
    iget-object v0, p0, Lp/L9;->b:Ljava/util/concurrent/ExecutorService;

    .line 32
    .line 33
    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    .line 34
    .line 35
    .line 36
    return-void
.end method

.method public final d(Ljava/net/DatagramSocket;Ljava/util/concurrent/ConcurrentHashMap;)V
    .locals 5

    .line 1
    monitor-enter p2

    .line 2
    :try_start_0
    invoke-virtual {p1}, Ljava/net/DatagramSocket;->isClosed()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    monitor-exit p2

    .line 9
    return-void

    .line 10
    :catchall_0
    move-exception p1

    .line 11
    goto :goto_1

    .line 12
    :cond_0
    invoke-virtual {p2}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    :catch_0
    :cond_1
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-eqz v1, :cond_3

    .line 25
    .line 26
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    check-cast v1, Ljava/util/Map$Entry;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 31
    .line 32
    :try_start_1
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    check-cast v2, Ljava/lang/Integer;

    .line 37
    .line 38
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    invoke-static {v2}, Lgringoxp/game/b;->takeClientRequestUdp(I)[B

    .line 43
    .line 44
    .line 45
    move-result-object v2
    :try_end_1
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 46
    if-eqz v2, :cond_1

    .line 47
    .line 48
    :try_start_2
    array-length v3, v2

    .line 49
    if-eqz v3, :cond_1

    .line 50
    .line 51
    array-length v3, v2

    .line 52
    const/16 v4, 0x1000

    .line 53
    .line 54
    if-le v3, v4, :cond_2

    .line 55
    .line 56
    goto :goto_0

    .line 57
    :cond_2
    new-instance v3, Ljava/net/DatagramPacket;

    .line 58
    .line 59
    array-length v4, v2

    .line 60
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    check-cast v1, Ljava/net/SocketAddress;

    .line 65
    .line 66
    invoke-direct {v3, v2, v4, v1}, Ljava/net/DatagramPacket;-><init>([BILjava/net/SocketAddress;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {p1, v3}, Ljava/net/DatagramSocket;->send(Ljava/net/DatagramPacket;)V

    .line 70
    .line 71
    .line 72
    iget-object v1, p0, Lp/L9;->d:Ljava/util/concurrent/atomic/AtomicLong;

    .line 73
    .line 74
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    .line 75
    .line 76
    .line 77
    goto :goto_0

    .line 78
    :cond_3
    monitor-exit p2

    .line 79
    return-void

    .line 80
    :goto_1
    monitor-exit p2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 81
    throw p1
.end method

.method public final e(Ljava/net/DatagramSocket;Ljava/util/concurrent/ConcurrentHashMap;)V
    .locals 9

    .line 1
    monitor-enter p2

    .line 2
    :try_start_0
    invoke-virtual {p1}, Ljava/net/DatagramSocket;->isClosed()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    monitor-exit p2

    .line 9
    return-void

    .line 10
    :catchall_0
    move-exception p1

    .line 11
    goto :goto_3

    .line 12
    :cond_0
    invoke-virtual {p2}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    :catch_0
    :cond_1
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-eqz v1, :cond_5

    .line 25
    .line 26
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    check-cast v1, Ljava/util/Map$Entry;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 31
    .line 32
    :try_start_1
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    check-cast v2, Ljava/lang/Integer;

    .line 37
    .line 38
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    const/4 v3, 0x1

    .line 43
    invoke-static {v3, v2}, Lgringoxp/game/b;->drainHeldVpnUdp(ZI)[[B

    .line 44
    .line 45
    .line 46
    move-result-object v2
    :try_end_1
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 47
    if-nez v2, :cond_2

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_2
    :try_start_2
    array-length v3, v2

    .line 51
    const/4 v4, 0x0

    .line 52
    :goto_1
    if-ge v4, v3, :cond_1

    .line 53
    .line 54
    aget-object v5, v2, v4

    .line 55
    .line 56
    if-eqz v5, :cond_4

    .line 57
    .line 58
    array-length v6, v5

    .line 59
    if-nez v6, :cond_3

    .line 60
    .line 61
    goto :goto_2

    .line 62
    :cond_3
    new-instance v6, Ljava/net/DatagramPacket;

    .line 63
    .line 64
    array-length v7, v5

    .line 65
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v8

    .line 69
    check-cast v8, Ljava/net/SocketAddress;

    .line 70
    .line 71
    invoke-direct {v6, v5, v7, v8}, Ljava/net/DatagramPacket;-><init>([BILjava/net/SocketAddress;)V

    .line 72
    .line 73
    .line 74
    invoke-virtual {p1, v6}, Ljava/net/DatagramSocket;->send(Ljava/net/DatagramPacket;)V

    .line 75
    .line 76
    .line 77
    iget-object v5, p0, Lp/L9;->d:Ljava/util/concurrent/atomic/AtomicLong;

    .line 78
    .line 79
    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    .line 80
    .line 81
    .line 82
    :cond_4
    :goto_2
    add-int/lit8 v4, v4, 0x1

    .line 83
    .line 84
    goto :goto_1

    .line 85
    :cond_5
    monitor-exit p2

    .line 86
    return-void

    .line 87
    :goto_3
    monitor-exit p2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 88
    throw p1
.end method

.method public final h()I
    .locals 4

    .line 1
    new-instance v0, Ljava/net/ServerSocket;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/net/ServerSocket;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object v0, p0, Lp/L9;->i:Ljava/net/ServerSocket;

    .line 7
    .line 8
    new-instance v1, Ljava/net/InetSocketAddress;

    .line 9
    .line 10
    const-string v2, "127.0.0.1"

    .line 11
    .line 12
    invoke-static {v2}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    const/4 v3, 0x0

    .line 17
    invoke-direct {v1, v2, v3}, Ljava/net/InetSocketAddress;-><init>(Ljava/net/InetAddress;I)V

    .line 18
    .line 19
    .line 20
    const/16 v2, 0x40

    .line 21
    .line 22
    invoke-virtual {v0, v1, v2}, Ljava/net/ServerSocket;->bind(Ljava/net/SocketAddress;I)V

    .line 23
    .line 24
    .line 25
    iget-object v0, p0, Lp/L9;->c:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    .line 26
    .line 27
    iget-object v1, p0, Lp/L9;->i:Ljava/net/ServerSocket;

    .line 28
    .line 29
    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    const/4 v0, 0x1

    .line 33
    iput-boolean v0, p0, Lp/L9;->h:Z

    .line 34
    .line 35
    iget-object v0, p0, Lp/L9;->b:Ljava/util/concurrent/ExecutorService;

    .line 36
    .line 37
    new-instance v1, Lp/i0;

    .line 38
    .line 39
    const/16 v2, 0x8

    .line 40
    .line 41
    invoke-direct {v1, v2, p0}, Lp/i0;-><init>(ILjava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 45
    .line 46
    .line 47
    iget-object v0, p0, Lp/L9;->i:Ljava/net/ServerSocket;

    .line 48
    .line 49
    invoke-virtual {v0}, Ljava/net/ServerSocket;->getLocalPort()I

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    return v0
.end method

.method public final i()Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "UDP ida/volta "

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Lp/L9;->d:Ljava/util/concurrent/atomic/AtomicLong;

    .line 9
    .line 10
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 11
    .line 12
    .line 13
    move-result-wide v1

    .line 14
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 15
    .line 16
    .line 17
    const-string v1, "/"

    .line 18
    .line 19
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    iget-object v1, p0, Lp/L9;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 23
    .line 24
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 25
    .line 26
    .line 27
    move-result-wide v1

    .line 28
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    const-string v1, " \u00b7 erros "

    .line 32
    .line 33
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    iget-object v1, p0, Lp/L9;->f:Ljava/util/concurrent/atomic/AtomicLong;

    .line 37
    .line 38
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 39
    .line 40
    .line 41
    move-result-wide v1

    .line 42
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    const-string v1, " \u00b7 TCP "

    .line 46
    .line 47
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 48
    .line 49
    .line 50
    iget-object v1, p0, Lp/L9;->g:Ljava/util/concurrent/atomic/AtomicLong;

    .line 51
    .line 52
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 53
    .line 54
    .line 55
    move-result-wide v1

    .line 56
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 57
    .line 58
    .line 59
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    return-object v0
.end method
