.class public final synthetic Lp/P3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lp/N7;


# instance fields
.field public final synthetic a:Lp/I0;


# direct methods
.method public synthetic constructor <init>(Lp/I0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lp/P3;->a:Lp/I0;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Lp/P3;->a:Lp/I0;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroidx/activity/a;->reportFullyDrawn()V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    return-object v0
.end method
