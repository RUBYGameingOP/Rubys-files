.class public final synthetic Lp/Qb;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:Lp/Rb;

.field public final synthetic b:I

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(Lp/Rb;II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lp/Qb;->a:Lp/Rb;

    iput p2, p0, Lp/Qb;->b:I

    iput p3, p0, Lp/Qb;->c:I

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 6

    .line 1
    iget v2, p0, Lp/Qb;->b:I

    .line 2
    .line 3
    iget-object p1, p0, Lp/Qb;->a:Lp/Rb;

    .line 4
    .line 5
    iget-object p1, p1, Lp/Rb;->d:Lp/Ub;

    .line 6
    .line 7
    invoke-virtual {p1}, Lp/Ub;->e()V

    .line 8
    .line 9
    .line 10
    :try_start_0
    iget-object v0, p1, Lp/Ub;->c:Lp/Di;

    .line 11
    .line 12
    iget v1, p1, Lp/Ub;->h:I
    :try_end_0
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_0} :catch_0

    .line 13
    .line 14
    iget v3, p0, Lp/Qb;->c:I

    .line 15
    .line 16
    and-int/2addr v1, v3

    .line 17
    if-nez v1, :cond_0

    .line 18
    .line 19
    const/4 v1, 0x1

    .line 20
    :goto_0
    move v4, v1

    .line 21
    goto :goto_1

    .line 22
    :cond_0
    const/4 v1, 0x0

    .line 23
    goto :goto_0

    .line 24
    :goto_1
    :try_start_1
    const-string v5, "quick_control"

    .line 25
    .line 26
    iget-object v0, v0, Lp/Di;->a:Ljava/lang/Object;

    .line 27
    .line 28
    move-object v1, v0

    .line 29
    check-cast v1, Lgringoxp/game/b;

    .line 30
    .line 31
    const/4 v3, 0x0

    .line 32
    move-object v0, v1

    .line 33
    invoke-virtual/range {v0 .. v5}, Lgringoxp/game/b;->Cases(Landroid/content/Context;IIZLjava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_1 .. :try_end_1} :catch_0

    .line 34
    .line 35
    .line 36
    invoke-virtual {p1}, Lp/Ub;->e()V

    .line 37
    .line 38
    .line 39
    iget-object v0, p1, Lp/Ub;->f:Ljava/util/ArrayList;

    .line 40
    .line 41
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 46
    .line 47
    .line 48
    move-result v1

    .line 49
    if-eqz v1, :cond_1

    .line 50
    .line 51
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    check-cast v1, Lp/Pb;

    .line 56
    .line 57
    invoke-virtual {v1}, Lp/Pb;->d()V

    .line 58
    .line 59
    .line 60
    goto :goto_2

    .line 61
    :cond_1
    iget-boolean v0, p1, Lp/Ub;->g:Z

    .line 62
    .line 63
    if-eqz v0, :cond_2

    .line 64
    .line 65
    goto :goto_3

    .line 66
    :cond_2
    iget-object v0, p1, Lp/Ub;->e:Landroid/os/Handler;

    .line 67
    .line 68
    iget-object p1, p1, Lp/Ub;->l:Lp/v2;

    .line 69
    .line 70
    invoke-virtual {v0, p1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 71
    .line 72
    .line 73
    invoke-virtual {v0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 74
    .line 75
    .line 76
    :catch_0
    :goto_3
    return-void
.end method
