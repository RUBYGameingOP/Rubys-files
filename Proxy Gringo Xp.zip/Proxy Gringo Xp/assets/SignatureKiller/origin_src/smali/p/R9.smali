.class public final synthetic Lp/R9;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lio/gringoxp/proxy/garena/freefire/LoginActivity;


# direct methods
.method public synthetic constructor <init>(Lio/gringoxp/proxy/garena/freefire/LoginActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lp/R9;->a:I

    iput-object p1, p0, Lp/R9;->b:Lio/gringoxp/proxy/garena/freefire/LoginActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Lp/R9;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    iget-object v1, v0, Lp/R9;->b:Lio/gringoxp/proxy/garena/freefire/LoginActivity;

    .line 9
    .line 10
    sget-boolean v2, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->Q:Z

    .line 11
    .line 12
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    sget-boolean v2, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->f:Z

    .line 16
    .line 17
    const/4 v3, 0x0

    .line 18
    if-eqz v2, :cond_0

    .line 19
    .line 20
    const-string v2, "Encerre a VPN antes de trocar o aplicativo."

    .line 21
    .line 22
    invoke-static {v1, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 27
    .line 28
    .line 29
    goto/16 :goto_4

    .line 30
    .line 31
    :cond_0
    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 32
    .line 33
    .line 34
    move-result-object v2

    .line 35
    new-instance v4, Landroid/content/Intent;

    .line 36
    .line 37
    const-string v5, "android.intent.action.MAIN"

    .line 38
    .line 39
    invoke-direct {v4, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    const-string v5, "android.intent.category.LAUNCHER"

    .line 43
    .line 44
    invoke-virtual {v4, v5}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    .line 45
    .line 46
    .line 47
    move-result-object v4

    .line 48
    new-instance v5, Ljava/util/ArrayList;

    .line 49
    .line 50
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 51
    .line 52
    .line 53
    invoke-virtual {v2, v4, v3}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    .line 54
    .line 55
    .line 56
    move-result-object v4

    .line 57
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 58
    .line 59
    .line 60
    move-result-object v4

    .line 61
    :cond_1
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 62
    .line 63
    .line 64
    move-result v6

    .line 65
    if-eqz v6, :cond_6

    .line 66
    .line 67
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v6

    .line 71
    check-cast v6, Landroid/content/pm/ResolveInfo;

    .line 72
    .line 73
    iget-object v7, v6, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    .line 74
    .line 75
    if-eqz v7, :cond_1

    .line 76
    .line 77
    iget-object v7, v7, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    .line 78
    .line 79
    if-nez v7, :cond_2

    .line 80
    .line 81
    goto :goto_0

    .line 82
    :cond_2
    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v8

    .line 86
    invoke-virtual {v8, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    move-result v8

    .line 90
    if-eqz v8, :cond_3

    .line 91
    .line 92
    goto :goto_0

    .line 93
    :cond_3
    invoke-virtual {v6, v2}, Landroid/content/pm/ResolveInfo;->loadLabel(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;

    .line 94
    .line 95
    .line 96
    move-result-object v8

    .line 97
    sget-object v9, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 98
    .line 99
    invoke-virtual {v7, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object v9

    .line 103
    const-string v10, "freefire"

    .line 104
    .line 105
    invoke-virtual {v9, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 106
    .line 107
    .line 108
    move-result v9

    .line 109
    if-nez v9, :cond_4

    .line 110
    .line 111
    goto :goto_0

    .line 112
    :cond_4
    new-instance v9, Lp/V9;

    .line 113
    .line 114
    if-nez v8, :cond_5

    .line 115
    .line 116
    move-object v8, v7

    .line 117
    goto :goto_1

    .line 118
    :cond_5
    invoke-interface {v8}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object v8

    .line 122
    :goto_1
    invoke-virtual {v6, v2}, Landroid/content/pm/ResolveInfo;->loadIcon(Landroid/content/pm/PackageManager;)Landroid/graphics/drawable/Drawable;

    .line 123
    .line 124
    .line 125
    move-result-object v6

    .line 126
    invoke-direct {v9, v8, v7, v6}, Lp/V9;-><init>(Ljava/lang/String;Ljava/lang/String;Landroid/graphics/drawable/Drawable;)V

    .line 127
    .line 128
    .line 129
    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 130
    .line 131
    .line 132
    goto :goto_0

    .line 133
    :cond_6
    new-instance v2, Lp/K9;

    .line 134
    .line 135
    const/4 v4, 0x2

    .line 136
    invoke-direct {v2, v4}, Lp/K9;-><init>(I)V

    .line 137
    .line 138
    .line 139
    invoke-static {v2}, Ljava/util/Comparator;->comparing(Ljava/util/function/Function;)Ljava/util/Comparator;

    .line 140
    .line 141
    .line 142
    move-result-object v2

    .line 143
    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->sort(Ljava/util/Comparator;)V

    .line 144
    .line 145
    .line 146
    new-instance v2, Landroid/widget/LinearLayout;

    .line 147
    .line 148
    invoke-direct {v2, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 149
    .line 150
    .line 151
    const/4 v4, 0x1

    .line 152
    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 153
    .line 154
    .line 155
    const/16 v6, 0x8

    .line 156
    .line 157
    invoke-virtual {v1, v6}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 158
    .line 159
    .line 160
    move-result v7

    .line 161
    const/4 v8, 0x4

    .line 162
    invoke-virtual {v1, v8}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 163
    .line 164
    .line 165
    move-result v8

    .line 166
    invoke-virtual {v1, v6}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 167
    .line 168
    .line 169
    move-result v9

    .line 170
    invoke-virtual {v1, v6}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 171
    .line 172
    .line 173
    move-result v10

    .line 174
    invoke-virtual {v2, v7, v8, v9, v10}, Landroid/view/View;->setPadding(IIII)V

    .line 175
    .line 176
    .line 177
    const-string v7, "#090E15"

    .line 178
    .line 179
    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 180
    .line 181
    .line 182
    move-result v8

    .line 183
    invoke-virtual {v2, v8}, Landroid/view/View;->setBackgroundColor(I)V

    .line 184
    .line 185
    .line 186
    invoke-virtual {v1}, Lp/I0;->getResources()Landroid/content/res/Resources;

    .line 187
    .line 188
    .line 189
    move-result-object v8

    .line 190
    invoke-virtual {v8}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 191
    .line 192
    .line 193
    move-result-object v8

    .line 194
    iget v8, v8, Landroid/util/DisplayMetrics;->heightPixels:I

    .line 195
    .line 196
    int-to-float v8, v8

    .line 197
    const v9, 0x3f266666    # 0.65f

    .line 198
    .line 199
    .line 200
    mul-float/2addr v8, v9

    .line 201
    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    .line 202
    .line 203
    .line 204
    move-result v8

    .line 205
    new-instance v9, Landroid/widget/ScrollView;

    .line 206
    .line 207
    invoke-direct {v9, v1}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 208
    .line 209
    .line 210
    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 211
    .line 212
    .line 213
    move-result v10

    .line 214
    invoke-virtual {v9, v10}, Landroid/view/View;->setBackgroundColor(I)V

    .line 215
    .line 216
    .line 217
    invoke-virtual {v9, v2}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 218
    .line 219
    .line 220
    new-instance v10, Landroid/view/ViewGroup$LayoutParams;

    .line 221
    .line 222
    const/4 v11, -0x1

    .line 223
    invoke-direct {v10, v11, v8}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 224
    .line 225
    .line 226
    invoke-virtual {v9, v10}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 227
    .line 228
    .line 229
    const-string v8, "Aplicaci\u00f3n monitoreada por la VPN"

    .line 230
    .line 231
    const/16 v10, 0x10

    .line 232
    .line 233
    invoke-virtual {v1, v8, v10, v11, v4}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->t(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    .line 234
    .line 235
    .line 236
    move-result-object v8

    .line 237
    const/16 v12, 0x12

    .line 238
    .line 239
    invoke-virtual {v1, v12}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 240
    .line 241
    .line 242
    move-result v13

    .line 243
    invoke-virtual {v1, v10}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 244
    .line 245
    .line 246
    move-result v14

    .line 247
    invoke-virtual {v1, v12}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 248
    .line 249
    .line 250
    move-result v12

    .line 251
    const/16 v15, 0xc

    .line 252
    .line 253
    invoke-virtual {v1, v15}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 254
    .line 255
    .line 256
    move-result v4

    .line 257
    invoke-virtual {v8, v13, v14, v12, v4}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 258
    .line 259
    .line 260
    const-string v4, "#0D141F"

    .line 261
    .line 262
    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 263
    .line 264
    .line 265
    move-result v4

    .line 266
    invoke-virtual {v8, v4}, Landroid/view/View;->setBackgroundColor(I)V

    .line 267
    .line 268
    .line 269
    new-instance v4, Lp/x0;

    .line 270
    .line 271
    invoke-direct {v4, v1}, Lp/x0;-><init>(Landroid/content/Context;)V

    .line 272
    .line 273
    .line 274
    iget-object v12, v4, Lp/x0;->b:Ljava/lang/Object;

    .line 275
    .line 276
    check-cast v12, Lp/t0;

    .line 277
    .line 278
    iput-object v8, v12, Lp/t0;->e:Landroid/view/View;

    .line 279
    .line 280
    iput-object v9, v12, Lp/t0;->j:Landroid/widget/ScrollView;

    .line 281
    .line 282
    const-string v8, "Cancelar"

    .line 283
    .line 284
    iput-object v8, v12, Lp/t0;->f:Ljava/lang/String;

    .line 285
    .line 286
    invoke-virtual {v4}, Lp/x0;->a()Lp/y0;

    .line 287
    .line 288
    .line 289
    move-result-object v4

    .line 290
    invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z

    .line 291
    .line 292
    .line 293
    move-result v8

    .line 294
    const/4 v9, -0x2

    .line 295
    if-eqz v8, :cond_7

    .line 296
    .line 297
    const-string v8, "#CBD5E1"

    .line 298
    .line 299
    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 300
    .line 301
    .line 302
    move-result v8

    .line 303
    const-string v12, "Nenhum Free Fire instalado foi encontrado."

    .line 304
    .line 305
    invoke-virtual {v1, v12, v15, v8, v3}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->t(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    .line 306
    .line 307
    .line 308
    move-result-object v8

    .line 309
    const/16 v12, 0x11

    .line 310
    .line 311
    invoke-virtual {v8, v12}, Landroid/widget/TextView;->setGravity(I)V

    .line 312
    .line 313
    .line 314
    invoke-virtual {v1, v10}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 315
    .line 316
    .line 317
    move-result v12

    .line 318
    const/16 v13, 0x1c

    .line 319
    .line 320
    invoke-virtual {v1, v13}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 321
    .line 322
    .line 323
    move-result v14

    .line 324
    invoke-virtual {v1, v10}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 325
    .line 326
    .line 327
    move-result v6

    .line 328
    invoke-virtual {v1, v13}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 329
    .line 330
    .line 331
    move-result v13

    .line 332
    invoke-virtual {v8, v12, v14, v6, v13}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 333
    .line 334
    .line 335
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    .line 336
    .line 337
    invoke-direct {v6, v11, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 338
    .line 339
    .line 340
    invoke-virtual {v2, v8, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 341
    .line 342
    .line 343
    :cond_7
    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 344
    .line 345
    .line 346
    move-result-object v5

    .line 347
    :goto_2
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 348
    .line 349
    .line 350
    move-result v6

    .line 351
    const-string v8, "#26364A"

    .line 352
    .line 353
    if-eqz v6, :cond_9

    .line 354
    .line 355
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 356
    .line 357
    .line 358
    move-result-object v6

    .line 359
    check-cast v6, Lp/V9;

    .line 360
    .line 361
    new-instance v12, Landroid/widget/LinearLayout;

    .line 362
    .line 363
    invoke-direct {v12, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 364
    .line 365
    .line 366
    invoke-virtual {v12, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 367
    .line 368
    .line 369
    invoke-virtual {v12, v10}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 370
    .line 371
    .line 372
    invoke-virtual {v1, v15}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 373
    .line 374
    .line 375
    move-result v13

    .line 376
    const/16 v14, 0x8

    .line 377
    .line 378
    invoke-virtual {v1, v14}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 379
    .line 380
    .line 381
    move-result v10

    .line 382
    invoke-virtual {v1, v15}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 383
    .line 384
    .line 385
    move-result v3

    .line 386
    invoke-virtual {v1, v14}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 387
    .line 388
    .line 389
    move-result v15

    .line 390
    invoke-virtual {v12, v13, v10, v3, v15}, Landroid/view/View;->setPadding(IIII)V

    .line 391
    .line 392
    .line 393
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    .line 394
    .line 395
    invoke-direct {v3, v11, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 396
    .line 397
    .line 398
    const/4 v10, 0x3

    .line 399
    invoke-virtual {v1, v10}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 400
    .line 401
    .line 402
    move-result v13

    .line 403
    invoke-virtual {v1, v10}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 404
    .line 405
    .line 406
    move-result v10

    .line 407
    const/4 v15, 0x0

    .line 408
    invoke-virtual {v3, v15, v13, v15, v10}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 409
    .line 410
    .line 411
    iget-object v10, v6, Lp/V9;->b:Ljava/lang/String;

    .line 412
    .line 413
    iget-object v13, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->K:Ljava/lang/String;

    .line 414
    .line 415
    invoke-virtual {v10, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 416
    .line 417
    .line 418
    move-result v10

    .line 419
    if-eqz v10, :cond_8

    .line 420
    .line 421
    const-string v8, "#153628"

    .line 422
    .line 423
    const-string v10, "#10B981"

    .line 424
    .line 425
    invoke-virtual {v1, v8, v10}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->w(Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/GradientDrawable;

    .line 426
    .line 427
    .line 428
    move-result-object v8

    .line 429
    invoke-virtual {v12, v8}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 430
    .line 431
    .line 432
    goto :goto_3

    .line 433
    :cond_8
    const-string v10, "#111C29"

    .line 434
    .line 435
    invoke-virtual {v1, v10, v8}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->w(Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/GradientDrawable;

    .line 436
    .line 437
    .line 438
    move-result-object v8

    .line 439
    invoke-virtual {v12, v8}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 440
    .line 441
    .line 442
    :goto_3
    new-instance v8, Landroid/widget/ImageView;

    .line 443
    .line 444
    invoke-direct {v8, v1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 445
    .line 446
    .line 447
    iget-object v10, v6, Lp/V9;->c:Landroid/graphics/drawable/Drawable;

    .line 448
    .line 449
    invoke-virtual {v8, v10}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 450
    .line 451
    .line 452
    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    .line 453
    .line 454
    const/16 v13, 0x2a

    .line 455
    .line 456
    invoke-virtual {v1, v13}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 457
    .line 458
    .line 459
    move-result v15

    .line 460
    invoke-virtual {v1, v13}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 461
    .line 462
    .line 463
    move-result v13

    .line 464
    invoke-direct {v10, v15, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 465
    .line 466
    .line 467
    invoke-virtual {v12, v8, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 468
    .line 469
    .line 470
    new-instance v8, Landroid/widget/LinearLayout;

    .line 471
    .line 472
    invoke-direct {v8, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 473
    .line 474
    .line 475
    const/4 v10, 0x1

    .line 476
    invoke-virtual {v8, v10}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 477
    .line 478
    .line 479
    const/16 v13, 0xa

    .line 480
    .line 481
    invoke-virtual {v1, v13}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 482
    .line 483
    .line 484
    move-result v15

    .line 485
    const/4 v14, 0x0

    .line 486
    invoke-virtual {v8, v15, v14, v14, v14}, Landroid/view/View;->setPadding(IIII)V

    .line 487
    .line 488
    .line 489
    iget-object v15, v6, Lp/V9;->a:Ljava/lang/String;

    .line 490
    .line 491
    const/16 v9, 0xd

    .line 492
    .line 493
    invoke-virtual {v1, v15, v9, v11, v10}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->t(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    .line 494
    .line 495
    .line 496
    move-result-object v9

    .line 497
    invoke-virtual {v8, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 498
    .line 499
    .line 500
    iget-object v9, v6, Lp/V9;->b:Ljava/lang/String;

    .line 501
    .line 502
    const v15, -0x333334

    .line 503
    .line 504
    .line 505
    invoke-virtual {v1, v9, v13, v15, v14}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->t(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    .line 506
    .line 507
    .line 508
    move-result-object v9

    .line 509
    invoke-virtual {v8, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 510
    .line 511
    .line 512
    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    .line 513
    .line 514
    const/high16 v13, 0x3f800000    # 1.0f

    .line 515
    .line 516
    const/4 v15, -0x2

    .line 517
    invoke-direct {v9, v14, v15, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 518
    .line 519
    .line 520
    invoke-virtual {v12, v8, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 521
    .line 522
    .line 523
    new-instance v8, Lp/T9;

    .line 524
    .line 525
    invoke-direct {v8, v1, v6, v4}, Lp/T9;-><init>(Lio/gringoxp/proxy/garena/freefire/LoginActivity;Lp/V9;Lp/y0;)V

    .line 526
    .line 527
    .line 528
    invoke-virtual {v12, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 529
    .line 530
    .line 531
    invoke-virtual {v2, v12, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 532
    .line 533
    .line 534
    move v3, v14

    .line 535
    move v9, v15

    .line 536
    const/16 v10, 0x10

    .line 537
    .line 538
    const/16 v15, 0xc

    .line 539
    .line 540
    goto/16 :goto_2

    .line 541
    .line 542
    :cond_9
    invoke-virtual {v4}, Landroid/app/Dialog;->show()V

    .line 543
    .line 544
    .line 545
    invoke-virtual {v4}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 546
    .line 547
    .line 548
    move-result-object v2

    .line 549
    if-eqz v2, :cond_a

    .line 550
    .line 551
    invoke-virtual {v4}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 552
    .line 553
    .line 554
    move-result-object v2

    .line 555
    invoke-virtual {v1, v7, v8}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->w(Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/GradientDrawable;

    .line 556
    .line 557
    .line 558
    move-result-object v1

    .line 559
    invoke-virtual {v2, v1}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 560
    .line 561
    .line 562
    :cond_a
    iget-object v1, v4, Lp/y0;->f:Lp/w0;

    .line 563
    .line 564
    iget-object v1, v1, Lp/w0;->i:Landroid/widget/Button;

    .line 565
    .line 566
    const-string v2, "#34D399"

    .line 567
    .line 568
    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 569
    .line 570
    .line 571
    move-result v2

    .line 572
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 573
    .line 574
    .line 575
    :goto_4
    return-void

    .line 576
    :pswitch_0
    iget-object v1, v0, Lp/R9;->b:Lio/gringoxp/proxy/garena/freefire/LoginActivity;

    .line 577
    .line 578
    invoke-static {v1}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->r(Lio/gringoxp/proxy/garena/freefire/LoginActivity;)V

    .line 579
    .line 580
    .line 581
    return-void

    .line 582
    :pswitch_1
    sget-boolean v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->Q:Z

    .line 583
    .line 584
    iget-object v1, v0, Lp/R9;->b:Lio/gringoxp/proxy/garena/freefire/LoginActivity;

    .line 585
    .line 586
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 587
    .line 588
    .line 589
    invoke-static {v1}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    .line 590
    .line 591
    .line 592
    move-result v2

    .line 593
    if-nez v2, :cond_b

    .line 594
    .line 595
    new-instance v2, Landroid/content/Intent;

    .line 596
    .line 597
    new-instance v3, Ljava/lang/StringBuilder;

    .line 598
    .line 599
    const-string v4, "package:"

    .line 600
    .line 601
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 602
    .line 603
    .line 604
    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 605
    .line 606
    .line 607
    move-result-object v4

    .line 608
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 609
    .line 610
    .line 611
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 612
    .line 613
    .line 614
    move-result-object v3

    .line 615
    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 616
    .line 617
    .line 618
    move-result-object v3

    .line 619
    const-string v4, "android.settings.action.MANAGE_OVERLAY_PERMISSION"

    .line 620
    .line 621
    invoke-direct {v2, v4, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 622
    .line 623
    .line 624
    invoke-virtual {v1, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 625
    .line 626
    .line 627
    :cond_b
    return-void

    .line 628
    nop

    .line 629
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
