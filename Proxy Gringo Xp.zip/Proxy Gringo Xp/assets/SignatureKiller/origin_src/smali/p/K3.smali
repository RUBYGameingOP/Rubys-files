.class public interface abstract Lp/K3;
.super Ljava/lang/Object;
.source "SourceFile"
