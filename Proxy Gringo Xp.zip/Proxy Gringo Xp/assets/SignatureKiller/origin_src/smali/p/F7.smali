.class public final Lp/F7;
.super Ljava/lang/RuntimeException;
.source "SourceFile"


# instance fields
.field public final a:Lp/m7;


# direct methods
.method public constructor <init>(Lp/m7;Ljava/lang/String;)V
    .locals 1

    .line 1
    const-string v0, "fragment"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lp/M8;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lp/F7;->a:Lp/m7;

    .line 10
    .line 11
    return-void
.end method
