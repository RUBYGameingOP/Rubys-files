.class public interface abstract Lp/L3;
.super Ljava/lang/Object;
.source "SourceFile"
