.class public abstract Lp/Oe;
.super Lp/Ne;
.source "SourceFile"
