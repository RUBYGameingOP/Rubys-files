.class public final Lp/Bc;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:F

.field public b:F

.field public c:F

.field public d:Z

.field public e:Z


# direct methods
.method public constructor <init>(F)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    mul-float/2addr p1, p1

    .line 5
    iput p1, p0, Lp/Bc;->a:F

    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final a(FF)Z
    .locals 2

    .line 1
    iget-boolean v0, p0, Lp/Bc;->d:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    return v1

    .line 7
    :cond_0
    iget v0, p0, Lp/Bc;->b:F

    .line 8
    .line 9
    sub-float/2addr p1, v0

    .line 10
    iget v0, p0, Lp/Bc;->c:F

    .line 11
    .line 12
    sub-float/2addr p2, v0

    .line 13
    iget-boolean v0, p0, Lp/Bc;->e:Z

    .line 14
    .line 15
    mul-float/2addr p1, p1

    .line 16
    mul-float/2addr p2, p2

    .line 17
    add-float/2addr p2, p1

    .line 18
    iget p1, p0, Lp/Bc;->a:F

    .line 19
    .line 20
    cmpl-float p1, p2, p1

    .line 21
    .line 22
    if-lez p1, :cond_1

    .line 23
    .line 24
    const/4 v1, 0x1

    .line 25
    :cond_1
    or-int p1, v0, v1

    .line 26
    .line 27
    iput-boolean p1, p0, Lp/Bc;->e:Z

    .line 28
    .line 29
    return p1
.end method
