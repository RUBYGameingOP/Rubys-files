.class public final Lp/Sb;
.super Landroid/view/View;
.source "SourceFile"


# instance fields
.field public final a:Lp/Pb;

.field public final b:Landroid/graphics/Paint;

.field public c:Ljava/lang/String;

.field public d:I

.field public e:I

.field public f:Z

.field public g:Z

.field public final synthetic h:Lp/Ub;


# direct methods
.method public constructor <init>(Lp/Ub;Lp/Pb;)V
    .locals 1

    .line 1
    iput-object p1, p0, Lp/Sb;->h:Lp/Ub;

    .line 2
    .line 3
    iget-object p1, p1, Lp/Ub;->a:Lgringoxp/game/b;

    .line 4
    .line 5
    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 6
    .line 7
    .line 8
    new-instance p1, Landroid/graphics/Paint;

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    invoke-direct {p1, v0}, Landroid/graphics/Paint;-><init>(I)V

    .line 12
    .line 13
    .line 14
    iput-object p1, p0, Lp/Sb;->b:Landroid/graphics/Paint;

    .line 15
    .line 16
    const-string p1, "OFF"

    .line 17
    .line 18
    iput-object p1, p0, Lp/Sb;->c:Ljava/lang/String;

    .line 19
    .line 20
    iput-object p2, p0, Lp/Sb;->a:Lp/Pb;

    .line 21
    .line 22
    invoke-virtual {p0, v0}, Landroid/view/View;->setImportantForAccessibility(I)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {p0, v0}, Landroid/view/View;->setFocusable(Z)V

    .line 26
    .line 27
    .line 28
    return-void
.end method


# virtual methods
.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v10, p1

    .line 4
    .line 5
    invoke-super/range {p0 .. p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    .line 9
    .line 10
    .line 11
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    int-to-float v1, v1

    .line 16
    const/high16 v2, 0x42800000    # 64.0f

    .line 17
    .line 18
    div-float/2addr v1, v2

    .line 19
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    int-to-float v2, v2

    .line 24
    const/high16 v3, 0x429c0000    # 78.0f

    .line 25
    .line 26
    div-float/2addr v2, v3

    .line 27
    invoke-virtual {v10, v1, v2}, Landroid/graphics/Canvas;->scale(FF)V

    .line 28
    .line 29
    .line 30
    iget-object v11, v0, Lp/Sb;->b:Landroid/graphics/Paint;

    .line 31
    .line 32
    sget-object v12, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    .line 33
    .line 34
    invoke-virtual {v11, v12}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 35
    .line 36
    .line 37
    const v1, -0x12eae4d7

    .line 38
    .line 39
    .line 40
    invoke-virtual {v11, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 41
    .line 42
    .line 43
    const/high16 v1, 0x41d00000    # 26.0f

    .line 44
    .line 45
    const/high16 v13, 0x42000000    # 32.0f

    .line 46
    .line 47
    const/high16 v2, 0x41e80000    # 29.0f

    .line 48
    .line 49
    invoke-virtual {v10, v13, v2, v1, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 50
    .line 51
    .line 52
    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 53
    .line 54
    invoke-virtual {v11, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 55
    .line 56
    .line 57
    iget-boolean v1, v0, Lp/Sb;->f:Z

    .line 58
    .line 59
    if-eqz v1, :cond_0

    .line 60
    .line 61
    const v1, 0x400ccccd    # 2.2f

    .line 62
    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_0
    const v1, 0x3fa66666    # 1.3f

    .line 66
    .line 67
    .line 68
    :goto_0
    invoke-virtual {v11, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 69
    .line 70
    .line 71
    iget-boolean v1, v0, Lp/Sb;->f:Z

    .line 72
    .line 73
    iget-object v15, v0, Lp/Sb;->a:Lp/Pb;

    .line 74
    .line 75
    if-eqz v1, :cond_1

    .line 76
    .line 77
    iget v1, v15, Lp/Pb;->e:I

    .line 78
    .line 79
    goto :goto_1

    .line 80
    :cond_1
    const v1, -0x968d7a

    .line 81
    .line 82
    .line 83
    :goto_1
    invoke-virtual {v11, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 84
    .line 85
    .line 86
    const/high16 v1, 0x41c80000    # 25.0f

    .line 87
    .line 88
    invoke-virtual {v10, v13, v2, v1, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 89
    .line 90
    .line 91
    iget v1, v0, Lp/Sb;->e:I

    .line 92
    .line 93
    const/high16 v9, 0x3f800000    # 1.0f

    .line 94
    .line 95
    if-lez v1, :cond_2

    .line 96
    .line 97
    iget v1, v0, Lp/Sb;->d:I

    .line 98
    .line 99
    if-lez v1, :cond_2

    .line 100
    .line 101
    const/high16 v1, 0x40200000    # 2.5f

    .line 102
    .line 103
    invoke-virtual {v11, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 104
    .line 105
    .line 106
    iget v1, v15, Lp/Pb;->e:I

    .line 107
    .line 108
    invoke-virtual {v11, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 109
    .line 110
    .line 111
    iget v1, v0, Lp/Sb;->d:I

    .line 112
    .line 113
    int-to-float v1, v1

    .line 114
    iget v2, v0, Lp/Sb;->e:I

    .line 115
    .line 116
    int-to-float v2, v2

    .line 117
    div-float/2addr v1, v2

    .line 118
    invoke-static {v9, v1}, Ljava/lang/Math;->min(FF)F

    .line 119
    .line 120
    .line 121
    move-result v1

    .line 122
    const/high16 v2, 0x43b40000    # 360.0f

    .line 123
    .line 124
    mul-float v7, v1, v2

    .line 125
    .line 126
    const/4 v8, 0x0

    .line 127
    const/high16 v2, 0x41100000    # 9.0f

    .line 128
    .line 129
    const/high16 v3, 0x40c00000    # 6.0f

    .line 130
    .line 131
    const/high16 v4, 0x425c0000    # 55.0f

    .line 132
    .line 133
    const/high16 v5, 0x42500000    # 52.0f

    .line 134
    .line 135
    const/high16 v6, -0x3d4c0000    # -90.0f

    .line 136
    .line 137
    move-object/from16 v1, p1

    .line 138
    .line 139
    move v14, v9

    .line 140
    move-object v9, v11

    .line 141
    invoke-virtual/range {v1 .. v9}, Landroid/graphics/Canvas;->drawArc(FFFFFFZLandroid/graphics/Paint;)V

    .line 142
    .line 143
    .line 144
    goto :goto_2

    .line 145
    :cond_2
    move v14, v9

    .line 146
    :goto_2
    iget v4, v15, Lp/Pb;->c:I

    .line 147
    .line 148
    const/high16 v7, 0x41e00000    # 28.0f

    .line 149
    .line 150
    iget v8, v15, Lp/Pb;->e:I

    .line 151
    .line 152
    iget-object v1, v0, Lp/Sb;->h:Lp/Ub;

    .line 153
    .line 154
    const/high16 v5, 0x41900000    # 18.0f

    .line 155
    .line 156
    const/high16 v6, 0x41500000    # 13.0f

    .line 157
    .line 158
    move-object/from16 v2, p1

    .line 159
    .line 160
    move-object v3, v11

    .line 161
    invoke-static/range {v1 .. v8}, Lp/Ub;->a(Lp/Ub;Landroid/graphics/Canvas;Landroid/graphics/Paint;IFFFI)V

    .line 162
    .line 163
    .line 164
    invoke-virtual {v11, v12}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 165
    .line 166
    .line 167
    iget-boolean v1, v0, Lp/Sb;->g:Z

    .line 168
    .line 169
    if-eqz v1, :cond_3

    .line 170
    .line 171
    iget v1, v15, Lp/Pb;->e:I

    .line 172
    .line 173
    goto :goto_3

    .line 174
    :cond_3
    const v1, -0x968d7a

    .line 175
    .line 176
    .line 177
    :goto_3
    invoke-virtual {v11, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 178
    .line 179
    .line 180
    const/high16 v1, 0x40800000    # 4.0f

    .line 181
    .line 182
    const/high16 v2, 0x424c0000    # 51.0f

    .line 183
    .line 184
    const/high16 v3, 0x41300000    # 11.0f

    .line 185
    .line 186
    invoke-virtual {v10, v2, v3, v1, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 187
    .line 188
    .line 189
    sget-object v1, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    .line 190
    .line 191
    invoke-virtual {v11, v1}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 192
    .line 193
    .line 194
    sget-object v1, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    .line 195
    .line 196
    invoke-virtual {v11, v1}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 197
    .line 198
    .line 199
    const/high16 v1, 0x41000000    # 8.0f

    .line 200
    .line 201
    invoke-virtual {v11, v1}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 202
    .line 203
    .line 204
    const/4 v1, -0x1

    .line 205
    invoke-virtual {v11, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 206
    .line 207
    .line 208
    iget-object v1, v15, Lp/Pb;->a:Ljava/lang/String;

    .line 209
    .line 210
    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 211
    .line 212
    invoke-virtual {v1, v2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 213
    .line 214
    .line 215
    move-result-object v1

    .line 216
    const/high16 v2, 0x42480000    # 50.0f

    .line 217
    .line 218
    invoke-virtual {v10, v1, v13, v2, v11}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 219
    .line 220
    .line 221
    iget-boolean v1, v0, Lp/Sb;->f:Z

    .line 222
    .line 223
    if-eqz v1, :cond_4

    .line 224
    .line 225
    iget v1, v15, Lp/Pb;->e:I

    .line 226
    .line 227
    goto :goto_4

    .line 228
    :cond_4
    const v1, -0x504632

    .line 229
    .line 230
    .line 231
    :goto_4
    invoke-virtual {v11, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 232
    .line 233
    .line 234
    const/high16 v1, 0x41200000    # 10.0f

    .line 235
    .line 236
    invoke-virtual {v11, v1}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 237
    .line 238
    .line 239
    const/4 v1, 0x0

    .line 240
    const/high16 v2, -0x1000000

    .line 241
    .line 242
    const/high16 v3, 0x40000000    # 2.0f

    .line 243
    .line 244
    invoke-virtual {v11, v3, v1, v14, v2}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    .line 245
    .line 246
    .line 247
    iget-object v1, v0, Lp/Sb;->c:Ljava/lang/String;

    .line 248
    .line 249
    const/high16 v2, 0x428a0000    # 69.0f

    .line 250
    .line 251
    invoke-virtual {v10, v1, v13, v2, v11}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 252
    .line 253
    .line 254
    invoke-virtual {v11}, Landroid/graphics/Paint;->clearShadowLayer()V

    .line 255
    .line 256
    .line 257
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->restore()V

    .line 258
    .line 259
    .line 260
    return-void
.end method
