.class public abstract Lp/Le;
.super Ljava/lang/Exception;
.source "SourceFile"
