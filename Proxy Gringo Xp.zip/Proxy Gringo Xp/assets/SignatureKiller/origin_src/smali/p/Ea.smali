.class public interface abstract Lp/Ea;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract h(Lp/Ga;Landroid/view/MenuItem;)Z
.end method

.method public abstract v(Lp/Ga;)V
.end method
