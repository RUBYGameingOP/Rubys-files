.class public final Lp/Sf;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/String;

.field public final d:J

.field public final e:J

.field public final f:J

.field public final g:J

.field public final h:J


# direct methods
.method public constructor <init>(Lp/Tf;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p1, Lp/Tf;->a:Ljava/lang/String;

    .line 5
    .line 6
    iput-object v0, p0, Lp/Sf;->a:Ljava/lang/String;

    .line 7
    .line 8
    iget-object v0, p1, Lp/Tf;->b:Ljava/lang/String;

    .line 9
    .line 10
    iput-object v0, p0, Lp/Sf;->b:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v0, p1, Lp/Tf;->c:Ljava/lang/String;

    .line 13
    .line 14
    iput-object v0, p0, Lp/Sf;->c:Ljava/lang/String;

    .line 15
    .line 16
    iget-object v0, p1, Lp/Tf;->d:Ljava/util/concurrent/atomic/AtomicLong;

    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 19
    .line 20
    .line 21
    move-result-wide v0

    .line 22
    iput-wide v0, p0, Lp/Sf;->d:J

    .line 23
    .line 24
    iget-object v0, p1, Lp/Tf;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 25
    .line 26
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 27
    .line 28
    .line 29
    move-result-wide v0

    .line 30
    iput-wide v0, p0, Lp/Sf;->e:J

    .line 31
    .line 32
    iget-object v0, p1, Lp/Tf;->f:Ljava/util/concurrent/atomic/AtomicLong;

    .line 33
    .line 34
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 35
    .line 36
    .line 37
    move-result-wide v0

    .line 38
    iput-wide v0, p0, Lp/Sf;->f:J

    .line 39
    .line 40
    iget-object v0, p1, Lp/Tf;->g:Ljava/util/concurrent/atomic/AtomicLong;

    .line 41
    .line 42
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 43
    .line 44
    .line 45
    move-result-wide v0

    .line 46
    iput-wide v0, p0, Lp/Sf;->g:J

    .line 47
    .line 48
    iget-wide v0, p1, Lp/Tf;->h:J

    .line 49
    .line 50
    iput-wide v0, p0, Lp/Sf;->h:J

    .line 51
    .line 52
    return-void
.end method
