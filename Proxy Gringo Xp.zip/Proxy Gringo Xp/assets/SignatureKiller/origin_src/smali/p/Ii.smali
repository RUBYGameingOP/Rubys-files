.class public final Lp/Ii;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:[I

.field public final synthetic b:Landroid/graphics/drawable/GradientDrawable;

.field public final synthetic c:Landroid/view/View;

.field public final synthetic d:Lp/s1;

.field public final synthetic e:Lgringoxp/game/b;


# direct methods
.method public constructor <init>(Lgringoxp/game/b;[ILandroid/graphics/drawable/GradientDrawable;Landroid/view/View;Lp/s1;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lp/Ii;->e:Lgringoxp/game/b;

    .line 5
    .line 6
    iput-object p2, p0, Lp/Ii;->a:[I

    .line 7
    .line 8
    iput-object p3, p0, Lp/Ii;->b:Landroid/graphics/drawable/GradientDrawable;

    .line 9
    .line 10
    iput-object p4, p0, Lp/Ii;->c:Landroid/view/View;

    .line 11
    .line 12
    iput-object p5, p0, Lp/Ii;->d:Lp/s1;

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Lp/Ii;->a:[I

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    aget v1, v1, v2

    .line 7
    .line 8
    new-instance v3, Lp/Di;

    .line 9
    .line 10
    invoke-direct {v3, v0}, Lp/Di;-><init>(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    sget-object v4, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 14
    .line 15
    iget-object v4, v0, Lp/Ii;->e:Lgringoxp/game/b;

    .line 16
    .line 17
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    sget-object v4, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 21
    .line 22
    const-string v5, "window"

    .line 23
    .line 24
    invoke-virtual {v4, v5}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v4

    .line 28
    check-cast v4, Landroid/view/WindowManager;

    .line 29
    .line 30
    const/4 v5, 0x3

    .line 31
    new-array v6, v5, [F

    .line 32
    .line 33
    invoke-static {v1, v6}, Landroid/graphics/Color;->colorToHSV(I[F)V

    .line 34
    .line 35
    .line 36
    new-instance v6, Landroid/view/WindowManager$LayoutParams;

    .line 37
    .line 38
    const/16 v7, 0x104

    .line 39
    .line 40
    invoke-static {v7}, Lgringoxp/game/b;->s(I)I

    .line 41
    .line 42
    .line 43
    move-result v8

    .line 44
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 45
    .line 46
    const/16 v9, 0x1a

    .line 47
    .line 48
    if-lt v7, v9, :cond_0

    .line 49
    .line 50
    const/16 v7, 0x7f6

    .line 51
    .line 52
    :goto_0
    move v10, v7

    .line 53
    goto :goto_1

    .line 54
    :cond_0
    const/16 v7, 0x7d2

    .line 55
    .line 56
    goto :goto_0

    .line 57
    :goto_1
    const v11, 0x40020

    .line 58
    .line 59
    .line 60
    const/4 v12, -0x3

    .line 61
    const/4 v9, -0x2

    .line 62
    move-object v7, v6

    .line 63
    invoke-direct/range {v7 .. v12}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    .line 64
    .line 65
    .line 66
    const/16 v7, 0x11

    .line 67
    .line 68
    iput v7, v6, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 69
    .line 70
    new-instance v8, Lp/Ji;

    .line 71
    .line 72
    sget-object v9, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 73
    .line 74
    invoke-direct {v8, v9, v4}, Lp/Ji;-><init>(Lgringoxp/game/b;Landroid/view/WindowManager;)V

    .line 75
    .line 76
    .line 77
    const/4 v9, 0x1

    .line 78
    invoke-virtual {v8, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 79
    .line 80
    .line 81
    const/16 v10, 0xf

    .line 82
    .line 83
    invoke-static {v10}, Lgringoxp/game/b;->s(I)I

    .line 84
    .line 85
    .line 86
    move-result v11

    .line 87
    invoke-static {v10}, Lgringoxp/game/b;->s(I)I

    .line 88
    .line 89
    .line 90
    move-result v12

    .line 91
    invoke-static {v10}, Lgringoxp/game/b;->s(I)I

    .line 92
    .line 93
    .line 94
    move-result v13

    .line 95
    invoke-static {v10}, Lgringoxp/game/b;->s(I)I

    .line 96
    .line 97
    .line 98
    move-result v14

    .line 99
    invoke-virtual {v8, v11, v12, v13, v14}, Landroid/view/View;->setPadding(IIII)V

    .line 100
    .line 101
    .line 102
    new-instance v11, Landroid/graphics/drawable/GradientDrawable;

    .line 103
    .line 104
    invoke-direct {v11}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 105
    .line 106
    .line 107
    const-string v12, "#121212"

    .line 108
    .line 109
    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 110
    .line 111
    .line 112
    move-result v12

    .line 113
    invoke-virtual {v11, v12}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 114
    .line 115
    .line 116
    invoke-static {v10}, Lgringoxp/game/b;->s(I)I

    .line 117
    .line 118
    .line 119
    move-result v12

    .line 120
    int-to-float v12, v12

    .line 121
    invoke-virtual {v11, v12}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 122
    .line 123
    .line 124
    invoke-static {v9}, Lgringoxp/game/b;->s(I)I

    .line 125
    .line 126
    .line 127
    move-result v12

    .line 128
    const-string v13, "#333333"

    .line 129
    .line 130
    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 131
    .line 132
    .line 133
    move-result v13

    .line 134
    invoke-virtual {v11, v12, v13}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 135
    .line 136
    .line 137
    invoke-virtual {v8, v11}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 138
    .line 139
    .line 140
    new-instance v11, Landroid/widget/LinearLayout;

    .line 141
    .line 142
    sget-object v12, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 143
    .line 144
    invoke-direct {v11, v12}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 145
    .line 146
    .line 147
    invoke-virtual {v11, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 148
    .line 149
    .line 150
    invoke-virtual {v11, v7}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 151
    .line 152
    .line 153
    new-array v7, v5, [F

    .line 154
    .line 155
    invoke-static {v1, v7}, Landroid/graphics/Color;->colorToHSV(I[F)V

    .line 156
    .line 157
    .line 158
    new-instance v12, Lp/Qd;

    .line 159
    .line 160
    sget-object v13, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 161
    .line 162
    aget v14, v7, v2

    .line 163
    .line 164
    invoke-direct {v12, v13}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 165
    .line 166
    .line 167
    iput v14, v12, Lp/Qd;->a:F

    .line 168
    .line 169
    const/4 v13, 0x0

    .line 170
    iput-object v13, v12, Lp/Qd;->d:Lp/g2;

    .line 171
    .line 172
    new-array v5, v5, [F

    .line 173
    .line 174
    invoke-static {v1, v5}, Landroid/graphics/Color;->colorToHSV(I[F)V

    .line 175
    .line 176
    .line 177
    aget v13, v5, v9

    .line 178
    .line 179
    iput v13, v12, Lp/Qd;->b:F

    .line 180
    .line 181
    const/4 v13, 0x2

    .line 182
    aget v5, v5, v13

    .line 183
    .line 184
    iput v5, v12, Lp/Qd;->c:F

    .line 185
    .line 186
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    .line 187
    .line 188
    const/16 v14, 0xc8

    .line 189
    .line 190
    invoke-virtual {v12, v14}, Lp/Qd;->a(I)I

    .line 191
    .line 192
    .line 193
    move-result v15

    .line 194
    invoke-virtual {v12, v14}, Lp/Qd;->a(I)I

    .line 195
    .line 196
    .line 197
    move-result v10

    .line 198
    invoke-direct {v5, v15, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 199
    .line 200
    .line 201
    invoke-virtual {v12, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 202
    .line 203
    .line 204
    new-instance v5, Landroid/graphics/Paint;

    .line 205
    .line 206
    invoke-direct {v5, v9}, Landroid/graphics/Paint;-><init>(I)V

    .line 207
    .line 208
    .line 209
    iput-object v5, v12, Lp/Qd;->e:Landroid/graphics/Paint;

    .line 210
    .line 211
    sget-object v10, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 212
    .line 213
    invoke-virtual {v5, v10}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 214
    .line 215
    .line 216
    invoke-virtual {v12, v13}, Lp/Qd;->a(I)I

    .line 217
    .line 218
    .line 219
    move-result v15

    .line 220
    int-to-float v15, v15

    .line 221
    invoke-virtual {v5, v15}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 222
    .line 223
    .line 224
    const/4 v15, -0x1

    .line 225
    invoke-virtual {v5, v15}, Landroid/graphics/Paint;->setColor(I)V

    .line 226
    .line 227
    .line 228
    new-instance v5, Lp/x8;

    .line 229
    .line 230
    sget-object v2, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 231
    .line 232
    new-instance v15, Lp/Di;

    .line 233
    .line 234
    invoke-direct {v15, v12}, Lp/Di;-><init>(Ljava/lang/Object;)V

    .line 235
    .line 236
    .line 237
    invoke-direct {v5, v2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 238
    .line 239
    .line 240
    const/4 v2, 0x0

    .line 241
    iput v2, v5, Lp/x8;->a:F

    .line 242
    .line 243
    iput-object v15, v5, Lp/x8;->b:Lp/Di;

    .line 244
    .line 245
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 246
    .line 247
    const/16 v15, 0x19

    .line 248
    .line 249
    invoke-virtual {v5, v15}, Lp/x8;->a(I)I

    .line 250
    .line 251
    .line 252
    move-result v15

    .line 253
    invoke-virtual {v5, v14}, Lp/x8;->a(I)I

    .line 254
    .line 255
    .line 256
    move-result v14

    .line 257
    invoke-direct {v2, v15, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 258
    .line 259
    .line 260
    invoke-virtual {v5, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 261
    .line 262
    .line 263
    new-instance v2, Landroid/graphics/Paint;

    .line 264
    .line 265
    invoke-direct {v2, v9}, Landroid/graphics/Paint;-><init>(I)V

    .line 266
    .line 267
    .line 268
    iput-object v2, v5, Lp/x8;->c:Landroid/graphics/Paint;

    .line 269
    .line 270
    invoke-virtual {v2, v10}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 271
    .line 272
    .line 273
    invoke-virtual {v5, v13}, Lp/x8;->a(I)I

    .line 274
    .line 275
    .line 276
    move-result v10

    .line 277
    int-to-float v10, v10

    .line 278
    invoke-virtual {v2, v10}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 279
    .line 280
    .line 281
    const/4 v10, -0x1

    .line 282
    invoke-virtual {v2, v10}, Landroid/graphics/Paint;->setColor(I)V

    .line 283
    .line 284
    .line 285
    const/4 v2, 0x0

    .line 286
    aget v7, v7, v2

    .line 287
    .line 288
    invoke-virtual {v5, v7}, Lp/x8;->setInitialHue(F)V

    .line 289
    .line 290
    .line 291
    invoke-virtual {v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 292
    .line 293
    .line 294
    new-instance v2, Landroid/view/View;

    .line 295
    .line 296
    sget-object v7, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 297
    .line 298
    invoke-direct {v2, v7}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 299
    .line 300
    .line 301
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    .line 302
    .line 303
    const/16 v10, 0xa

    .line 304
    .line 305
    invoke-static {v10}, Lgringoxp/game/b;->s(I)I

    .line 306
    .line 307
    .line 308
    move-result v13

    .line 309
    invoke-direct {v7, v13, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 310
    .line 311
    .line 312
    invoke-virtual {v2, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 313
    .line 314
    .line 315
    invoke-virtual {v11, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 316
    .line 317
    .line 318
    invoke-virtual {v11, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 319
    .line 320
    .line 321
    invoke-virtual {v8, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 322
    .line 323
    .line 324
    new-instance v2, Landroid/widget/TextView;

    .line 325
    .line 326
    sget-object v5, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 327
    .line 328
    invoke-direct {v2, v5}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 329
    .line 330
    .line 331
    const-string v5, "#AAAAAA"

    .line 332
    .line 333
    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 334
    .line 335
    .line 336
    move-result v5

    .line 337
    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 338
    .line 339
    .line 340
    const/high16 v5, 0x41200000    # 10.0f

    .line 341
    .line 342
    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setTextSize(F)V

    .line 343
    .line 344
    .line 345
    invoke-static {v10}, Lgringoxp/game/b;->s(I)I

    .line 346
    .line 347
    .line 348
    move-result v5

    .line 349
    const/4 v7, 0x5

    .line 350
    invoke-static {v7}, Lgringoxp/game/b;->s(I)I

    .line 351
    .line 352
    .line 353
    move-result v9

    .line 354
    const/4 v10, 0x0

    .line 355
    invoke-virtual {v2, v10, v5, v10, v9}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 356
    .line 357
    .line 358
    sget-object v5, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    .line 359
    .line 360
    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 361
    .line 362
    .line 363
    invoke-virtual {v8, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 364
    .line 365
    .line 366
    new-instance v5, Landroid/view/View;

    .line 367
    .line 368
    sget-object v9, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 369
    .line 370
    invoke-direct {v5, v9}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 371
    .line 372
    .line 373
    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    .line 374
    .line 375
    const/16 v10, 0x1e

    .line 376
    .line 377
    invoke-static {v10}, Lgringoxp/game/b;->s(I)I

    .line 378
    .line 379
    .line 380
    move-result v10

    .line 381
    const/4 v11, -0x1

    .line 382
    invoke-direct {v9, v11, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 383
    .line 384
    .line 385
    invoke-virtual {v5, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 386
    .line 387
    .line 388
    new-instance v9, Landroid/graphics/drawable/GradientDrawable;

    .line 389
    .line 390
    invoke-direct {v9}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 391
    .line 392
    .line 393
    invoke-static {v7}, Lgringoxp/game/b;->s(I)I

    .line 394
    .line 395
    .line 396
    move-result v7

    .line 397
    int-to-float v7, v7

    .line 398
    invoke-virtual {v9, v7}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 399
    .line 400
    .line 401
    invoke-virtual {v9, v1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 402
    .line 403
    .line 404
    invoke-virtual {v5, v9}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 405
    .line 406
    .line 407
    invoke-virtual {v8, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 408
    .line 409
    .line 410
    new-instance v7, Lp/g2;

    .line 411
    .line 412
    const/16 v9, 0x8

    .line 413
    .line 414
    invoke-direct {v7, v5, v2, v3, v9}, Lp/g2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 415
    .line 416
    .line 417
    iput-object v7, v12, Lp/Qd;->d:Lp/g2;

    .line 418
    .line 419
    invoke-virtual {v7, v1}, Lp/g2;->z(I)V

    .line 420
    .line 421
    .line 422
    new-instance v1, Landroid/widget/Button;

    .line 423
    .line 424
    sget-object v2, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 425
    .line 426
    invoke-direct {v1, v2}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 427
    .line 428
    .line 429
    const-string v2, "SALVAR CONFIGURA\u00c7\u00c3O"

    .line 430
    .line 431
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 432
    .line 433
    .line 434
    const/4 v2, -0x1

    .line 435
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 436
    .line 437
    .line 438
    const/high16 v3, 0x41300000    # 11.0f

    .line 439
    .line 440
    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setTextSize(F)V

    .line 441
    .line 442
    .line 443
    const-string v3, "#252525"

    .line 444
    .line 445
    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 446
    .line 447
    .line 448
    move-result v3

    .line 449
    invoke-virtual {v1, v3}, Landroid/view/View;->setBackgroundColor(I)V

    .line 450
    .line 451
    .line 452
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    .line 453
    .line 454
    const/16 v5, 0x26

    .line 455
    .line 456
    invoke-static {v5}, Lgringoxp/game/b;->s(I)I

    .line 457
    .line 458
    .line 459
    move-result v5

    .line 460
    invoke-direct {v3, v2, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 461
    .line 462
    .line 463
    const/16 v2, 0xf

    .line 464
    .line 465
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 466
    .line 467
    .line 468
    move-result v2

    .line 469
    const/4 v5, 0x0

    .line 470
    invoke-virtual {v3, v5, v2, v5, v5}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 471
    .line 472
    .line 473
    invoke-virtual {v1, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 474
    .line 475
    .line 476
    new-instance v2, Lp/If;

    .line 477
    .line 478
    invoke-direct {v2, v4, v8}, Lp/If;-><init>(Landroid/view/WindowManager;Lp/Ji;)V

    .line 479
    .line 480
    .line 481
    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 482
    .line 483
    .line 484
    invoke-virtual {v8, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 485
    .line 486
    .line 487
    invoke-interface {v4, v8, v6}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 488
    .line 489
    .line 490
    return-void
.end method
