.class public final synthetic Lp/Rf;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Function;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;I)V
    .locals 0

    .line 1
    iput p2, p0, Lp/Rf;->a:I

    iput-object p1, p0, Lp/Rf;->b:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, Lp/Rf;->a:I

    .line 2
    .line 3
    check-cast p1, Ljava/lang/String;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    new-instance p1, Lp/Tf;

    .line 9
    .line 10
    const-string v0, "TCP"

    .line 11
    .line 12
    iget-object v1, p0, Lp/Rf;->b:Ljava/lang/String;

    .line 13
    .line 14
    invoke-direct {p1, v0, v1}, Lp/Tf;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    return-object p1

    .line 18
    :pswitch_0
    new-instance p1, Lp/Tf;

    .line 19
    .line 20
    const-string v0, "UDP"

    .line 21
    .line 22
    iget-object v1, p0, Lp/Rf;->b:Ljava/lang/String;

    .line 23
    .line 24
    invoke-direct {p1, v0, v1}, Lp/Tf;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    return-object p1

    .line 28
    nop

    .line 29
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
