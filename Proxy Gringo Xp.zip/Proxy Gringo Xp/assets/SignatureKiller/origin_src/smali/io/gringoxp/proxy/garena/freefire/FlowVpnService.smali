.class public final Lio/gringoxp/proxy/garena/freefire/FlowVpnService;
.super Landroid/net/VpnService;
.source "SourceFile"


# static fields
.field public static volatile f:Z = false

.field public static volatile g:Ljava/lang/String; = "parada"


# instance fields
.field public volatile a:Z

.field public b:Landroid/os/ParcelFileDescriptor;

.field public c:I

.field public d:Lp/L9;

.field public e:Ljava/lang/Thread;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Landroid/net/VpnService;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, -0x1

    .line 5
    iput v0, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->c:I

    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)V
    .locals 4

    .line 1
    new-instance v0, Landroid/content/Intent;

    .line 2
    .line 3
    const-class v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;

    .line 4
    .line 5
    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 6
    .line 7
    .line 8
    const/high16 v1, 0xc000000

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    invoke-static {p0, v2, v0, v1}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 16
    .line 17
    const/16 v2, 0x1a

    .line 18
    .line 19
    if-lt v1, v2, :cond_0

    .line 20
    .line 21
    invoke-static {p0}, Lp/s;->d(Lio/gringoxp/proxy/garena/freefire/FlowVpnService;)Landroid/app/Notification$Builder;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    goto :goto_0

    .line 26
    :cond_0
    new-instance v2, Landroid/app/Notification$Builder;

    .line 27
    .line 28
    invoke-direct {v2, p0}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    .line 29
    .line 30
    .line 31
    :goto_0
    const v3, 0x7f070099

    .line 32
    .line 33
    .line 34
    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    const-string v3, "Flow VPN UDP"

    .line 39
    .line 40
    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    invoke-virtual {v2, p1}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    invoke-virtual {p1, v0}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    const/4 v0, 0x1

    .line 53
    invoke-virtual {p1, v0}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    const-string v0, "service"

    .line 58
    .line 59
    invoke-virtual {p1, v0}, Landroid/app/Notification$Builder;->setCategory(Ljava/lang/String;)Landroid/app/Notification$Builder;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    invoke-virtual {p1}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    .line 64
    .line 65
    .line 66
    move-result-object p1

    .line 67
    const/16 v0, 0x22

    .line 68
    .line 69
    if-lt v1, v0, :cond_1

    .line 70
    .line 71
    invoke-static {p0, p1}, Lp/t;->q(Lio/gringoxp/proxy/garena/freefire/FlowVpnService;Landroid/app/Notification;)V

    .line 72
    .line 73
    .line 74
    goto :goto_1

    .line 75
    :cond_1
    const/16 v0, 0xc80

    .line 76
    .line 77
    invoke-virtual {p0, v0, p1}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    .line 78
    .line 79
    .line 80
    :goto_1
    return-void
.end method

.method public final declared-synchronized b()V
    .locals 4

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-boolean v0, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->a:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 3
    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    monitor-exit p0

    .line 7
    return-void

    .line 8
    :cond_0
    const/4 v0, 0x1

    .line 9
    :try_start_1
    iput-boolean v0, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->a:Z

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    sput-boolean v1, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->f:Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 13
    .line 14
    :try_start_2
    invoke-static {}, Lhev/htproxy/TProxyService;->TProxyStopService()Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 15
    .line 16
    .line 17
    :catchall_0
    :try_start_3
    iget-object v1, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->d:Lp/L9;

    .line 18
    .line 19
    const/4 v2, 0x0

    .line 20
    if-eqz v1, :cond_1

    .line 21
    .line 22
    invoke-virtual {v1}, Lp/L9;->close()V

    .line 23
    .line 24
    .line 25
    iput-object v2, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->d:Lp/L9;

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :catchall_1
    move-exception v0

    .line 29
    goto :goto_1

    .line 30
    :cond_1
    :goto_0
    iget v1, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->c:I
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 31
    .line 32
    if-ltz v1, :cond_2

    .line 33
    .line 34
    :try_start_4
    invoke-static {v1}, Landroid/os/ParcelFileDescriptor;->adoptFd(I)Landroid/os/ParcelFileDescriptor;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    invoke-virtual {v1}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 39
    .line 40
    .line 41
    :catch_0
    const/4 v1, -0x1

    .line 42
    :try_start_5
    iput v1, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->c:I

    .line 43
    .line 44
    :cond_2
    iget-object v1, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->b:Landroid/os/ParcelFileDescriptor;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 45
    .line 46
    if-eqz v1, :cond_3

    .line 47
    .line 48
    :try_start_6
    invoke-virtual {v1}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    .line 49
    .line 50
    .line 51
    :catch_1
    :try_start_7
    iput-object v2, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->b:Landroid/os/ParcelFileDescriptor;

    .line 52
    .line 53
    :cond_3
    new-instance v1, Landroid/content/Intent;

    .line 54
    .line 55
    const-class v3, Lgringoxp/game/b;

    .line 56
    .line 57
    invoke-direct {v1, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {p0, v1}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 61
    .line 62
    .line 63
    new-instance v1, Landroid/content/Intent;

    .line 64
    .line 65
    const-class v3, Lgringoxp/game/EspDraw;

    .line 66
    .line 67
    invoke-direct {v1, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {p0, v1}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 71
    .line 72
    .line 73
    iput-object v2, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->e:Ljava/lang/Thread;

    .line 74
    .line 75
    const-string v1, "parada"

    .line 76
    .line 77
    sput-object v1, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->g:Ljava/lang/String;

    .line 78
    .line 79
    invoke-virtual {p0, v0}, Landroid/app/Service;->stopForeground(I)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .line 80
    .line 81
    .line 82
    monitor-exit p0

    .line 83
    return-void

    .line 84
    :goto_1
    :try_start_8
    monitor-exit p0
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    .line 85
    throw v0
.end method

.method public final onCreate()V
    .locals 2

    invoke-static/range {p0 .. p0}, Lcom/cuban/guard/CubanGuardApp;->a(Landroid/content/Context;)V

    .line 1
    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    .line 2
    .line 3
    .line 4
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 5
    .line 6
    const/16 v1, 0x1a

    .line 7
    .line 8
    if-lt v0, v1, :cond_0

    .line 9
    .line 10
    invoke-static {}, Lp/s;->q()Landroid/app/NotificationChannel;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {v0}, Lp/s;->r(Landroid/app/NotificationChannel;)V

    .line 15
    .line 16
    .line 17
    const-class v1, Landroid/app/NotificationManager;

    .line 18
    .line 19
    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    check-cast v1, Landroid/app/NotificationManager;

    .line 24
    .line 25
    invoke-static {v1, v0}, Lp/s;->i(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    .line 26
    .line 27
    .line 28
    :cond_0
    return-void
.end method

.method public final onDestroy()V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->b()V

    .line 2
    .line 3
    .line 4
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final onRevoke()V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->b()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    .line 5
    .line 6
    .line 7
    invoke-super {p0}, Landroid/net/VpnService;->onRevoke()V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .locals 6

    .line 1
    const-string p2, "Preparando VPN local..."

    .line 2
    .line 3
    invoke-virtual {p0, p2}, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->a(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/4 p2, 0x2

    .line 7
    if-eqz p1, :cond_0

    .line 8
    .line 9
    const-string p3, "io.gringoxp.proxy.garena.freefire.STOP_VPN"

    .line 10
    .line 11
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {p3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    move-result p3

    .line 19
    if-eqz p3, :cond_0

    .line 20
    .line 21
    invoke-virtual {p0}, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->b()V

    .line 22
    .line 23
    .line 24
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    .line 25
    .line 26
    .line 27
    return p2

    .line 28
    :cond_0
    sget-boolean p3, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->f:Z

    .line 29
    .line 30
    if-nez p3, :cond_7

    .line 31
    .line 32
    iget-object p3, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->e:Ljava/lang/Thread;

    .line 33
    .line 34
    if-eqz p3, :cond_1

    .line 35
    .line 36
    goto/16 :goto_6

    .line 37
    .line 38
    :cond_1
    const/4 p3, 0x0

    .line 39
    if-nez p1, :cond_2

    .line 40
    .line 41
    move-object p1, p3

    .line 42
    goto :goto_0

    .line 43
    :cond_2
    const-string v0, "target"

    .line 44
    .line 45
    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    :goto_0
    if-eqz p1, :cond_6

    .line 50
    .line 51
    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-eqz v0, :cond_3

    .line 60
    .line 61
    goto/16 :goto_5

    .line 62
    .line 63
    :cond_3
    const-string v0, "tunnel:\n  mtu: 1500\n  ipv4: 198.18.0.1\n  icmp: \'off\'\nsocks5:\n  address: 127.0.0.1\n  port: "

    .line 64
    .line 65
    const/4 v1, 0x0

    .line 66
    :try_start_0
    iput-boolean v1, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->a:Z

    .line 67
    .line 68
    sget-object v2, Lp/Uf;->a:Ljava/util/concurrent/ConcurrentHashMap;

    .line 69
    .line 70
    invoke-virtual {v2}, Ljava/util/concurrent/ConcurrentHashMap;->clear()V

    .line 71
    .line 72
    .line 73
    const-string v2, "AUTO"

    .line 74
    .line 75
    sput-object v2, Lp/Uf;->b:Ljava/lang/String;

    .line 76
    .line 77
    new-instance v2, Lp/L9;

    .line 78
    .line 79
    new-instance v3, Lp/F;

    .line 80
    .line 81
    const/16 v4, 0xe

    .line 82
    .line 83
    invoke-direct {v3, v4, p0}, Lp/F;-><init>(ILjava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    invoke-direct {v2, v3}, Lp/L9;-><init>(Lp/F;)V

    .line 87
    .line 88
    .line 89
    iput-object v2, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->d:Lp/L9;

    .line 90
    .line 91
    invoke-virtual {v2}, Lp/L9;->h()I

    .line 92
    .line 93
    .line 94
    move-result v2

    .line 95
    new-instance v3, Landroid/net/VpnService$Builder;

    .line 96
    .line 97
    invoke-direct {v3, p0}, Landroid/net/VpnService$Builder;-><init>(Landroid/net/VpnService;)V

    .line 98
    .line 99
    .line 100
    const-string v4, "Flow UDP VPN"

    .line 101
    .line 102
    invoke-virtual {v3, v4}, Landroid/net/VpnService$Builder;->setSession(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    .line 103
    .line 104
    .line 105
    move-result-object v3

    .line 106
    const/16 v4, 0x5dc

    .line 107
    .line 108
    invoke-virtual {v3, v4}, Landroid/net/VpnService$Builder;->setMtu(I)Landroid/net/VpnService$Builder;

    .line 109
    .line 110
    .line 111
    move-result-object v3

    .line 112
    const-string v4, "198.18.0.1"

    .line 113
    .line 114
    const/16 v5, 0x18

    .line 115
    .line 116
    invoke-virtual {v3, v4, v5}, Landroid/net/VpnService$Builder;->addAddress(Ljava/lang/String;I)Landroid/net/VpnService$Builder;

    .line 117
    .line 118
    .line 119
    move-result-object v3

    .line 120
    const-string v4, "0.0.0.0"

    .line 121
    .line 122
    invoke-virtual {v3, v4, v1}, Landroid/net/VpnService$Builder;->addRoute(Ljava/lang/String;I)Landroid/net/VpnService$Builder;

    .line 123
    .line 124
    .line 125
    move-result-object v3

    .line 126
    const-string v4, "1.1.1.1"

    .line 127
    .line 128
    invoke-virtual {v3, v4}, Landroid/net/VpnService$Builder;->addDnsServer(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    .line 129
    .line 130
    .line 131
    move-result-object v3

    .line 132
    invoke-virtual {v3, v1}, Landroid/net/VpnService$Builder;->setBlocking(Z)Landroid/net/VpnService$Builder;

    .line 133
    .line 134
    .line 135
    move-result-object v3

    .line 136
    invoke-virtual {v3, p1}, Landroid/net/VpnService$Builder;->addAllowedApplication(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    .line 137
    .line 138
    .line 139
    invoke-virtual {v3}, Landroid/net/VpnService$Builder;->establish()Landroid/os/ParcelFileDescriptor;

    .line 140
    .line 141
    .line 142
    move-result-object p1

    .line 143
    iput-object p1, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->b:Landroid/os/ParcelFileDescriptor;

    .line 144
    .line 145
    if-eqz p1, :cond_5

    .line 146
    .line 147
    new-instance p1, Ljava/io/File;

    .line 148
    .line 149
    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    .line 150
    .line 151
    .line 152
    move-result-object v3

    .line 153
    const-string v4, "flow-tunnel.yml"

    .line 154
    .line 155
    invoke-direct {p1, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    new-instance v3, Ljava/lang/StringBuilder;

    .line 159
    .line 160
    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 164
    .line 165
    .line 166
    const-string v0, "\n  udp: \'udp\'\nmisc:\n  log-file: null\n  log-level: warn\n"

    .line 167
    .line 168
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 169
    .line 170
    .line 171
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 172
    .line 173
    .line 174
    move-result-object v0

    .line 175
    new-instance v2, Ljava/io/FileOutputStream;

    .line 176
    .line 177
    invoke-direct {v2, p1, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;Z)V
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 178
    .line 179
    .line 180
    :try_start_1
    sget-object v1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 181
    .line 182
    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 183
    .line 184
    .line 185
    move-result-object v0

    .line 186
    invoke-virtual {v2, v0}, Ljava/io/FileOutputStream;->write([B)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 187
    .line 188
    .line 189
    :try_start_2
    invoke-virtual {v2}, Ljava/io/FileOutputStream;->close()V

    .line 190
    .line 191
    .line 192
    iget-object v0, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->b:Landroid/os/ParcelFileDescriptor;

    .line 193
    .line 194
    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->detachFd()I

    .line 195
    .line 196
    .line 197
    move-result v0

    .line 198
    iput v0, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->c:I

    .line 199
    .line 200
    iput-object p3, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->b:Landroid/os/ParcelFileDescriptor;

    .line 201
    .line 202
    const/4 p3, 0x1

    .line 203
    sput-boolean p3, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->f:Z

    .line 204
    .line 205
    const-string p3, "activa \u00b7 esperando UDP"

    .line 206
    .line 207
    sput-object p3, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->g:Ljava/lang/String;

    .line 208
    .line 209
    sget-object p3, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->g:Ljava/lang/String;

    .line 210
    .line 211
    invoke-virtual {p0, p3}, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->a(Ljava/lang/String;)V

    .line 212
    .line 213
    .line 214
    new-instance p3, Landroid/content/Intent;

    .line 215
    .line 216
    const-class v0, Lgringoxp/game/b;

    .line 217
    .line 218
    invoke-direct {p3, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 219
    .line 220
    .line 221
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 222
    .line 223
    const/16 v1, 0x1a

    .line 224
    .line 225
    if-lt v0, v1, :cond_4

    .line 226
    .line 227
    invoke-static {p0, p3}, Lp/s;->n(Lio/gringoxp/proxy/garena/freefire/FlowVpnService;Landroid/content/Intent;)V

    .line 228
    .line 229
    .line 230
    goto :goto_1

    .line 231
    :catchall_0
    move-exception p1

    .line 232
    goto :goto_3

    .line 233
    :cond_4
    invoke-virtual {p0, p3}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 234
    .line 235
    .line 236
    :goto_1
    iget p3, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->c:I

    .line 237
    .line 238
    new-instance v0, Ljava/lang/Thread;

    .line 239
    .line 240
    new-instance v1, Lp/r5;

    .line 241
    .line 242
    invoke-direct {v1, p0, p1, p3}, Lp/r5;-><init>(Lio/gringoxp/proxy/garena/freefire/FlowVpnService;Ljava/io/File;I)V

    .line 243
    .line 244
    .line 245
    const-string p1, "flow-tun2socks"

    .line 246
    .line 247
    invoke-direct {v0, v1, p1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 248
    .line 249
    .line 250
    iput-object v0, p0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->e:Ljava/lang/Thread;

    .line 251
    .line 252
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V
    :try_end_2
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 253
    .line 254
    .line 255
    goto :goto_4

    .line 256
    :catchall_1
    move-exception p1

    .line 257
    :try_start_3
    invoke-virtual {v2}, Ljava/io/FileOutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 258
    .line 259
    .line 260
    goto :goto_2

    .line 261
    :catchall_2
    move-exception p3

    .line 262
    :try_start_4
    invoke-virtual {p1, p3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 263
    .line 264
    .line 265
    :goto_2
    throw p1

    .line 266
    :cond_5
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 267
    .line 268
    const-string p3, "consentimento VPN ausente"

    .line 269
    .line 270
    invoke-direct {p1, p3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 271
    .line 272
    .line 273
    throw p1
    :try_end_4
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 274
    :goto_3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 275
    .line 276
    .line 277
    move-result-object p1

    .line 278
    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 279
    .line 280
    .line 281
    move-result-object p1

    .line 282
    const-string p3, "falha ao iniciar: "

    .line 283
    .line 284
    invoke-virtual {p3, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 285
    .line 286
    .line 287
    move-result-object p1

    .line 288
    sput-object p1, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->g:Ljava/lang/String;

    .line 289
    .line 290
    invoke-virtual {p0}, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->b()V

    .line 291
    .line 292
    .line 293
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    .line 294
    .line 295
    .line 296
    goto :goto_4

    .line 297
    :catch_0
    const-string p1, "jogo n\u00e3o instalado"

    .line 298
    .line 299
    sput-object p1, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->g:Ljava/lang/String;

    .line 300
    .line 301
    invoke-virtual {p0}, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->b()V

    .line 302
    .line 303
    .line 304
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    .line 305
    .line 306
    .line 307
    :goto_4
    return p2

    .line 308
    :cond_6
    :goto_5
    const-string p1, "alvo inv\u00e1lido"

    .line 309
    .line 310
    sput-object p1, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->g:Ljava/lang/String;

    .line 311
    .line 312
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    .line 313
    .line 314
    .line 315
    :cond_7
    :goto_6
    return p2
.end method

.method public final onTaskRemoved(Landroid/content/Intent;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->b()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    .line 5
    .line 6
    .line 7
    invoke-super {p0, p1}, Landroid/app/Service;->onTaskRemoved(Landroid/content/Intent;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method
