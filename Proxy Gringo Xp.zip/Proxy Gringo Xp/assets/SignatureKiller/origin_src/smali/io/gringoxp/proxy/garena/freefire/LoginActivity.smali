.class public final Lio/gringoxp/proxy/garena/freefire/LoginActivity;
.super Lp/I0;
.source "SourceFile"


# static fields
.field public static Q:Z

.field public static final R:[B


# instance fields
.field public A:Landroid/widget/TextView;

.field public B:Landroid/widget/TextView;

.field public C:Landroid/widget/TextView;

.field public D:Landroid/widget/TextView;

.field public E:Landroid/widget/Button;

.field public F:Landroid/widget/ImageButton;

.field public G:Landroid/widget/TextView;

.field public H:Landroid/widget/ImageView;

.field public I:Landroid/widget/TextView;

.field public J:Landroid/widget/TextView;

.field public K:Ljava/lang/String;

.field public L:Z

.field public M:Z

.field public N:Z

.field public O:Z

.field public final P:Lp/v2;

.field public final x:Landroid/os/Handler;

.field public y:Landroid/webkit/WebView;

.field public z:Landroid/widget/TextView;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const/16 v0, 0x20

    .line 2
    .line 3
    new-array v0, v0, [B

    .line 4
    .line 5
    fill-array-data v0, :array_0

    .line 6
    .line 7
    .line 8
    sput-object v0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->R:[B

    .line 9
    .line 10
    return-void

    .line 11
    :array_0
    .array-data 1
        -0x7et
        -0x55t
        0x5t
        0x4dt
        -0x55t
        -0x7dt
        -0x37t
        -0x54t
        0x1ct
        -0x11t
        -0x7bt
        0xct
        0x4ct
        -0x43t
        0x37t
        0x53t
        0x4dt
        0x7t
        -0x14t
        0x76t
        -0x64t
        0x32t
        0x6et
        0x61t
        -0x59t
        -0x76t
        -0x3t
        -0x42t
        -0x37t
        0x74t
        -0x55t
        0x3dt
    .end array-data
.end method

.method public constructor <init>()V
    .locals 3

    .line 1
    invoke-direct {p0}, Lp/I0;-><init>()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Landroidx/activity/a;->e:Lp/M7;

    .line 5
    .line 6
    iget-object v0, v0, Lp/M7;->c:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lp/P0;

    .line 9
    .line 10
    new-instance v1, Lp/G0;

    .line 11
    .line 12
    invoke-direct {v1, p0}, Lp/G0;-><init>(Lio/gringoxp/proxy/garena/freefire/LoginActivity;)V

    .line 13
    .line 14
    .line 15
    const-string v2, "androidx:appcompat"

    .line 16
    .line 17
    invoke-virtual {v0, v2, v1}, Lp/P0;->e(Ljava/lang/String;Lp/Vd;)V

    .line 18
    .line 19
    .line 20
    new-instance v0, Lp/H0;

    .line 21
    .line 22
    invoke-direct {v0, p0}, Lp/H0;-><init>(Lio/gringoxp/proxy/garena/freefire/LoginActivity;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {p0, v0}, Landroidx/activity/a;->h(Lp/Gb;)V

    .line 26
    .line 27
    .line 28
    new-instance v0, Landroid/os/Handler;

    .line 29
    .line 30
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 35
    .line 36
    .line 37
    iput-object v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->x:Landroid/os/Handler;

    .line 38
    .line 39
    new-instance v0, Lp/v2;

    .line 40
    .line 41
    const/16 v1, 0x8

    .line 42
    .line 43
    invoke-direct {v0, v1, p0}, Lp/v2;-><init>(ILjava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    iput-object v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->P:Lp/v2;

    .line 47
    .line 48
    return-void
.end method

.method private native isNativeInjectionAuthorized()Z
.end method

.method public static r(Lio/gringoxp/proxy/garena/freefire/LoginActivity;)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    sget-boolean v0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->f:Z

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {p0}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->z()V

    .line 9
    .line 10
    .line 11
    goto :goto_2

    .line 12
    :cond_0
    invoke-virtual {p0}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->v()V

    .line 13
    .line 14
    .line 15
    iget-boolean v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->L:Z

    .line 16
    .line 17
    if-eqz v0, :cond_4

    .line 18
    .line 19
    sget-boolean v0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->Q:Z

    .line 20
    .line 21
    if-eqz v0, :cond_4

    .line 22
    .line 23
    iget-boolean v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->M:Z

    .line 24
    .line 25
    if-eqz v0, :cond_4

    .line 26
    .line 27
    iget-boolean v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->N:Z

    .line 28
    .line 29
    if-eqz v0, :cond_4

    .line 30
    .line 31
    iget-boolean v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->O:Z

    .line 32
    .line 33
    if-nez v0, :cond_1

    .line 34
    .line 35
    goto :goto_1

    .line 36
    :cond_1
    const/4 v0, 0x0

    .line 37
    :try_start_0
    invoke-direct {p0}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->isNativeInjectionAuthorized()Z

    .line 38
    .line 39
    .line 40
    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 41
    goto :goto_0

    .line 42
    :catchall_0
    move v1, v0

    .line 43
    :goto_0
    if-nez v1, :cond_2

    .line 44
    .line 45
    const-string v1, "acesso nao autorizado."

    .line 46
    .line 47
    invoke-static {p0, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 48
    .line 49
    .line 50
    move-result-object p0

    .line 51
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    .line 52
    .line 53
    .line 54
    goto :goto_2

    .line 55
    :cond_2
    invoke-static {p0}, Landroid/net/VpnService;->prepare(Landroid/content/Context;)Landroid/content/Intent;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    if-eqz v0, :cond_3

    .line 60
    .line 61
    const/16 v1, 0x2329

    .line 62
    .line 63
    invoke-virtual {p0, v0, v1}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    .line 64
    .line 65
    .line 66
    goto :goto_2

    .line 67
    :cond_3
    invoke-virtual {p0}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->y()V

    .line 68
    .line 69
    .line 70
    goto :goto_2

    .line 71
    :cond_4
    :goto_1
    iget-object v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->D:Landroid/widget/TextView;

    .line 72
    .line 73
    const-string v1, "Falta licencia, juego instalado, m\u00f3dulo principal o permiso de superposici\u00f3n."

    .line 74
    .line 75
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 76
    .line 77
    .line 78
    iget-object p0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->D:Landroid/widget/TextView;

    .line 79
    .line 80
    const-string v0, "#F59E0B"

    .line 81
    .line 82
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 87
    .line 88
    .line 89
    :goto_2
    return-void
.end method


# virtual methods
.method public final A()V
    .locals 5

    .line 1
    iget-boolean v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->L:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    sget-boolean v0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->Q:Z

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget-boolean v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->M:Z

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    iget-boolean v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->N:Z

    .line 16
    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    iget-boolean v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->O:Z

    .line 20
    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    move v0, v2

    .line 24
    goto :goto_0

    .line 25
    :cond_0
    move v0, v1

    .line 26
    :goto_0
    iget-object v3, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->F:Landroid/widget/ImageButton;

    .line 27
    .line 28
    sget-boolean v4, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->f:Z

    .line 29
    .line 30
    if-nez v4, :cond_1

    .line 31
    .line 32
    if-eqz v0, :cond_2

    .line 33
    .line 34
    :cond_1
    move v1, v2

    .line 35
    :cond_2
    invoke-virtual {v3, v1}, Landroid/view/View;->setEnabled(Z)V

    .line 36
    .line 37
    .line 38
    iget-object v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->F:Landroid/widget/ImageButton;

    .line 39
    .line 40
    invoke-virtual {v0}, Landroid/view/View;->isEnabled()Z

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    if-eqz v1, :cond_3

    .line 45
    .line 46
    const/high16 v1, 0x3f800000    # 1.0f

    .line 47
    .line 48
    goto :goto_1

    .line 49
    :cond_3
    const v1, 0x3ee66666    # 0.45f

    .line 50
    .line 51
    .line 52
    :goto_1
    invoke-virtual {v0, v1}, Landroid/view/View;->setAlpha(F)V

    .line 53
    .line 54
    .line 55
    iget-object v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->F:Landroid/widget/ImageButton;

    .line 56
    .line 57
    sget-boolean v1, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->f:Z

    .line 58
    .line 59
    if-eqz v1, :cond_4

    .line 60
    .line 61
    const v1, 0x7f0700a3

    .line 62
    .line 63
    .line 64
    goto :goto_2

    .line 65
    :cond_4
    const v1, 0x7f0700a4

    .line 66
    .line 67
    .line 68
    :goto_2
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 69
    .line 70
    .line 71
    iget-object v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->G:Landroid/widget/TextView;

    .line 72
    .line 73
    if-eqz v0, :cond_6

    .line 74
    .line 75
    sget-boolean v1, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->f:Z

    .line 76
    .line 77
    if-eqz v1, :cond_5

    .line 78
    .line 79
    const-string v1, "PAUSAR VPN Y FLOTANTE"

    .line 80
    .line 81
    goto :goto_3

    .line 82
    :cond_5
    const-string v1, "INICIAR VPN Y FLOTANTE"

    .line 83
    .line 84
    :goto_3
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 85
    .line 86
    .line 87
    :cond_6
    return-void
.end method

.method public final onActivityResult(IILandroid/content/Intent;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3}, Lp/I0;->onActivityResult(IILandroid/content/Intent;)V

    .line 2
    .line 3
    .line 4
    const/16 p3, 0x2329

    .line 5
    .line 6
    if-ne p1, p3, :cond_1

    .line 7
    .line 8
    const/4 p1, -0x1

    .line 9
    if-ne p2, p1, :cond_0

    .line 10
    .line 11
    invoke-virtual {p0}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->y()V

    .line 12
    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    const-string p1, "Permiss\u00e3o VPN recusada."

    .line 16
    .line 17
    const-string p2, "#EF4444"

    .line 18
    .line 19
    invoke-virtual {p0, p1, p2}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->x(Ljava/lang/String;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    :cond_1
    :goto_0
    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 16

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    invoke-super/range {p0 .. p1}, Lp/I0;->onCreate(Landroid/os/Bundle;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "flow_vpn_ui"

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 10
    .line 11
    .line 12
    move-result-object v3

    .line 13
    invoke-virtual {v1, v0, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    const-string v4, "target_package"

    .line 18
    .line 19
    const-string v5, "com.dts.freefireth"

    .line 20
    .line 21
    invoke-interface {v0, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    iput-object v0, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->K:Ljava/lang/String;

    .line 26
    .line 27
    new-instance v0, Landroid/widget/LinearLayout;

    .line 28
    .line 29
    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 30
    .line 31
    .line 32
    const/4 v4, 0x1

    .line 33
    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 34
    .line 35
    .line 36
    const/16 v5, 0xe

    .line 37
    .line 38
    invoke-virtual {v1, v5}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 39
    .line 40
    .line 41
    move-result v6

    .line 42
    const/16 v7, 0xa

    .line 43
    .line 44
    invoke-virtual {v1, v7}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 45
    .line 46
    .line 47
    move-result v8

    .line 48
    invoke-virtual {v1, v5}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 49
    .line 50
    .line 51
    move-result v5

    .line 52
    invoke-virtual {v1, v7}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 53
    .line 54
    .line 55
    move-result v9

    .line 56
    invoke-virtual {v0, v6, v8, v5, v9}, Landroid/view/View;->setPadding(IIII)V

    .line 57
    .line 58
    .line 59
    const-string v5, "#080D14"

    .line 60
    .line 61
    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 62
    .line 63
    .line 64
    move-result v5

    .line 65
    invoke-virtual {v0, v5}, Landroid/view/View;->setBackgroundColor(I)V

    .line 66
    .line 67
    .line 68
    invoke-virtual/range {p0 .. p0}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->u()Landroid/widget/LinearLayout;

    .line 69
    .line 70
    .line 71
    move-result-object v5

    .line 72
    const-string v6, "CUBAN MODS \u00b7 GRINGO XP"

    .line 73
    .line 74
    const/16 v8, 0x12

    .line 75
    .line 76
    const/4 v9, -0x1

    .line 77
    invoke-virtual {v1, v6, v8, v9, v4}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->t(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    .line 78
    .line 79
    .line 80
    move-result-object v6

    .line 81
    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 82
    .line 83
    .line 84
    const-string v6, "#F59E0B"

    .line 85
    .line 86
    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 87
    .line 88
    .line 89
    move-result v6

    .line 90
    const-string v8, "Fa\u00e7a login para liberar"

    .line 91
    .line 92
    const/16 v10, 0xc

    .line 93
    .line 94
    invoke-virtual {v1, v8, v10, v6, v2}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->t(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    .line 95
    .line 96
    .line 97
    move-result-object v6

    .line 98
    iput-object v6, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->z:Landroid/widget/TextView;

    .line 99
    .line 100
    const-string v6, "Superposici\u00f3n: verificando..."

    .line 101
    .line 102
    const/16 v8, 0xb

    .line 103
    .line 104
    const v10, -0x333334

    .line 105
    .line 106
    .line 107
    invoke-virtual {v1, v6, v8, v10, v2}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->t(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    .line 108
    .line 109
    .line 110
    move-result-object v6

    .line 111
    iput-object v6, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->A:Landroid/widget/TextView;

    .line 112
    .line 113
    const-string v6, "VPN: detenida"

    .line 114
    .line 115
    invoke-virtual {v1, v6, v8, v10, v2}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->t(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    .line 116
    .line 117
    .line 118
    move-result-object v6

    .line 119
    iput-object v6, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->B:Landroid/widget/TextView;

    .line 120
    .line 121
    const-string v6, "Free Fire: verificando..."

    .line 122
    .line 123
    invoke-virtual {v1, v6, v8, v10, v2}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->t(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    .line 124
    .line 125
    .line 126
    move-result-object v6

    .line 127
    iput-object v6, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->C:Landroid/widget/TextView;

    .line 128
    .line 129
    iget-object v6, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->z:Landroid/widget/TextView;

    .line 130
    .line 131
    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 132
    .line 133
    .line 134
    iget-object v6, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->A:Landroid/widget/TextView;

    .line 135
    .line 136
    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 137
    .line 138
    .line 139
    iget-object v6, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->B:Landroid/widget/TextView;

    .line 140
    .line 141
    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 142
    .line 143
    .line 144
    iget-object v6, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->C:Landroid/widget/TextView;

    .line 145
    .line 146
    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 147
    .line 148
    .line 149
    new-instance v6, Landroid/widget/Button;

    .line 150
    .line 151
    invoke-direct {v6, v1}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 152
    .line 153
    .line 154
    const-string v10, "LIBERAR SOBREPOSI\u00c7\u00c3O"

    .line 155
    .line 156
    invoke-virtual {v6, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 157
    .line 158
    .line 159
    invoke-virtual {v6, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 160
    .line 161
    .line 162
    const/high16 v10, 0x41300000    # 11.0f

    .line 163
    .line 164
    const/4 v11, 0x2

    .line 165
    invoke-virtual {v6, v11, v10}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 166
    .line 167
    .line 168
    sget-object v10, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    .line 169
    .line 170
    invoke-virtual {v6, v10, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 171
    .line 172
    .line 173
    const-string v10, "#334155"

    .line 174
    .line 175
    invoke-virtual {v1, v10, v10}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->w(Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/GradientDrawable;

    .line 176
    .line 177
    .line 178
    move-result-object v10

    .line 179
    invoke-virtual {v6, v10}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 180
    .line 181
    .line 182
    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    .line 183
    .line 184
    const/16 v12, 0x2c

    .line 185
    .line 186
    invoke-virtual {v1, v12}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 187
    .line 188
    .line 189
    move-result v12

    .line 190
    invoke-direct {v10, v9, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 191
    .line 192
    .line 193
    const/4 v12, 0x7

    .line 194
    invoke-virtual {v1, v12}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 195
    .line 196
    .line 197
    move-result v13

    .line 198
    iput v13, v10, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 199
    .line 200
    invoke-virtual {v6, v10}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 201
    .line 202
    .line 203
    iput-object v6, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->E:Landroid/widget/Button;

    .line 204
    .line 205
    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 206
    .line 207
    .line 208
    new-instance v6, Landroid/widget/LinearLayout;

    .line 209
    .line 210
    invoke-direct {v6, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 211
    .line 212
    .line 213
    invoke-virtual {v6, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 214
    .line 215
    .line 216
    const/16 v10, 0x10

    .line 217
    .line 218
    invoke-virtual {v6, v10}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 219
    .line 220
    .line 221
    invoke-virtual {v1, v7}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 222
    .line 223
    .line 224
    move-result v10

    .line 225
    const/16 v13, 0x8

    .line 226
    .line 227
    invoke-virtual {v1, v13}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 228
    .line 229
    .line 230
    move-result v14

    .line 231
    invoke-virtual {v1, v7}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 232
    .line 233
    .line 234
    move-result v15

    .line 235
    invoke-virtual {v1, v13}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 236
    .line 237
    .line 238
    move-result v12

    .line 239
    invoke-virtual {v6, v10, v14, v15, v12}, Landroid/view/View;->setPadding(IIII)V

    .line 240
    .line 241
    .line 242
    const-string v10, "#0D1722"

    .line 243
    .line 244
    const-string v12, "#2B4058"

    .line 245
    .line 246
    invoke-virtual {v1, v10, v12}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->w(Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/GradientDrawable;

    .line 247
    .line 248
    .line 249
    move-result-object v10

    .line 250
    invoke-virtual {v6, v10}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 251
    .line 252
    .line 253
    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    .line 254
    .line 255
    const/4 v12, -0x2

    .line 256
    invoke-direct {v10, v9, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 257
    .line 258
    .line 259
    invoke-virtual {v1, v13}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 260
    .line 261
    .line 262
    move-result v14

    .line 263
    iput v14, v10, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 264
    .line 265
    invoke-virtual {v6, v10}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 266
    .line 267
    .line 268
    new-instance v10, Landroid/widget/ImageView;

    .line 269
    .line 270
    invoke-direct {v10, v1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 271
    .line 272
    .line 273
    iput-object v10, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->H:Landroid/widget/ImageView;

    .line 274
    .line 275
    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    .line 276
    .line 277
    const/16 v15, 0x2e

    .line 278
    .line 279
    invoke-virtual {v1, v15}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 280
    .line 281
    .line 282
    move-result v11

    .line 283
    invoke-virtual {v1, v15}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 284
    .line 285
    .line 286
    move-result v15

    .line 287
    invoke-direct {v14, v11, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 288
    .line 289
    .line 290
    invoke-virtual {v6, v10, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 291
    .line 292
    .line 293
    new-instance v10, Landroid/widget/LinearLayout;

    .line 294
    .line 295
    invoke-direct {v10, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 296
    .line 297
    .line 298
    invoke-virtual {v10, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 299
    .line 300
    .line 301
    invoke-virtual {v1, v7}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 302
    .line 303
    .line 304
    move-result v11

    .line 305
    const/4 v14, 0x6

    .line 306
    invoke-virtual {v1, v14}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 307
    .line 308
    .line 309
    move-result v14

    .line 310
    invoke-virtual {v10, v11, v2, v14, v2}, Landroid/view/View;->setPadding(IIII)V

    .line 311
    .line 312
    .line 313
    const-string v11, "Selecionar aplicativo"

    .line 314
    .line 315
    const/16 v14, 0xd

    .line 316
    .line 317
    invoke-virtual {v1, v11, v14, v9, v4}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->t(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    .line 318
    .line 319
    .line 320
    move-result-object v11

    .line 321
    iput-object v11, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->I:Landroid/widget/TextView;

    .line 322
    .line 323
    iget-object v11, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->K:Ljava/lang/String;

    .line 324
    .line 325
    const-string v14, "#94A3B8"

    .line 326
    .line 327
    invoke-static {v14}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 328
    .line 329
    .line 330
    move-result v15

    .line 331
    invoke-virtual {v1, v11, v7, v15, v2}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->t(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    .line 332
    .line 333
    .line 334
    move-result-object v11

    .line 335
    iput-object v11, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->J:Landroid/widget/TextView;

    .line 336
    .line 337
    iget-object v11, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->I:Landroid/widget/TextView;

    .line 338
    .line 339
    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 340
    .line 341
    .line 342
    iget-object v11, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->J:Landroid/widget/TextView;

    .line 343
    .line 344
    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 345
    .line 346
    .line 347
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    .line 348
    .line 349
    const/high16 v15, 0x3f800000    # 1.0f

    .line 350
    .line 351
    invoke-direct {v11, v2, v12, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 352
    .line 353
    .line 354
    invoke-virtual {v6, v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 355
    .line 356
    .line 357
    const-string v10, "#10B981"

    .line 358
    .line 359
    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 360
    .line 361
    .line 362
    move-result v10

    .line 363
    const-string v11, "\u203a"

    .line 364
    .line 365
    const/16 v7, 0x1a

    .line 366
    .line 367
    invoke-virtual {v1, v11, v7, v10, v4}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->t(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    .line 368
    .line 369
    .line 370
    move-result-object v7

    .line 371
    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 372
    .line 373
    .line 374
    new-instance v7, Lp/R9;

    .line 375
    .line 376
    const/4 v10, 0x2

    .line 377
    invoke-direct {v7, v1, v10}, Lp/R9;-><init>(Lio/gringoxp/proxy/garena/freefire/LoginActivity;I)V

    .line 378
    .line 379
    .line 380
    invoke-virtual {v6, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 381
    .line 382
    .line 383
    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 384
    .line 385
    .line 386
    invoke-virtual {v0, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 387
    .line 388
    .line 389
    invoke-virtual/range {p0 .. p0}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->u()Landroid/widget/LinearLayout;

    .line 390
    .line 391
    .line 392
    move-result-object v5

    .line 393
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    .line 394
    .line 395
    invoke-direct {v6, v9, v2, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 396
    .line 397
    .line 398
    invoke-virtual {v1, v13}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 399
    .line 400
    .line 401
    move-result v7

    .line 402
    iput v7, v6, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 403
    .line 404
    invoke-virtual {v5, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 405
    .line 406
    .line 407
    new-instance v6, Landroid/webkit/WebView;

    .line 408
    .line 409
    invoke-direct {v6, v1}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    .line 410
    .line 411
    .line 412
    iput-object v6, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->y:Landroid/webkit/WebView;

    .line 413
    .line 414
    const-string v7, "#0D141F"

    .line 415
    .line 416
    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 417
    .line 418
    .line 419
    move-result v7

    .line 420
    invoke-virtual {v6, v7}, Landroid/webkit/WebView;->setBackgroundColor(I)V

    .line 421
    .line 422
    .line 423
    iget-object v6, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->y:Landroid/webkit/WebView;

    .line 424
    .line 425
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    .line 426
    .line 427
    invoke-direct {v7, v9, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 428
    .line 429
    .line 430
    invoke-virtual {v5, v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 431
    .line 432
    .line 433
    invoke-virtual {v0, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 434
    .line 435
    .line 436
    invoke-virtual/range {p0 .. p0}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->u()Landroid/widget/LinearLayout;

    .line 437
    .line 438
    .line 439
    move-result-object v5

    .line 440
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    .line 441
    .line 442
    invoke-direct {v6, v9, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 443
    .line 444
    .line 445
    invoke-virtual {v1, v13}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 446
    .line 447
    .line 448
    move-result v7

    .line 449
    iput v7, v6, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 450
    .line 451
    invoke-virtual {v5, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 452
    .line 453
    .line 454
    const-string v6, "Al iniciar, la VPN captura el UDP y abre el panel flotante."

    .line 455
    .line 456
    invoke-static {v14}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 457
    .line 458
    .line 459
    move-result v7

    .line 460
    invoke-virtual {v1, v6, v8, v7, v2}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->t(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    .line 461
    .line 462
    .line 463
    move-result-object v6

    .line 464
    iput-object v6, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->D:Landroid/widget/TextView;

    .line 465
    .line 466
    const-string v7, "#070B11"

    .line 467
    .line 468
    const-string v10, "#1E293B"

    .line 469
    .line 470
    invoke-virtual {v1, v7, v10}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->w(Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/GradientDrawable;

    .line 471
    .line 472
    .line 473
    move-result-object v7

    .line 474
    invoke-virtual {v6, v7}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 475
    .line 476
    .line 477
    iget-object v6, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->D:Landroid/widget/TextView;

    .line 478
    .line 479
    const/16 v7, 0xa

    .line 480
    .line 481
    invoke-virtual {v1, v7}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 482
    .line 483
    .line 484
    move-result v10

    .line 485
    invoke-virtual {v1, v13}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 486
    .line 487
    .line 488
    move-result v11

    .line 489
    invoke-virtual {v1, v7}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 490
    .line 491
    .line 492
    move-result v7

    .line 493
    invoke-virtual {v1, v13}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 494
    .line 495
    .line 496
    move-result v12

    .line 497
    invoke-virtual {v6, v10, v11, v7, v12}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 498
    .line 499
    .line 500
    iget-object v6, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->D:Landroid/widget/TextView;

    .line 501
    .line 502
    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 503
    .line 504
    .line 505
    const-string v6, "INICIAR VPN Y FLOTANTE"

    .line 506
    .line 507
    invoke-virtual {v1, v6, v8, v9, v4}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->t(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    .line 508
    .line 509
    .line 510
    move-result-object v6

    .line 511
    iput-object v6, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->G:Landroid/widget/TextView;

    .line 512
    .line 513
    const/16 v7, 0x11

    .line 514
    .line 515
    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setGravity(I)V

    .line 516
    .line 517
    .line 518
    new-instance v6, Landroid/widget/ImageButton;

    .line 519
    .line 520
    invoke-direct {v6, v1}, Landroid/widget/ImageButton;-><init>(Landroid/content/Context;)V

    .line 521
    .line 522
    .line 523
    const v7, 0x7f0700a4

    .line 524
    .line 525
    .line 526
    invoke-virtual {v6, v7}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 527
    .line 528
    .line 529
    sget-object v7, Landroid/widget/ImageView$ScaleType;->CENTER:Landroid/widget/ImageView$ScaleType;

    .line 530
    .line 531
    invoke-virtual {v6, v7}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 532
    .line 533
    .line 534
    const/16 v7, 0x13

    .line 535
    .line 536
    invoke-virtual {v1, v7}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 537
    .line 538
    .line 539
    move-result v8

    .line 540
    invoke-virtual {v1, v7}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 541
    .line 542
    .line 543
    move-result v10

    .line 544
    invoke-virtual {v1, v7}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 545
    .line 546
    .line 547
    move-result v11

    .line 548
    invoke-virtual {v1, v7}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 549
    .line 550
    .line 551
    move-result v7

    .line 552
    invoke-virtual {v6, v8, v10, v11, v7}, Landroid/view/View;->setPadding(IIII)V

    .line 553
    .line 554
    .line 555
    const-string v7, "Iniciar ou pausar VPN"

    .line 556
    .line 557
    invoke-virtual {v6, v7}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 558
    .line 559
    .line 560
    new-instance v7, Landroid/graphics/drawable/GradientDrawable;

    .line 561
    .line 562
    invoke-direct {v7}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 563
    .line 564
    .line 565
    invoke-virtual {v7, v4}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 566
    .line 567
    .line 568
    const-string v8, "#059669"

    .line 569
    .line 570
    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 571
    .line 572
    .line 573
    move-result v8

    .line 574
    invoke-virtual {v7, v8}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 575
    .line 576
    .line 577
    const/4 v8, 0x2

    .line 578
    invoke-virtual {v1, v8}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 579
    .line 580
    .line 581
    move-result v8

    .line 582
    const-string v10, "#34D399"

    .line 583
    .line 584
    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 585
    .line 586
    .line 587
    move-result v10

    .line 588
    invoke-virtual {v7, v8, v10}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 589
    .line 590
    .line 591
    invoke-virtual {v6, v7}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 592
    .line 593
    .line 594
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    .line 595
    .line 596
    const/16 v8, 0x46

    .line 597
    .line 598
    invoke-virtual {v1, v8}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 599
    .line 600
    .line 601
    move-result v10

    .line 602
    invoke-virtual {v1, v8}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 603
    .line 604
    .line 605
    move-result v8

    .line 606
    invoke-direct {v7, v10, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 607
    .line 608
    .line 609
    iput v4, v7, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 610
    .line 611
    const/4 v8, 0x7

    .line 612
    invoke-virtual {v1, v8}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 613
    .line 614
    .line 615
    move-result v8

    .line 616
    iput v8, v7, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 617
    .line 618
    const/4 v8, 0x3

    .line 619
    invoke-virtual {v1, v8}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 620
    .line 621
    .line 622
    move-result v8

    .line 623
    iput v8, v7, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 624
    .line 625
    invoke-virtual {v6, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 626
    .line 627
    .line 628
    iput-object v6, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->F:Landroid/widget/ImageButton;

    .line 629
    .line 630
    iget-object v6, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->G:Landroid/widget/TextView;

    .line 631
    .line 632
    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 633
    .line 634
    .line 635
    iget-object v6, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->F:Landroid/widget/ImageButton;

    .line 636
    .line 637
    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 638
    .line 639
    .line 640
    invoke-virtual {v0, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 641
    .line 642
    .line 643
    invoke-virtual {v1, v0}, Lp/I0;->setContentView(Landroid/view/View;)V

    .line 644
    .line 645
    .line 646
    :try_start_0
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 647
    .line 648
    .line 649
    move-result-object v0

    .line 650
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 651
    .line 652
    .line 653
    move-result-object v5

    .line 654
    const/16 v6, 0x40

    .line 655
    .line 656
    invoke-virtual {v0, v5, v6}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 657
    .line 658
    .line 659
    move-result-object v0

    .line 660
    iget-object v0, v0, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    .line 661
    .line 662
    if-eqz v0, :cond_1

    .line 663
    .line 664
    array-length v5, v0

    .line 665
    if-eq v5, v4, :cond_0

    .line 666
    .line 667
    goto :goto_0

    .line 668
    :cond_0
    const-string v5, "SHA-256"

    .line 669
    .line 670
    invoke-static {v5}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    .line 671
    .line 672
    .line 673
    move-result-object v5

    .line 674
    aget-object v0, v0, v2

    .line 675
    .line 676
    invoke-virtual {v0}, Landroid/content/pm/Signature;->toByteArray()[B

    .line 677
    .line 678
    .line 679
    move-result-object v0

    .line 680
    invoke-virtual {v5, v0}, Ljava/security/MessageDigest;->digest([B)[B

    .line 681
    .line 682
    .line 683
    move-result-object v0

    .line 684
    sget-object v5, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->R:[B

    .line 685
    .line 686
    invoke-static {v0, v5}, Ljava/security/MessageDigest;->isEqual([B[B)Z

    .line 687
    .line 688
    .line 689
    const/4 v0, 0x1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 690
    goto :goto_1

    .line 691
    :catch_0
    :cond_1
    :goto_0
    move v0, v2

    .line 692
    :goto_1
    iput-boolean v0, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->L:Z

    .line 693
    .line 694
    sget-boolean v5, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->Q:Z

    .line 695
    .line 696
    if-eqz v5, :cond_2

    .line 697
    .line 698
    goto :goto_4

    .line 699
    :cond_2
    if-nez v0, :cond_3

    .line 700
    .line 701
    const-string v0, "Integridade do aplicativo inv\u00e1lida."

    .line 702
    .line 703
    const-string v5, "#EF4444"

    .line 704
    .line 705
    invoke-virtual {v1, v0, v5}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->x(Ljava/lang/String;Ljava/lang/String;)V

    .line 706
    .line 707
    .line 708
    goto :goto_4

    .line 709
    :cond_3
    :try_start_1
    invoke-static {}, Lakn/main/UpdateActivity;->loadedMainAbi()Ljava/lang/String;

    .line 710
    .line 711
    .line 712
    move-result-object v0

    .line 713
    const-string v5, "arm64-v8a"

    .line 714
    .line 715
    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 716
    .line 717
    .line 718
    move-result v5

    .line 719
    if-nez v5, :cond_5

    .line 720
    .line 721
    const-string v5, "armeabi-v7a"

    .line 722
    .line 723
    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 724
    .line 725
    .line 726
    move-result v5

    .line 727
    if-nez v5, :cond_5

    .line 728
    .line 729
    const-string v5, "x86"

    .line 730
    .line 731
    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 732
    .line 733
    .line 734
    move-result v0

    .line 735
    if-eqz v0, :cond_4

    .line 736
    .line 737
    goto :goto_2

    .line 738
    :cond_4
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 739
    .line 740
    const-string v5, "Unsupported loaded native ABI"

    .line 741
    .line 742
    invoke-direct {v0, v5}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 743
    .line 744
    .line 745
    throw v0

    .line 746
    :cond_5
    :goto_2
    invoke-static {}, Lakn/main/UpdateActivity;->loadedMainAbi()Ljava/lang/String;

    .line 747
    .line 748
    .line 749
    move-result-object v0

    .line 750
    new-instance v5, Lp/S9;

    .line 751
    .line 752
    invoke-direct {v5, v1, v0}, Lp/S9;-><init>(Lio/gringoxp/proxy/garena/freefire/LoginActivity;Ljava/lang/String;)V

    .line 753
    .line 754
    .line 755
    const-class v6, Lp/Z9;

    .line 756
    .line 757
    monitor-enter v6
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 758
    :try_start_2
    sget-boolean v0, Lp/Z9;->a:Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 759
    .line 760
    if-eqz v0, :cond_6

    .line 761
    .line 762
    :try_start_3
    monitor-exit v6
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 763
    goto :goto_3

    .line 764
    :cond_6
    :try_start_4
    invoke-virtual {v5}, Lp/S9;->a()V

    .line 765
    .line 766
    .line 767
    sput-boolean v4, Lp/Z9;->a:Z
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 768
    .line 769
    :try_start_5
    monitor-exit v6

    .line 770
    :goto_3
    sput-boolean v4, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->Q:Z

    .line 771
    .line 772
    invoke-direct/range {p0 .. p0}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->isNativeInjectionAuthorized()Z
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 773
    .line 774
    .line 775
    goto :goto_4

    .line 776
    :catchall_0
    move-exception v0

    .line 777
    :try_start_6
    monitor-exit v6
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 778
    :try_start_7
    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .line 779
    :catchall_1
    invoke-static {}, Landroid/os/Process;->is64Bit()Z

    .line 780
    .line 781
    .line 782
    const-string v0, "Falha ao carregar o m\u00f3dulo principal. Reinicie para atualizar."

    .line 783
    .line 784
    const-string v5, "#EF4444"

    .line 785
    .line 786
    invoke-virtual {v1, v0, v5}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->x(Ljava/lang/String;Ljava/lang/String;)V

    .line 787
    .line 788
    .line 789
    :goto_4
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 790
    .line 791
    const/16 v5, 0x21

    .line 792
    .line 793
    if-lt v0, v5, :cond_e

    .line 794
    .line 795
    const-string v6, "android.permission.POST_NOTIFICATIONS"

    .line 796
    .line 797
    const-string v7, "android.permission.POST_NOTIFICATIONS"

    .line 798
    .line 799
    if-ge v0, v5, :cond_7

    .line 800
    .line 801
    invoke-static {v7, v7}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 802
    .line 803
    .line 804
    move-result v8

    .line 805
    if-eqz v8, :cond_7

    .line 806
    .line 807
    new-instance v7, Lp/wb;

    .line 808
    .line 809
    invoke-direct {v7, v1}, Lp/wb;-><init>(Lio/gringoxp/proxy/garena/freefire/LoginActivity;)V

    .line 810
    .line 811
    .line 812
    iget-object v7, v7, Lp/wb;->a:Landroid/app/NotificationManager;

    .line 813
    .line 814
    invoke-static {v7}, Lp/vb;->a(Landroid/app/NotificationManager;)Z

    .line 815
    .line 816
    .line 817
    move-result v7

    .line 818
    if-eqz v7, :cond_8

    .line 819
    .line 820
    move v9, v2

    .line 821
    goto :goto_5

    .line 822
    :cond_7
    invoke-static {}, Landroid/os/Process;->myPid()I

    .line 823
    .line 824
    .line 825
    move-result v8

    .line 826
    invoke-static {}, Landroid/os/Process;->myUid()I

    .line 827
    .line 828
    .line 829
    move-result v9

    .line 830
    invoke-virtual {v1, v7, v8, v9}, Landroid/content/Context;->checkPermission(Ljava/lang/String;II)I

    .line 831
    .line 832
    .line 833
    move-result v9

    .line 834
    :cond_8
    :goto_5
    if-eqz v9, :cond_e

    .line 835
    .line 836
    new-array v7, v4, [Ljava/lang/String;

    .line 837
    .line 838
    aput-object v6, v7, v2

    .line 839
    .line 840
    new-instance v8, Ljava/util/HashSet;

    .line 841
    .line 842
    invoke-direct {v8}, Ljava/util/HashSet;-><init>()V

    .line 843
    .line 844
    .line 845
    aget-object v9, v7, v2

    .line 846
    .line 847
    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 848
    .line 849
    .line 850
    move-result v9

    .line 851
    if-nez v9, :cond_d

    .line 852
    .line 853
    if-ge v0, v5, :cond_9

    .line 854
    .line 855
    aget-object v0, v7, v2

    .line 856
    .line 857
    invoke-static {v0, v6}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 858
    .line 859
    .line 860
    move-result v0

    .line 861
    if-eqz v0, :cond_9

    .line 862
    .line 863
    invoke-virtual {v8, v3}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 864
    .line 865
    .line 866
    :cond_9
    invoke-virtual {v8}, Ljava/util/HashSet;->size()I

    .line 867
    .line 868
    .line 869
    move-result v0

    .line 870
    if-lez v0, :cond_a

    .line 871
    .line 872
    rsub-int/lit8 v5, v0, 0x1

    .line 873
    .line 874
    new-array v5, v5, [Ljava/lang/String;

    .line 875
    .line 876
    goto :goto_6

    .line 877
    :cond_a
    move-object v5, v7

    .line 878
    :goto_6
    if-lez v0, :cond_c

    .line 879
    .line 880
    if-ne v0, v4, :cond_b

    .line 881
    .line 882
    goto :goto_7

    .line 883
    :cond_b
    invoke-virtual {v8, v3}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 884
    .line 885
    .line 886
    move-result v0

    .line 887
    if-nez v0, :cond_c

    .line 888
    .line 889
    aget-object v0, v7, v2

    .line 890
    .line 891
    aput-object v0, v5, v2

    .line 892
    .line 893
    :cond_c
    const/16 v0, 0x65

    .line 894
    .line 895
    invoke-static {v1, v7, v0}, Lp/j0;->b(Landroid/app/Activity;[Ljava/lang/String;I)V

    .line 896
    .line 897
    .line 898
    goto :goto_7

    .line 899
    :cond_d
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 900
    .line 901
    new-instance v2, Ljava/lang/StringBuilder;

    .line 902
    .line 903
    const-string v3, "Permission request for permissions "

    .line 904
    .line 905
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 906
    .line 907
    .line 908
    invoke-static {v7}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    .line 909
    .line 910
    .line 911
    move-result-object v3

    .line 912
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 913
    .line 914
    .line 915
    const-string v3, " must not contain null or empty values"

    .line 916
    .line 917
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 918
    .line 919
    .line 920
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 921
    .line 922
    .line 923
    move-result-object v2

    .line 924
    invoke-direct {v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 925
    .line 926
    .line 927
    throw v0

    .line 928
    :cond_e
    :goto_7
    iget-object v0, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->y:Landroid/webkit/WebView;

    .line 929
    .line 930
    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    .line 931
    .line 932
    .line 933
    move-result-object v0

    .line 934
    invoke-virtual {v0, v4}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    .line 935
    .line 936
    .line 937
    invoke-virtual {v0, v4}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    .line 938
    .line 939
    .line 940
    invoke-virtual {v0, v2}, Landroid/webkit/WebSettings;->setSupportZoom(Z)V

    .line 941
    .line 942
    .line 943
    new-instance v2, Ljava/lang/StringBuilder;

    .line 944
    .line 945
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 946
    .line 947
    .line 948
    invoke-virtual {v0}, Landroid/webkit/WebSettings;->getUserAgentString()Ljava/lang/String;

    .line 949
    .line 950
    .line 951
    move-result-object v3

    .line 952
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 953
    .line 954
    .line 955
    const-string v3, " GringoXP_Secure_App"

    .line 956
    .line 957
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 958
    .line 959
    .line 960
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 961
    .line 962
    .line 963
    move-result-object v2

    .line 964
    invoke-virtual {v0, v2}, Landroid/webkit/WebSettings;->setUserAgentString(Ljava/lang/String;)V

    .line 965
    .line 966
    .line 967
    iget-object v0, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->y:Landroid/webkit/WebView;

    .line 968
    .line 969
    new-instance v2, Lp/U9;

    .line 970
    .line 971
    invoke-direct {v2, v1}, Lp/U9;-><init>(Lio/gringoxp/proxy/garena/freefire/LoginActivity;)V

    .line 972
    .line 973
    .line 974
    invoke-virtual {v0, v2}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    .line 975
    .line 976
    .line 977
    new-instance v0, Ljava/util/HashMap;

    .line 978
    .line 979
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 980
    .line 981
    .line 982
    const-string v2, "Referer"

    .line 983
    .line 984
    const-string v3, "file:///android_asset/cuban_home.html"

    .line 985
    .line 986
    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 987
    .line 988
    .line 989
    iget-object v2, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->y:Landroid/webkit/WebView;

    .line 990
    .line 991
    const-string v3, "file:///android_asset/cuban_home.html"

    .line 992
    .line 993
    invoke-virtual {v2, v3, v0}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;Ljava/util/Map;)V

    .line 994
    .line 995
    .line 996
    iget-object v0, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->E:Landroid/widget/Button;

    .line 997
    .line 998
    new-instance v2, Lp/R9;

    .line 999
    .line 1000
    const/4 v3, 0x0

    .line 1001
    invoke-direct {v2, v1, v3}, Lp/R9;-><init>(Lio/gringoxp/proxy/garena/freefire/LoginActivity;I)V

    .line 1002
    .line 1003
    .line 1004
    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1005
    .line 1006
    .line 1007
    iget-object v0, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->F:Landroid/widget/ImageButton;

    .line 1008
    .line 1009
    new-instance v2, Lp/R9;

    .line 1010
    .line 1011
    const/4 v3, 0x1

    .line 1012
    invoke-direct {v2, v1, v3}, Lp/R9;-><init>(Lio/gringoxp/proxy/garena/freefire/LoginActivity;I)V

    .line 1013
    .line 1014
    .line 1015
    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1016
    .line 1017
    .line 1018
    invoke-virtual/range {p0 .. p0}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->v()V

    .line 1019
    .line 1020
    .line 1021
    iget-object v0, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->x:Landroid/os/Handler;

    .line 1022
    .line 1023
    iget-object v2, v1, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->P:Lp/v2;

    .line 1024
    .line 1025
    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 1026
    .line 1027
    .line 1028
    return-void
.end method

.method public final onDestroy()V
    .locals 2

    .line 1
    iget-object v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->x:Landroid/os/Handler;

    .line 2
    .line 3
    iget-object v1, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->P:Lp/v2;

    .line 4
    .line 5
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 6
    .line 7
    .line 8
    sget-boolean v0, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;->f:Z

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    invoke-virtual {p0}, Landroid/app/Activity;->isChangingConfigurations()Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-nez v0, :cond_0

    .line 23
    .line 24
    invoke-virtual {p0}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->z()V

    .line 25
    .line 26
    .line 27
    :cond_0
    iget-object v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->y:Landroid/webkit/WebView;

    .line 28
    .line 29
    if-eqz v0, :cond_1

    .line 30
    .line 31
    invoke-virtual {v0}, Landroid/webkit/WebView;->destroy()V

    .line 32
    .line 33
    .line 34
    :cond_1
    invoke-super {p0}, Lp/I0;->onDestroy()V

    .line 35
    .line 36
    .line 37
    return-void
.end method

.method public final onResume()V
    .locals 1

    .line 1
    invoke-super {p0}, Lp/I0;->onResume()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->A:Landroid/widget/TextView;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {p0}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->v()V

    .line 9
    .line 10
    .line 11
    :cond_0
    return-void
.end method

.method public final s(I)I
    .locals 1

    .line 1
    int-to-float p1, p1

    .line 2
    invoke-virtual {p0}, Lp/I0;->getResources()Landroid/content/res/Resources;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    .line 11
    .line 12
    mul-float/2addr p1, v0

    .line 13
    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    return p1
.end method

.method public final t(Ljava/lang/String;IIZ)Landroid/widget/TextView;
    .locals 1

    .line 1
    new-instance v0, Landroid/widget/TextView;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 7
    .line 8
    .line 9
    const/4 p1, 0x2

    .line 10
    int-to-float p2, p2

    .line 11
    invoke-virtual {v0, p1, p2}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0, p3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 15
    .line 16
    .line 17
    if-eqz p4, :cond_0

    .line 18
    .line 19
    sget-object p1, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    .line 20
    .line 21
    const/4 p2, 0x1

    .line 22
    invoke-virtual {v0, p1, p2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 23
    .line 24
    .line 25
    :cond_0
    return-object v0
.end method

.method public final u()Landroid/widget/LinearLayout;
    .locals 5

    .line 1
    new-instance v0, Landroid/widget/LinearLayout;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 8
    .line 9
    .line 10
    const/16 v1, 0xc

    .line 11
    .line 12
    invoke-virtual {p0, v1}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    const/16 v3, 0xa

    .line 17
    .line 18
    invoke-virtual {p0, v3}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 19
    .line 20
    .line 21
    move-result v4

    .line 22
    invoke-virtual {p0, v1}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    invoke-virtual {p0, v3}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 27
    .line 28
    .line 29
    move-result v3

    .line 30
    invoke-virtual {v0, v2, v4, v1, v3}, Landroid/view/View;->setPadding(IIII)V

    .line 31
    .line 32
    .line 33
    const-string v1, "#101925"

    .line 34
    .line 35
    const-string v2, "#26364A"

    .line 36
    .line 37
    invoke-virtual {p0, v1, v2}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->w(Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/GradientDrawable;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    invoke-virtual {v0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 42
    .line 43
    .line 44
    return-object v0
.end method

.method public final v()V
    .locals 5

    .line 1
    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iput-boolean v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->N:Z

    .line 6
    .line 7
    const/4 v0, 0x0

    .line 8
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    iget-object v2, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->K:Ljava/lang/String;

    .line 13
    .line 14
    invoke-virtual {v1, v2, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    const/4 v3, 0x1

    .line 19
    iput-boolean v3, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->O:Z

    .line 20
    .line 21
    iget-object v3, v2, Landroid/content/pm/PackageInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    .line 22
    .line 23
    if-nez v3, :cond_0

    .line 24
    .line 25
    iget-object v3, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->K:Ljava/lang/String;

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_0
    invoke-virtual {v1, v3}, Landroid/content/pm/PackageManager;->getApplicationLabel(Landroid/content/pm/ApplicationInfo;)Ljava/lang/CharSequence;

    .line 29
    .line 30
    .line 31
    move-result-object v3

    .line 32
    :goto_0
    iget-object v4, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->I:Landroid/widget/TextView;

    .line 33
    .line 34
    if-eqz v4, :cond_2

    .line 35
    .line 36
    if-nez v3, :cond_1

    .line 37
    .line 38
    iget-object v3, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->K:Ljava/lang/String;

    .line 39
    .line 40
    :cond_1
    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 41
    .line 42
    .line 43
    :cond_2
    iget-object v3, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->J:Landroid/widget/TextView;

    .line 44
    .line 45
    if-eqz v3, :cond_3

    .line 46
    .line 47
    iget-object v4, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->K:Ljava/lang/String;

    .line 48
    .line 49
    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 50
    .line 51
    .line 52
    :cond_3
    iget-object v3, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->H:Landroid/widget/ImageView;

    .line 53
    .line 54
    if-eqz v3, :cond_6

    .line 55
    .line 56
    iget-object v2, v2, Landroid/content/pm/PackageInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    .line 57
    .line 58
    if-eqz v2, :cond_6

    .line 59
    .line 60
    invoke-virtual {v1, v2}, Landroid/content/pm/PackageManager;->getApplicationIcon(Landroid/content/pm/ApplicationInfo;)Landroid/graphics/drawable/Drawable;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    invoke-virtual {v3, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 65
    .line 66
    .line 67
    goto :goto_1

    .line 68
    :catch_0
    iput-boolean v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->O:Z

    .line 69
    .line 70
    iget-object v1, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->I:Landroid/widget/TextView;

    .line 71
    .line 72
    if-eqz v1, :cond_4

    .line 73
    .line 74
    const-string v2, "Aplicaci\u00f3n no encontrada"

    .line 75
    .line 76
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 77
    .line 78
    .line 79
    :cond_4
    iget-object v1, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->J:Landroid/widget/TextView;

    .line 80
    .line 81
    if-eqz v1, :cond_5

    .line 82
    .line 83
    iget-object v2, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->K:Ljava/lang/String;

    .line 84
    .line 85
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 86
    .line 87
    .line 88
    :cond_5
    iget-object v1, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->H:Landroid/widget/ImageView;

    .line 89
    .line 90
    if-eqz v1, :cond_6

    .line 91
    .line 92
    const/4 v2, 0x0

    .line 93
    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 94
    .line 95
    .line 96
    :cond_6
    :goto_1
    iget-object v1, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->A:Landroid/widget/TextView;

    .line 97
    .line 98
    iget-boolean v2, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->N:Z

    .line 99
    .line 100
    if-eqz v2, :cond_7

    .line 101
    .line 102
    const-string v2, "Superposici\u00f3n: liberada"

    .line 103
    .line 104
    goto :goto_2

    .line 105
    :cond_7
    const-string v2, "Superposici\u00f3n: permiso necesario"

    .line 106
    .line 107
    :goto_2
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 108
    .line 109
    .line 110
    iget-object v1, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->A:Landroid/widget/TextView;

    .line 111
    .line 112
    iget-boolean v2, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->N:Z

    .line 113
    .line 114
    const-string v3, "#10B981"

    .line 115
    .line 116
    if-eqz v2, :cond_8

    .line 117
    .line 118
    move-object v2, v3

    .line 119
    goto :goto_3

    .line 120
    :cond_8
    const-string v2, "#F59E0B"

    .line 121
    .line 122
    :goto_3
    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 123
    .line 124
    .line 125
    move-result v2

    .line 126
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 127
    .line 128
    .line 129
    iget-object v1, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->E:Landroid/widget/Button;

    .line 130
    .line 131
    iget-boolean v2, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->N:Z

    .line 132
    .line 133
    if-eqz v2, :cond_9

    .line 134
    .line 135
    const/16 v0, 0x8

    .line 136
    .line 137
    :cond_9
    invoke-virtual {v1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 138
    .line 139
    .line 140
    iget-object v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->C:Landroid/widget/TextView;

    .line 141
    .line 142
    iget-boolean v1, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->O:Z

    .line 143
    .line 144
    if-eqz v1, :cond_a

    .line 145
    .line 146
    const-string v1, "Objetivo VPN: listo"

    .line 147
    .line 148
    goto :goto_4

    .line 149
    :cond_a
    const-string v1, "Objetivo VPN: no encontrado"

    .line 150
    .line 151
    :goto_4
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 152
    .line 153
    .line 154
    iget-object v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->C:Landroid/widget/TextView;

    .line 155
    .line 156
    iget-boolean v1, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->O:Z

    .line 157
    .line 158
    if-eqz v1, :cond_b

    .line 159
    .line 160
    goto :goto_5

    .line 161
    :cond_b
    const-string v3, "#EF4444"

    .line 162
    .line 163
    :goto_5
    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 164
    .line 165
    .line 166
    move-result v1

    .line 167
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {p0}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->A()V

    .line 171
    .line 172
    .line 173
    return-void
.end method

.method public final w(Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/GradientDrawable;
    .locals 1

    .line 1
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    .line 2
    .line 3
    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 11
    .line 12
    .line 13
    const/16 p1, 0x9

    .line 14
    .line 15
    invoke-virtual {p0, p1}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 16
    .line 17
    .line 18
    move-result p1

    .line 19
    int-to-float p1, p1

    .line 20
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 21
    .line 22
    .line 23
    const/4 p1, 0x1

    .line 24
    invoke-virtual {p0, p1}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->s(I)I

    .line 25
    .line 26
    .line 27
    move-result p1

    .line 28
    invoke-static {p2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 29
    .line 30
    .line 31
    move-result p2

    .line 32
    invoke-virtual {v0, p1, p2}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 33
    .line 34
    .line 35
    return-object v0
.end method

.method public final x(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->D:Landroid/widget/TextView;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 7
    .line 8
    .line 9
    iget-object p1, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->D:Landroid/widget/TextView;

    .line 10
    .line 11
    invoke-static {p2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 12
    .line 13
    .line 14
    move-result p2

    .line 15
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public final y()V
    .locals 4

    .line 1
    new-instance v0, Landroid/content/Intent;

    .line 2
    .line 3
    const-class v1, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;

    .line 4
    .line 5
    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 6
    .line 7
    .line 8
    const-string v1, "io.gringoxp.proxy.garena.freefire.START_VPN"

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    const-string v1, "target"

    .line 15
    .line 16
    iget-object v2, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->K:Ljava/lang/String;

    .line 17
    .line 18
    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 23
    .line 24
    const/16 v2, 0x1a

    .line 25
    .line 26
    if-lt v1, v2, :cond_0

    .line 27
    .line 28
    invoke-static {p0, v0}, Lp/s;->o(Lio/gringoxp/proxy/garena/freefire/LoginActivity;Landroid/content/Intent;)V

    .line 29
    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_0
    invoke-virtual {p0, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 33
    .line 34
    .line 35
    :goto_0
    const-string v0, "Iniciando VPN, captura UDP e flutuante..."

    .line 36
    .line 37
    const-string v1, "#F59E0B"

    .line 38
    .line 39
    invoke-virtual {p0, v0, v1}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->x(Ljava/lang/String;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    iget-object v0, p0, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->x:Landroid/os/Handler;

    .line 43
    .line 44
    new-instance v1, Lp/i0;

    .line 45
    .line 46
    const/16 v2, 0x9

    .line 47
    .line 48
    invoke-direct {v1, v2, p0}, Lp/i0;-><init>(ILjava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    const-wide/16 v2, 0x2bc

    .line 52
    .line 53
    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 54
    .line 55
    .line 56
    return-void
.end method

.method public final z()V
    .locals 3

    .line 1
    new-instance v0, Landroid/content/Intent;

    .line 2
    .line 3
    const-class v1, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;

    .line 4
    .line 5
    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 6
    .line 7
    .line 8
    const-string v1, "io.gringoxp.proxy.garena.freefire.STOP_VPN"

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 15
    .line 16
    const/16 v2, 0x1a

    .line 17
    .line 18
    if-lt v1, v2, :cond_0

    .line 19
    .line 20
    invoke-static {p0, v0}, Lp/s;->o(Lio/gringoxp/proxy/garena/freefire/LoginActivity;Landroid/content/Intent;)V

    .line 21
    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    invoke-virtual {p0, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 25
    .line 26
    .line 27
    :goto_0
    const-string v0, "Encerrando VPN e flutuante..."

    .line 28
    .line 29
    const-string v1, "#F59E0B"

    .line 30
    .line 31
    invoke-virtual {p0, v0, v1}, Lio/gringoxp/proxy/garena/freefire/LoginActivity;->x(Ljava/lang/String;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method
