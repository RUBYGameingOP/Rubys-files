.class public final Lhev/htproxy/TProxyService;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "hev-socks5-tunnel"

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public static native TProxyGetStats()[J
.end method

.method public static native TProxyIsRunning()Z
.end method

.method public static native TProxyStartService(Ljava/lang/String;I)Z
.end method

.method public static native TProxyStopService()Z
.end method
