.class public Lgringoxp/game/b;
.super Landroid/app/Service;
.source "SourceFile"


# static fields
.field public static d:Lgringoxp/game/b;

.field public static e:Landroid/view/WindowManager;

.field public static f:Landroid/widget/FrameLayout;

.field public static g:Landroid/widget/LinearLayout;

.field public static final h:I


# instance fields
.field public a:Landroid/widget/LinearLayout;

.field public b:Landroid/widget/LinearLayout;

.field public c:Lp/Ub;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    const/16 v0, 0xff

    .line 2
    .line 3
    const/16 v1, 0x14

    .line 4
    .line 5
    invoke-static {v0, v1, v1}, Landroid/graphics/Color;->rgb(III)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    sput v0, Lgringoxp/game/b;->h:I

    .line 10
    .line 11
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method private native Funcoes()[Ljava/lang/String;
.end method

.method private native GetRemoteAuthMenuText()Ljava/lang/String;
.end method

.method private native GetUdpPacketControlsMenuText()Ljava/lang/String;
.end method

.method private native GetUdpQuickControlSnapshot()J
.end method

.method private native GetUdpTelemetryMenuText()Ljava/lang/String;
.end method

.method public static native PxbftKZXivSr(Lgringoxp/game/ESPView;Landroid/graphics/Canvas;II)V
.end method

.method public static a(Lgringoxp/game/b;)V
    .locals 14

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    :try_start_0
    invoke-direct {p0}, Lgringoxp/game/b;->Funcoes()[Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    goto/16 :goto_4

    .line 11
    .line 12
    :cond_0
    array-length v1, v0

    .line 13
    const/4 v2, 0x0

    .line 14
    move v3, v2

    .line 15
    :goto_0
    if-ge v3, v1, :cond_4

    .line 16
    .line 17
    aget-object v4, v0, v3

    .line 18
    .line 19
    if-nez v4, :cond_1

    .line 20
    .line 21
    goto/16 :goto_3

    .line 22
    .line 23
    :cond_1
    const-string v5, "_"

    .line 24
    .line 25
    invoke-virtual {v4, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v4

    .line 29
    array-length v5, v4

    .line 30
    const/4 v6, 0x3

    .line 31
    if-ge v5, v6, :cond_2

    .line 32
    .line 33
    goto/16 :goto_3

    .line 34
    .line 35
    :cond_2
    aget-object v5, v4, v2

    .line 36
    .line 37
    invoke-virtual {v5}, Ljava/lang/String;->hashCode()I

    .line 38
    .line 39
    .line 40
    move-result v7

    .line 41
    const/4 v8, 0x1

    .line 42
    const/4 v9, 0x5

    .line 43
    const/4 v10, 0x4

    .line 44
    const/4 v11, 0x2

    .line 45
    sparse-switch v7, :sswitch_data_0

    .line 46
    .line 47
    .line 48
    goto/16 :goto_1

    .line 49
    .line 50
    :sswitch_0
    const-string v7, "[CheckBox]"

    .line 51
    .line 52
    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    move-result v5

    .line 56
    if-eqz v5, :cond_3

    .line 57
    .line 58
    move v5, v10

    .line 59
    goto/16 :goto_2

    .line 60
    .line 61
    :sswitch_1
    const-string v7, "[Description]"

    .line 62
    .line 63
    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result v5

    .line 67
    if-eqz v5, :cond_3

    .line 68
    .line 69
    move v5, v11

    .line 70
    goto/16 :goto_2

    .line 71
    .line 72
    :sswitch_2
    const-string v7, "[Button]"

    .line 73
    .line 74
    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v5

    .line 78
    if-eqz v5, :cond_3

    .line 79
    .line 80
    const/16 v5, 0xb

    .line 81
    .line 82
    goto/16 :goto_2

    .line 83
    .line 84
    :sswitch_3
    const-string v7, "[Color]"

    .line 85
    .line 86
    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    move-result v5

    .line 90
    if-eqz v5, :cond_3

    .line 91
    .line 92
    const/4 v5, 0x6

    .line 93
    goto :goto_2

    .line 94
    :sswitch_4
    const-string v7, "[LoginInfo]"

    .line 95
    .line 96
    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    move-result v5

    .line 100
    if-eqz v5, :cond_3

    .line 101
    .line 102
    const/4 v5, 0x7

    .line 103
    goto :goto_2

    .line 104
    :sswitch_5
    const-string v7, "[SeekBar]"

    .line 105
    .line 106
    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 107
    .line 108
    .line 109
    move-result v5

    .line 110
    if-eqz v5, :cond_3

    .line 111
    .line 112
    move v5, v9

    .line 113
    goto :goto_2

    .line 114
    :sswitch_6
    const-string v7, "[FlowSelector]"

    .line 115
    .line 116
    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 117
    .line 118
    .line 119
    move-result v5

    .line 120
    if-eqz v5, :cond_3

    .line 121
    .line 122
    const/16 v5, 0xa

    .line 123
    .line 124
    goto :goto_2

    .line 125
    :sswitch_7
    const-string v7, "[Switch]"

    .line 126
    .line 127
    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 128
    .line 129
    .line 130
    move-result v5

    .line 131
    if-eqz v5, :cond_3

    .line 132
    .line 133
    move v5, v8

    .line 134
    goto :goto_2

    .line 135
    :sswitch_8
    const-string v7, "[PacketControlInfo]"

    .line 136
    .line 137
    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 138
    .line 139
    .line 140
    move-result v5

    .line 141
    if-eqz v5, :cond_3

    .line 142
    .line 143
    const/16 v5, 0x9

    .line 144
    .line 145
    goto :goto_2

    .line 146
    :sswitch_9
    const-string v7, "[Category]"

    .line 147
    .line 148
    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 149
    .line 150
    .line 151
    move-result v5

    .line 152
    if-eqz v5, :cond_3

    .line 153
    .line 154
    move v5, v2

    .line 155
    goto :goto_2

    .line 156
    :sswitch_a
    const-string v7, "[QuickControl]"

    .line 157
    .line 158
    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 159
    .line 160
    .line 161
    move-result v5

    .line 162
    if-eqz v5, :cond_3

    .line 163
    .line 164
    move v5, v6

    .line 165
    goto :goto_2

    .line 166
    :sswitch_b
    const-string v7, "[UdpInfo]"

    .line 167
    .line 168
    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 169
    .line 170
    .line 171
    move-result v5

    .line 172
    if-eqz v5, :cond_3

    .line 173
    .line 174
    const/16 v5, 0x8

    .line 175
    .line 176
    goto :goto_2

    .line 177
    :cond_3
    :goto_1
    const/4 v5, -0x1

    .line 178
    :goto_2
    packed-switch v5, :pswitch_data_0

    .line 179
    .line 180
    .line 181
    goto/16 :goto_3

    .line 182
    .line 183
    :pswitch_0
    aget-object v5, v4, v8

    .line 184
    .line 185
    aget-object v7, v4, v11

    .line 186
    .line 187
    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 188
    .line 189
    .line 190
    move-result v7

    .line 191
    aget-object v4, v4, v6

    .line 192
    .line 193
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 194
    .line 195
    .line 196
    move-result v4

    .line 197
    invoke-virtual {p0, v5, v7, v4}, Lgringoxp/game/b;->i(Ljava/lang/String;II)V

    .line 198
    .line 199
    .line 200
    goto/16 :goto_3

    .line 201
    .line 202
    :pswitch_1
    aget-object v5, v4, v8

    .line 203
    .line 204
    aget-object v4, v4, v11

    .line 205
    .line 206
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 207
    .line 208
    .line 209
    move-result v4

    .line 210
    invoke-virtual {p0, v5, v4}, Lgringoxp/game/b;->m(Ljava/lang/String;I)V

    .line 211
    .line 212
    .line 213
    goto/16 :goto_3

    .line 214
    .line 215
    :pswitch_2
    aget-object v5, v4, v8

    .line 216
    .line 217
    aget-object v4, v4, v11

    .line 218
    .line 219
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 220
    .line 221
    .line 222
    move-result v4

    .line 223
    invoke-virtual {p0, v5, v4, v8}, Lgringoxp/game/b;->p(Ljava/lang/String;IZ)V

    .line 224
    .line 225
    .line 226
    goto/16 :goto_3

    .line 227
    .line 228
    :pswitch_3
    aget-object v5, v4, v8

    .line 229
    .line 230
    aget-object v4, v4, v11

    .line 231
    .line 232
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 233
    .line 234
    .line 235
    move-result v4

    .line 236
    invoke-virtual {p0, v5, v4, v2}, Lgringoxp/game/b;->p(Ljava/lang/String;IZ)V

    .line 237
    .line 238
    .line 239
    goto/16 :goto_3

    .line 240
    .line 241
    :pswitch_4
    aget-object v5, v4, v8

    .line 242
    .line 243
    aget-object v4, v4, v11

    .line 244
    .line 245
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 246
    .line 247
    .line 248
    move-result v4

    .line 249
    invoke-virtual {p0, v5, v4}, Lgringoxp/game/b;->n(Ljava/lang/String;I)V

    .line 250
    .line 251
    .line 252
    goto/16 :goto_3

    .line 253
    .line 254
    :pswitch_5
    aget-object v5, v4, v8

    .line 255
    .line 256
    aget-object v7, v4, v11

    .line 257
    .line 258
    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 259
    .line 260
    .line 261
    move-result v7

    .line 262
    aget-object v6, v4, v6

    .line 263
    .line 264
    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 265
    .line 266
    .line 267
    move-result v6

    .line 268
    aget-object v4, v4, v10

    .line 269
    .line 270
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 271
    .line 272
    .line 273
    move-result v4

    .line 274
    invoke-virtual {p0, v5, v7, v6, v4}, Lgringoxp/game/b;->j(Ljava/lang/String;III)V

    .line 275
    .line 276
    .line 277
    goto/16 :goto_3

    .line 278
    .line 279
    :pswitch_6
    aget-object v5, v4, v8

    .line 280
    .line 281
    aget-object v7, v4, v11

    .line 282
    .line 283
    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 284
    .line 285
    .line 286
    move-result v7

    .line 287
    aget-object v6, v4, v6

    .line 288
    .line 289
    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 290
    .line 291
    .line 292
    move-result v11

    .line 293
    aget-object v6, v4, v10

    .line 294
    .line 295
    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 296
    .line 297
    .line 298
    move-result v12

    .line 299
    aget-object v4, v4, v9

    .line 300
    .line 301
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 302
    .line 303
    .line 304
    move-result v13

    .line 305
    move-object v8, p0

    .line 306
    move-object v9, v5

    .line 307
    move v10, v7

    .line 308
    invoke-virtual/range {v8 .. v13}, Lgringoxp/game/b;->h(Ljava/lang/String;IIII)V

    .line 309
    .line 310
    .line 311
    goto :goto_3

    .line 312
    :pswitch_7
    aget-object v5, v4, v8

    .line 313
    .line 314
    aget-object v7, v4, v11

    .line 315
    .line 316
    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 317
    .line 318
    .line 319
    move-result v7

    .line 320
    aget-object v6, v4, v6

    .line 321
    .line 322
    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 323
    .line 324
    .line 325
    move-result v6

    .line 326
    aget-object v4, v4, v10

    .line 327
    .line 328
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 329
    .line 330
    .line 331
    move-result v4

    .line 332
    invoke-virtual {p0, v5, v7, v6, v4}, Lgringoxp/game/b;->k(Ljava/lang/String;III)V

    .line 333
    .line 334
    .line 335
    goto :goto_3

    .line 336
    :pswitch_8
    aget-object v5, v4, v8

    .line 337
    .line 338
    aget-object v7, v4, v11

    .line 339
    .line 340
    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 341
    .line 342
    .line 343
    move-result v7

    .line 344
    aget-object v4, v4, v6

    .line 345
    .line 346
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 347
    .line 348
    .line 349
    move-result v4

    .line 350
    invoke-virtual {p0, v5, v7, v4}, Lgringoxp/game/b;->o(Ljava/lang/String;II)V

    .line 351
    .line 352
    .line 353
    goto :goto_3

    .line 354
    :pswitch_9
    aget-object v5, v4, v8

    .line 355
    .line 356
    aget-object v4, v4, v11

    .line 357
    .line 358
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 359
    .line 360
    .line 361
    move-result v4

    .line 362
    invoke-virtual {p0, v5, v4}, Lgringoxp/game/b;->l(Ljava/lang/String;I)V

    .line 363
    .line 364
    .line 365
    goto :goto_3

    .line 366
    :pswitch_a
    aget-object v5, v4, v8

    .line 367
    .line 368
    aget-object v7, v4, v11

    .line 369
    .line 370
    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 371
    .line 372
    .line 373
    move-result v7

    .line 374
    aget-object v6, v4, v6

    .line 375
    .line 376
    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 377
    .line 378
    .line 379
    move-result v6

    .line 380
    aget-object v4, v4, v10

    .line 381
    .line 382
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 383
    .line 384
    .line 385
    move-result v4

    .line 386
    invoke-virtual {p0, v5, v7, v6, v4}, Lgringoxp/game/b;->g(Ljava/lang/String;III)V

    .line 387
    .line 388
    .line 389
    goto :goto_3

    .line 390
    :pswitch_b
    aget-object v5, v4, v8

    .line 391
    .line 392
    aget-object v4, v4, v11

    .line 393
    .line 394
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 395
    .line 396
    .line 397
    move-result v4

    .line 398
    invoke-virtual {p0, v5, v4}, Lgringoxp/game/b;->f(Ljava/lang/String;I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 399
    .line 400
    .line 401
    :goto_3
    add-int/lit8 v3, v3, 0x1

    .line 402
    .line 403
    goto/16 :goto_0

    .line 404
    .line 405
    :catch_0
    :cond_4
    :goto_4
    return-void

    .line 406
    nop

    .line 407
    :sswitch_data_0
    .sparse-switch
        -0x60a27857 -> :sswitch_b
        -0x55a590ee -> :sswitch_a
        -0x551dc6fc -> :sswitch_9
        -0x44a7c18b -> :sswitch_8
        -0x1b414532 -> :sswitch_7
        -0x10ec09cb -> :sswitch_6
        -0xc78d943 -> :sswitch_5
        -0x5460dbf -> :sswitch_4
        0x467ab995 -> :sswitch_3
        0x5ea64a90 -> :sswitch_2
        0x5fd99fdc -> :sswitch_1
        0x654726ff -> :sswitch_0
    .end sparse-switch

    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static synthetic b(Lgringoxp/game/b;)J
    .locals 2

    .line 1
    invoke-direct {p0}, Lgringoxp/game/b;->GetUdpQuickControlSnapshot()J

    .line 2
    .line 3
    .line 4
    move-result-wide v0

    .line 5
    return-wide v0
.end method

.method public static synthetic c(Lgringoxp/game/b;)Ljava/lang/String;
    .locals 0

    const-string p0, "Acesso autorizado - Cuban Mods"

    return-object p0
.end method

.method public static synthetic d(Lgringoxp/game/b;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-direct {p0}, Lgringoxp/game/b;->GetUdpPacketControlsMenuText()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public static native drainHeldVpnUdp(ZI)[[B
.end method

.method public static synthetic e(Lgringoxp/game/b;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-direct {p0}, Lgringoxp/game/b;->GetUdpTelemetryMenuText()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public static r(ZILjava/net/InetSocketAddress;[BII)[B
    .locals 6

    .line 1
    invoke-static {p2}, Lp/Uf;->a(Ljava/net/InetSocketAddress;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    new-instance v1, Ljava/lang/StringBuilder;

    .line 6
    .line 7
    const-string v2, "UDP://"

    .line 8
    .line 9
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 13
    .line 14
    .line 15
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    sget-object v2, Lp/Uf;->a:Ljava/util/concurrent/ConcurrentHashMap;

    .line 20
    .line 21
    new-instance v3, Lp/Rf;

    .line 22
    .line 23
    const/4 v4, 0x0

    .line 24
    invoke-direct {v3, v0, v4}, Lp/Rf;-><init>(Ljava/lang/String;I)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v2, v1, v3}, Ljava/util/concurrent/ConcurrentHashMap;->computeIfAbsent(Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    check-cast v0, Lp/Tf;

    .line 32
    .line 33
    invoke-virtual {v0, p5, p0}, Lp/Tf;->a(IZ)V

    .line 34
    .line 35
    .line 36
    sget-object v0, Lp/Uf;->b:Ljava/lang/String;

    .line 37
    .line 38
    const-string v3, "AUTO"

    .line 39
    .line 40
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v4

    .line 44
    if-nez v4, :cond_3

    .line 45
    .line 46
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    if-eqz v1, :cond_0

    .line 51
    .line 52
    goto :goto_1

    .line 53
    :cond_0
    invoke-virtual {v2, v0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    check-cast v0, Lp/Tf;

    .line 58
    .line 59
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 60
    .line 61
    .line 62
    move-result-wide v1

    .line 63
    if-eqz v0, :cond_2

    .line 64
    .line 65
    iget-wide v4, v0, Lp/Tf;->h:J

    .line 66
    .line 67
    sub-long/2addr v1, v4

    .line 68
    const-wide/16 v4, 0x1388

    .line 69
    .line 70
    cmp-long v0, v1, v4

    .line 71
    .line 72
    if-lez v0, :cond_1

    .line 73
    .line 74
    goto :goto_0

    .line 75
    :cond_1
    const/4 p0, 0x0

    .line 76
    return-object p0

    .line 77
    :cond_2
    :goto_0
    sput-object v3, Lp/Uf;->b:Ljava/lang/String;

    .line 78
    .line 79
    :cond_3
    :goto_1
    invoke-virtual {p2}, Ljava/net/InetSocketAddress;->getPort()I

    .line 80
    .line 81
    .line 82
    move-result v2

    .line 83
    move v0, p0

    .line 84
    move v1, p1

    .line 85
    move-object v3, p3

    .line 86
    move v4, p4

    .line 87
    move v5, p5

    .line 88
    invoke-static/range {v0 .. v5}, Lgringoxp/game/b;->receiveVpnUdp(ZII[BII)[B

    .line 89
    .line 90
    .line 91
    move-result-object p0

    .line 92
    return-object p0
.end method

.method public static native receiveVpnTcp(ZI[BII)V
.end method

.method public static native receiveVpnUdp(ZII[BII)[B
.end method

.method public static native releaseVpnUdpAssociation(I)V
.end method

.method public static s(I)I
    .locals 2

    .line 1
    int-to-float p0, p0

    .line 2
    sget-object v0, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 3
    .line 4
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    const/4 v1, 0x1

    .line 13
    invoke-static {v1, p0, v0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 14
    .line 15
    .line 16
    move-result p0

    .line 17
    float-to-int p0, p0

    .line 18
    return p0
.end method

.method private native startTelemetryReceiver()V
.end method

.method private native stopTelemetryReceiver()V
.end method

.method public static native takeClientRequestUdp(I)[B
.end method

.method public static native takeNativeMarkerUdp(I)[B
.end method


# virtual methods
.method public native Cases(Landroid/content/Context;IIZLjava/lang/String;)V
.end method

.method public final f(Ljava/lang/String;I)V
    .locals 9

    .line 1
    new-instance v0, Ljava/util/LinkedList;

    .line 2
    .line 3
    const-string v1, "&"

    .line 4
    .line 5
    invoke-virtual {p1, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-direct {v0, p1}, Ljava/util/LinkedList;-><init>(Ljava/util/Collection;)V

    .line 14
    .line 15
    .line 16
    const/4 p1, 0x0

    .line 17
    invoke-virtual {v0, p1}, Ljava/util/LinkedList;->get(I)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    check-cast v0, Ljava/lang/String;

    .line 22
    .line 23
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 24
    .line 25
    const/4 v2, -0x1

    .line 26
    const/4 v3, -0x2

    .line 27
    invoke-direct {v1, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 28
    .line 29
    .line 30
    const/16 v3, 0x8

    .line 31
    .line 32
    invoke-static {v3}, Lgringoxp/game/b;->s(I)I

    .line 33
    .line 34
    .line 35
    move-result v4

    .line 36
    const/16 v5, 0xa

    .line 37
    .line 38
    invoke-static {v5}, Lgringoxp/game/b;->s(I)I

    .line 39
    .line 40
    .line 41
    move-result v5

    .line 42
    invoke-static {v3}, Lgringoxp/game/b;->s(I)I

    .line 43
    .line 44
    .line 45
    move-result v6

    .line 46
    const/4 v7, 0x4

    .line 47
    invoke-static {v7}, Lgringoxp/game/b;->s(I)I

    .line 48
    .line 49
    .line 50
    move-result v8

    .line 51
    invoke-virtual {v1, v4, v5, v6, v8}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 52
    .line 53
    .line 54
    new-instance v4, Landroid/widget/LinearLayout;

    .line 55
    .line 56
    sget-object v5, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 57
    .line 58
    invoke-direct {v4, v5}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 59
    .line 60
    .line 61
    const/4 v5, 0x1

    .line 62
    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v4, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 66
    .line 67
    .line 68
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    invoke-virtual {v4, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    new-instance v1, Landroid/widget/TextView;

    .line 76
    .line 77
    sget-object v6, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 78
    .line 79
    invoke-direct {v1, v6}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 80
    .line 81
    .line 82
    new-instance v6, Ljava/lang/StringBuilder;

    .line 83
    .line 84
    const-string v8, "<b>"

    .line 85
    .line 86
    invoke-direct {v6, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    invoke-virtual {v0}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 94
    .line 95
    .line 96
    const-string v0, "</b>"

    .line 97
    .line 98
    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 99
    .line 100
    .line 101
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    invoke-static {v0}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 110
    .line 111
    .line 112
    const/high16 v0, 0x41280000    # 10.5f

    .line 113
    .line 114
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextSize(F)V

    .line 115
    .line 116
    .line 117
    const-string v0, "#BBBBBB"

    .line 118
    .line 119
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 120
    .line 121
    .line 122
    move-result v0

    .line 123
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 124
    .line 125
    .line 126
    invoke-static {v7}, Lgringoxp/game/b;->s(I)I

    .line 127
    .line 128
    .line 129
    move-result v0

    .line 130
    const/4 v6, 0x2

    .line 131
    invoke-static {v6}, Lgringoxp/game/b;->s(I)I

    .line 132
    .line 133
    .line 134
    move-result v7

    .line 135
    invoke-virtual {v1, v0, p1, p1, v7}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 136
    .line 137
    .line 138
    sget-object v0, Landroid/graphics/Typeface;->SANS_SERIF:Landroid/graphics/Typeface;

    .line 139
    .line 140
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 141
    .line 142
    .line 143
    new-instance v0, Landroid/view/View;

    .line 144
    .line 145
    sget-object v7, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 146
    .line 147
    invoke-direct {v0, v7}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 148
    .line 149
    .line 150
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    .line 151
    .line 152
    invoke-static {v5}, Lgringoxp/game/b;->s(I)I

    .line 153
    .line 154
    .line 155
    move-result v5

    .line 156
    invoke-direct {v7, v2, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 157
    .line 158
    .line 159
    invoke-static {v6}, Lgringoxp/game/b;->s(I)I

    .line 160
    .line 161
    .line 162
    move-result v2

    .line 163
    invoke-static {v6}, Lgringoxp/game/b;->s(I)I

    .line 164
    .line 165
    .line 166
    move-result v5

    .line 167
    invoke-virtual {v7, v2, p1, v5, p1}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {v0, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 171
    .line 172
    .line 173
    const/16 p1, 0x32

    .line 174
    .line 175
    const/16 v2, 0xff

    .line 176
    .line 177
    invoke-static {p1, v2, v2, v2}, Landroid/graphics/Color;->argb(IIII)I

    .line 178
    .line 179
    .line 180
    move-result p1

    .line 181
    invoke-virtual {v0, p1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 182
    .line 183
    .line 184
    invoke-virtual {v4, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 185
    .line 186
    .line 187
    invoke-virtual {v4, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 188
    .line 189
    .line 190
    iget-object p1, p0, Lgringoxp/game/b;->b:Landroid/widget/LinearLayout;

    .line 191
    .line 192
    invoke-virtual {p1, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 193
    .line 194
    .line 195
    if-eqz p2, :cond_0

    .line 196
    .line 197
    invoke-virtual {v4, v3}, Landroid/view/View;->setVisibility(I)V

    .line 198
    .line 199
    .line 200
    :cond_0
    return-void
.end method

.method public final g(Ljava/lang/String;III)V
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 6
    .line 7
    const/16 v3, 0x20

    .line 8
    .line 9
    invoke-static {v3}, Lgringoxp/game/b;->s(I)I

    .line 10
    .line 11
    .line 12
    move-result v3

    .line 13
    const/4 v4, -0x1

    .line 14
    invoke-direct {v2, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 15
    .line 16
    .line 17
    const/4 v3, 0x6

    .line 18
    invoke-static {v3}, Lgringoxp/game/b;->s(I)I

    .line 19
    .line 20
    .line 21
    move-result v5

    .line 22
    const/4 v6, 0x2

    .line 23
    invoke-static {v6}, Lgringoxp/game/b;->s(I)I

    .line 24
    .line 25
    .line 26
    move-result v7

    .line 27
    invoke-static {v3}, Lgringoxp/game/b;->s(I)I

    .line 28
    .line 29
    .line 30
    move-result v8

    .line 31
    invoke-static {v6}, Lgringoxp/game/b;->s(I)I

    .line 32
    .line 33
    .line 34
    move-result v6

    .line 35
    invoke-virtual {v2, v5, v7, v8, v6}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 36
    .line 37
    .line 38
    new-instance v5, Landroid/widget/LinearLayout;

    .line 39
    .line 40
    sget-object v6, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 41
    .line 42
    invoke-direct {v5, v6}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 43
    .line 44
    .line 45
    const/4 v6, 0x0

    .line 46
    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 47
    .line 48
    .line 49
    const/16 v7, 0x10

    .line 50
    .line 51
    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 52
    .line 53
    .line 54
    const/16 v7, 0x8

    .line 55
    .line 56
    invoke-static {v7}, Lgringoxp/game/b;->s(I)I

    .line 57
    .line 58
    .line 59
    move-result v8

    .line 60
    invoke-static {v7}, Lgringoxp/game/b;->s(I)I

    .line 61
    .line 62
    .line 63
    move-result v9

    .line 64
    invoke-virtual {v5, v8, v6, v9, v6}, Landroid/view/View;->setPadding(IIII)V

    .line 65
    .line 66
    .line 67
    invoke-virtual {v5, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 68
    .line 69
    .line 70
    invoke-static/range {p4 .. p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 71
    .line 72
    .line 73
    move-result-object v2

    .line 74
    invoke-virtual {v5, v2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    .line 78
    .line 79
    invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 80
    .line 81
    .line 82
    const/16 v8, 0x14

    .line 83
    .line 84
    const/16 v9, 0xff

    .line 85
    .line 86
    invoke-static {v8, v9, v9, v9}, Landroid/graphics/Color;->argb(IIII)I

    .line 87
    .line 88
    .line 89
    move-result v8

    .line 90
    invoke-virtual {v2, v8}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 91
    .line 92
    .line 93
    invoke-static {v3}, Lgringoxp/game/b;->s(I)I

    .line 94
    .line 95
    .line 96
    move-result v8

    .line 97
    int-to-float v8, v8

    .line 98
    invoke-virtual {v2, v8}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 99
    .line 100
    .line 101
    const/4 v8, 0x1

    .line 102
    invoke-static {v8}, Lgringoxp/game/b;->s(I)I

    .line 103
    .line 104
    .line 105
    move-result v10

    .line 106
    const/16 v11, 0x28

    .line 107
    .line 108
    invoke-static {v11, v9, v9, v9}, Landroid/graphics/Color;->argb(IIII)I

    .line 109
    .line 110
    .line 111
    move-result v12

    .line 112
    invoke-virtual {v2, v10, v12}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 113
    .line 114
    .line 115
    new-instance v15, Landroid/graphics/drawable/GradientDrawable;

    .line 116
    .line 117
    invoke-direct {v15}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 118
    .line 119
    .line 120
    const/16 v10, 0x23

    .line 121
    .line 122
    const/16 v12, 0x2e

    .line 123
    .line 124
    const/16 v13, 0xcc

    .line 125
    .line 126
    const/16 v14, 0x71

    .line 127
    .line 128
    invoke-static {v10, v12, v13, v14}, Landroid/graphics/Color;->argb(IIII)I

    .line 129
    .line 130
    .line 131
    move-result v10

    .line 132
    invoke-virtual {v15, v10}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 133
    .line 134
    .line 135
    invoke-static {v3}, Lgringoxp/game/b;->s(I)I

    .line 136
    .line 137
    .line 138
    move-result v3

    .line 139
    int-to-float v3, v3

    .line 140
    invoke-virtual {v15, v3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 141
    .line 142
    .line 143
    invoke-static {v8}, Lgringoxp/game/b;->s(I)I

    .line 144
    .line 145
    .line 146
    move-result v3

    .line 147
    const-string v10, "#2ECC71"

    .line 148
    .line 149
    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 150
    .line 151
    .line 152
    move-result v12

    .line 153
    invoke-virtual {v15, v3, v12}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 154
    .line 155
    .line 156
    invoke-virtual {v5, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 157
    .line 158
    .line 159
    new-instance v3, Landroid/widget/TextView;

    .line 160
    .line 161
    sget-object v12, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 162
    .line 163
    invoke-direct {v3, v12}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 164
    .line 165
    .line 166
    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 167
    .line 168
    .line 169
    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setTextColor(I)V

    .line 170
    .line 171
    .line 172
    const/high16 v12, 0x41380000    # 11.5f

    .line 173
    .line 174
    invoke-virtual {v3, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 175
    .line 176
    .line 177
    sget-object v12, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    .line 178
    .line 179
    invoke-virtual {v3, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 180
    .line 181
    .line 182
    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    .line 183
    .line 184
    const/4 v13, -0x2

    .line 185
    const/high16 v14, 0x3f800000    # 1.0f

    .line 186
    .line 187
    invoke-direct {v12, v6, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 188
    .line 189
    .line 190
    invoke-virtual {v3, v12}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 191
    .line 192
    .line 193
    new-instance v14, Landroid/widget/TextView;

    .line 194
    .line 195
    sget-object v12, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 196
    .line 197
    invoke-direct {v14, v12}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 198
    .line 199
    .line 200
    const/high16 v12, 0x41100000    # 9.0f

    .line 201
    .line 202
    invoke-virtual {v14, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 203
    .line 204
    .line 205
    const/16 v12, 0x11

    .line 206
    .line 207
    invoke-virtual {v14, v12}, Landroid/widget/TextView;->setGravity(I)V

    .line 208
    .line 209
    .line 210
    invoke-virtual {v14, v4}, Landroid/widget/TextView;->setTextColor(I)V

    .line 211
    .line 212
    .line 213
    sget-object v4, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    .line 214
    .line 215
    invoke-virtual {v14, v4, v8}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 216
    .line 217
    .line 218
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    .line 219
    .line 220
    invoke-static {v11}, Lgringoxp/game/b;->s(I)I

    .line 221
    .line 222
    .line 223
    move-result v11

    .line 224
    const/16 v12, 0x12

    .line 225
    .line 226
    invoke-static {v12}, Lgringoxp/game/b;->s(I)I

    .line 227
    .line 228
    .line 229
    move-result v12

    .line 230
    invoke-direct {v4, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 231
    .line 232
    .line 233
    invoke-virtual {v14, v4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 234
    .line 235
    .line 236
    new-instance v13, Landroid/graphics/drawable/GradientDrawable;

    .line 237
    .line 238
    invoke-direct {v13}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 239
    .line 240
    .line 241
    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 242
    .line 243
    .line 244
    move-result v4

    .line 245
    invoke-virtual {v13, v4}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 246
    .line 247
    .line 248
    const/16 v4, 0x9

    .line 249
    .line 250
    invoke-static {v4}, Lgringoxp/game/b;->s(I)I

    .line 251
    .line 252
    .line 253
    move-result v10

    .line 254
    int-to-float v10, v10

    .line 255
    invoke-virtual {v13, v10}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 256
    .line 257
    .line 258
    invoke-static {v8}, Lgringoxp/game/b;->s(I)I

    .line 259
    .line 260
    .line 261
    move-result v10

    .line 262
    const/16 v11, 0x50

    .line 263
    .line 264
    invoke-static {v11, v9, v9, v9}, Landroid/graphics/Color;->argb(IIII)I

    .line 265
    .line 266
    .line 267
    move-result v12

    .line 268
    invoke-virtual {v13, v10, v12}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 269
    .line 270
    .line 271
    new-instance v12, Landroid/graphics/drawable/GradientDrawable;

    .line 272
    .line 273
    invoke-direct {v12}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 274
    .line 275
    .line 276
    const-string v10, "#2A2A2A"

    .line 277
    .line 278
    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 279
    .line 280
    .line 281
    move-result v10

    .line 282
    invoke-virtual {v12, v10}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 283
    .line 284
    .line 285
    invoke-static {v4}, Lgringoxp/game/b;->s(I)I

    .line 286
    .line 287
    .line 288
    move-result v4

    .line 289
    int-to-float v4, v4

    .line 290
    invoke-virtual {v12, v4}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 291
    .line 292
    .line 293
    invoke-static {v8}, Lgringoxp/game/b;->s(I)I

    .line 294
    .line 295
    .line 296
    move-result v4

    .line 297
    invoke-static {v11, v9, v9, v9}, Landroid/graphics/Color;->argb(IIII)I

    .line 298
    .line 299
    .line 300
    move-result v9

    .line 301
    invoke-virtual {v12, v4, v9}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 302
    .line 303
    .line 304
    new-instance v11, Lp/s1;

    .line 305
    .line 306
    move/from16 v4, p3

    .line 307
    .line 308
    invoke-direct {v11, v0, v4, v1}, Lp/s1;-><init>(Lgringoxp/game/b;ILjava/lang/String;)V

    .line 309
    .line 310
    .line 311
    move/from16 v1, p2

    .line 312
    .line 313
    if-ne v1, v8, :cond_0

    .line 314
    .line 315
    move v1, v8

    .line 316
    goto :goto_0

    .line 317
    :cond_0
    move v1, v6

    .line 318
    :goto_0
    new-array v10, v8, [Z

    .line 319
    .line 320
    aput-boolean v1, v10, v6

    .line 321
    .line 322
    aget-boolean v1, v10, v6

    .line 323
    .line 324
    if-eqz v1, :cond_1

    .line 325
    .line 326
    const-string v1, "ON"

    .line 327
    .line 328
    invoke-virtual {v14, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 329
    .line 330
    .line 331
    invoke-virtual {v14, v13}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 332
    .line 333
    .line 334
    invoke-virtual {v5, v15}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 335
    .line 336
    .line 337
    invoke-virtual {v11, v6, v8}, Lp/s1;->a(IZ)V

    .line 338
    .line 339
    .line 340
    goto :goto_1

    .line 341
    :cond_1
    const-string v1, "OFF"

    .line 342
    .line 343
    invoke-virtual {v14, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 344
    .line 345
    .line 346
    invoke-virtual {v14, v12}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 347
    .line 348
    .line 349
    :goto_1
    new-instance v1, Lp/Ei;

    .line 350
    .line 351
    move-object v9, v1

    .line 352
    move-object v4, v12

    .line 353
    move-object v12, v14

    .line 354
    move-object v6, v14

    .line 355
    move-object v14, v5

    .line 356
    move-object/from16 v16, v4

    .line 357
    .line 358
    move-object/from16 v17, v2

    .line 359
    .line 360
    invoke-direct/range {v9 .. v17}, Lp/Ei;-><init>([ZLp/s1;Landroid/widget/TextView;Landroid/graphics/drawable/GradientDrawable;Landroid/widget/LinearLayout;Landroid/graphics/drawable/GradientDrawable;Landroid/graphics/drawable/GradientDrawable;Landroid/graphics/drawable/GradientDrawable;)V

    .line 361
    .line 362
    .line 363
    invoke-virtual {v5, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 364
    .line 365
    .line 366
    invoke-virtual {v5, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 367
    .line 368
    .line 369
    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 370
    .line 371
    .line 372
    iget-object v1, v0, Lgringoxp/game/b;->b:Landroid/widget/LinearLayout;

    .line 373
    .line 374
    invoke-virtual {v1, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 375
    .line 376
    .line 377
    if-eqz p4, :cond_2

    .line 378
    .line 379
    invoke-virtual {v5, v7}, Landroid/view/View;->setVisibility(I)V

    .line 380
    .line 381
    .line 382
    :cond_2
    return-void
.end method

.method public final h(Ljava/lang/String;IIII)V
    .locals 14

    .line 1
    move-object v0, p0

    .line 2
    move/from16 v1, p2

    .line 3
    .line 4
    const-string v2, ">"

    .line 5
    .line 6
    move-object v3, p1

    .line 7
    invoke-virtual {p1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    const/4 v3, 0x0

    .line 12
    aget-object v4, v2, v3

    .line 13
    .line 14
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    .line 15
    .line 16
    const/4 v6, -0x1

    .line 17
    const/4 v7, -0x2

    .line 18
    invoke-direct {v5, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 19
    .line 20
    .line 21
    const/16 v7, 0x8

    .line 22
    .line 23
    invoke-static {v7}, Lgringoxp/game/b;->s(I)I

    .line 24
    .line 25
    .line 26
    move-result v8

    .line 27
    const/4 v9, 0x2

    .line 28
    invoke-static {v9}, Lgringoxp/game/b;->s(I)I

    .line 29
    .line 30
    .line 31
    move-result v10

    .line 32
    invoke-static {v7}, Lgringoxp/game/b;->s(I)I

    .line 33
    .line 34
    .line 35
    move-result v11

    .line 36
    invoke-static {v9}, Lgringoxp/game/b;->s(I)I

    .line 37
    .line 38
    .line 39
    move-result v9

    .line 40
    invoke-virtual {v5, v8, v10, v11, v9}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 41
    .line 42
    .line 43
    new-instance v8, Landroid/widget/LinearLayout;

    .line 44
    .line 45
    sget-object v9, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 46
    .line 47
    invoke-direct {v8, v9}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 48
    .line 49
    .line 50
    const/4 v9, 0x1

    .line 51
    invoke-virtual {v8, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 52
    .line 53
    .line 54
    const/16 v10, 0xa

    .line 55
    .line 56
    invoke-static {v10}, Lgringoxp/game/b;->s(I)I

    .line 57
    .line 58
    .line 59
    move-result v11

    .line 60
    const/4 v12, 0x4

    .line 61
    invoke-static {v12}, Lgringoxp/game/b;->s(I)I

    .line 62
    .line 63
    .line 64
    move-result v13

    .line 65
    invoke-static {v10}, Lgringoxp/game/b;->s(I)I

    .line 66
    .line 67
    .line 68
    move-result v10

    .line 69
    invoke-static {v12}, Lgringoxp/game/b;->s(I)I

    .line 70
    .line 71
    .line 72
    move-result v12

    .line 73
    invoke-virtual {v8, v11, v13, v10, v12}, Landroid/view/View;->setPadding(IIII)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {v8, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 77
    .line 78
    .line 79
    invoke-static/range {p5 .. p5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 80
    .line 81
    .line 82
    move-result-object v5

    .line 83
    invoke-virtual {v8, v5}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    new-instance v5, Landroid/graphics/drawable/GradientDrawable;

    .line 87
    .line 88
    invoke-direct {v5}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 89
    .line 90
    .line 91
    const/16 v10, 0x19

    .line 92
    .line 93
    const/16 v11, 0xff

    .line 94
    .line 95
    invoke-static {v10, v11, v11, v11}, Landroid/graphics/Color;->argb(IIII)I

    .line 96
    .line 97
    .line 98
    move-result v10

    .line 99
    invoke-virtual {v5, v10}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 100
    .line 101
    .line 102
    const/4 v10, 0x6

    .line 103
    invoke-static {v10}, Lgringoxp/game/b;->s(I)I

    .line 104
    .line 105
    .line 106
    move-result v10

    .line 107
    int-to-float v10, v10

    .line 108
    invoke-virtual {v5, v10}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 109
    .line 110
    .line 111
    invoke-virtual {v8, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 112
    .line 113
    .line 114
    new-instance v5, Landroid/widget/TextView;

    .line 115
    .line 116
    sget-object v10, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 117
    .line 118
    invoke-direct {v5, v10}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 119
    .line 120
    .line 121
    const/high16 v10, 0x41300000    # 11.0f

    .line 122
    .line 123
    invoke-virtual {v5, v10}, Landroid/widget/TextView;->setTextSize(F)V

    .line 124
    .line 125
    .line 126
    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 127
    .line 128
    .line 129
    new-instance v6, Lp/s1;

    .line 130
    .line 131
    move/from16 v10, p4

    .line 132
    .line 133
    invoke-direct {v6, p0, v10, v4}, Lp/s1;-><init>(Lgringoxp/game/b;ILjava/lang/String;)V

    .line 134
    .line 135
    .line 136
    new-instance v10, Landroid/widget/SeekBar;

    .line 137
    .line 138
    sget-object v11, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 139
    .line 140
    invoke-direct {v10, v11}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    .line 141
    .line 142
    .line 143
    add-int/lit8 v11, p3, -0x1

    .line 144
    .line 145
    invoke-virtual {v10, v11}, Landroid/widget/ProgressBar;->setMax(I)V

    .line 146
    .line 147
    .line 148
    invoke-virtual {v10, v1}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 149
    .line 150
    .line 151
    invoke-static {v3}, Lgringoxp/game/b;->s(I)I

    .line 152
    .line 153
    .line 154
    move-result v11

    .line 155
    invoke-virtual {v10, v11}, Landroid/widget/AbsSeekBar;->setThumbOffset(I)V

    .line 156
    .line 157
    .line 158
    invoke-virtual {v10, v3}, Landroid/widget/AbsSeekBar;->setSplitTrack(Z)V

    .line 159
    .line 160
    .line 161
    const/4 v3, 0x5

    .line 162
    invoke-static {v3}, Lgringoxp/game/b;->s(I)I

    .line 163
    .line 164
    .line 165
    move-result v11

    .line 166
    invoke-static {v7}, Lgringoxp/game/b;->s(I)I

    .line 167
    .line 168
    .line 169
    move-result v12

    .line 170
    invoke-static {v3}, Lgringoxp/game/b;->s(I)I

    .line 171
    .line 172
    .line 173
    move-result v3

    .line 174
    invoke-static {v7}, Lgringoxp/game/b;->s(I)I

    .line 175
    .line 176
    .line 177
    move-result v13

    .line 178
    invoke-virtual {v10, v11, v12, v3, v13}, Landroid/view/View;->setPadding(IIII)V

    .line 179
    .line 180
    .line 181
    new-instance v3, Lp/Fi;

    .line 182
    .line 183
    invoke-direct {v3, v6, v2, v5, v4}, Lp/Fi;-><init>(Lp/s1;[Ljava/lang/String;Landroid/widget/TextView;Ljava/lang/String;)V

    .line 184
    .line 185
    .line 186
    invoke-virtual {v10, v3}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 187
    .line 188
    .line 189
    array-length v3, v2

    .line 190
    const-string v6, "</font>"

    .line 191
    .line 192
    const-string v11, ": <font color=\'#2ECC71\'>"

    .line 193
    .line 194
    if-le v3, v9, :cond_0

    .line 195
    .line 196
    add-int/lit8 v3, v1, 0x1

    .line 197
    .line 198
    array-length v9, v2

    .line 199
    if-ge v3, v9, :cond_0

    .line 200
    .line 201
    new-instance v1, Ljava/lang/StringBuilder;

    .line 202
    .line 203
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 204
    .line 205
    .line 206
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 207
    .line 208
    .line 209
    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 210
    .line 211
    .line 212
    aget-object v2, v2, v3

    .line 213
    .line 214
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 215
    .line 216
    .line 217
    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 218
    .line 219
    .line 220
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 221
    .line 222
    .line 223
    move-result-object v1

    .line 224
    invoke-static {v1}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    .line 225
    .line 226
    .line 227
    move-result-object v1

    .line 228
    invoke-virtual {v5, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 229
    .line 230
    .line 231
    goto :goto_0

    .line 232
    :cond_0
    new-instance v2, Ljava/lang/StringBuilder;

    .line 233
    .line 234
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 235
    .line 236
    .line 237
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 238
    .line 239
    .line 240
    invoke-virtual {v2, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 241
    .line 242
    .line 243
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 244
    .line 245
    .line 246
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 247
    .line 248
    .line 249
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 250
    .line 251
    .line 252
    move-result-object v1

    .line 253
    invoke-static {v1}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    .line 254
    .line 255
    .line 256
    move-result-object v1

    .line 257
    invoke-virtual {v5, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 258
    .line 259
    .line 260
    :goto_0
    invoke-virtual {v8, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 261
    .line 262
    .line 263
    invoke-virtual {v8, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 264
    .line 265
    .line 266
    iget-object v1, v0, Lgringoxp/game/b;->b:Landroid/widget/LinearLayout;

    .line 267
    .line 268
    invoke-virtual {v1, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 269
    .line 270
    .line 271
    if-eqz p5, :cond_1

    .line 272
    .line 273
    invoke-virtual {v8, v7}, Landroid/view/View;->setVisibility(I)V

    .line 274
    .line 275
    .line 276
    :cond_1
    return-void
.end method

.method public final i(Ljava/lang/String;II)V
    .locals 8

    .line 1
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 2
    .line 3
    const/16 v1, 0x20

    .line 4
    .line 5
    invoke-static {v1}, Lgringoxp/game/b;->s(I)I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v2, -0x1

    .line 10
    invoke-direct {v0, v2, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 11
    .line 12
    .line 13
    const/4 v1, 0x6

    .line 14
    invoke-static {v1}, Lgringoxp/game/b;->s(I)I

    .line 15
    .line 16
    .line 17
    move-result v3

    .line 18
    const/4 v4, 0x2

    .line 19
    invoke-static {v4}, Lgringoxp/game/b;->s(I)I

    .line 20
    .line 21
    .line 22
    move-result v5

    .line 23
    invoke-static {v1}, Lgringoxp/game/b;->s(I)I

    .line 24
    .line 25
    .line 26
    move-result v6

    .line 27
    invoke-static {v4}, Lgringoxp/game/b;->s(I)I

    .line 28
    .line 29
    .line 30
    move-result v4

    .line 31
    invoke-virtual {v0, v3, v5, v6, v4}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 32
    .line 33
    .line 34
    new-instance v3, Landroid/widget/LinearLayout;

    .line 35
    .line 36
    sget-object v4, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 37
    .line 38
    invoke-direct {v3, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 39
    .line 40
    .line 41
    const/4 v4, 0x0

    .line 42
    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 43
    .line 44
    .line 45
    const/16 v5, 0x10

    .line 46
    .line 47
    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 48
    .line 49
    .line 50
    const/16 v5, 0x8

    .line 51
    .line 52
    invoke-static {v5}, Lgringoxp/game/b;->s(I)I

    .line 53
    .line 54
    .line 55
    move-result v6

    .line 56
    invoke-static {v5}, Lgringoxp/game/b;->s(I)I

    .line 57
    .line 58
    .line 59
    move-result v7

    .line 60
    invoke-virtual {v3, v6, v4, v7, v4}, Landroid/view/View;->setPadding(IIII)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {v3, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 64
    .line 65
    .line 66
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    invoke-virtual {v3, v0}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    .line 74
    .line 75
    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 76
    .line 77
    .line 78
    const/16 v6, 0x19

    .line 79
    .line 80
    const/16 v7, 0xff

    .line 81
    .line 82
    invoke-static {v6, v7, v7, v7}, Landroid/graphics/Color;->argb(IIII)I

    .line 83
    .line 84
    .line 85
    move-result v6

    .line 86
    invoke-virtual {v0, v6}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 87
    .line 88
    .line 89
    invoke-static {v1}, Lgringoxp/game/b;->s(I)I

    .line 90
    .line 91
    .line 92
    move-result v1

    .line 93
    int-to-float v1, v1

    .line 94
    invoke-virtual {v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 95
    .line 96
    .line 97
    const/16 v1, 0x50

    .line 98
    .line 99
    invoke-static {v1, v7, v7, v7}, Landroid/graphics/Color;->argb(IIII)I

    .line 100
    .line 101
    .line 102
    move-result v1

    .line 103
    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 104
    .line 105
    .line 106
    move-result-object v1

    .line 107
    new-instance v6, Landroid/graphics/drawable/RippleDrawable;

    .line 108
    .line 109
    const/4 v7, 0x0

    .line 110
    invoke-direct {v6, v1, v0, v7}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 111
    .line 112
    .line 113
    invoke-virtual {v3, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 114
    .line 115
    .line 116
    const/4 v0, 0x1

    .line 117
    invoke-virtual {v3, v0}, Landroid/view/View;->setClickable(Z)V

    .line 118
    .line 119
    .line 120
    invoke-virtual {v3, v0}, Landroid/view/View;->setFocusable(Z)V

    .line 121
    .line 122
    .line 123
    new-instance v0, Landroid/widget/TextView;

    .line 124
    .line 125
    sget-object v1, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 126
    .line 127
    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 131
    .line 132
    .line 133
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 134
    .line 135
    .line 136
    const/high16 v1, 0x41380000    # 11.5f

    .line 137
    .line 138
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextSize(F)V

    .line 139
    .line 140
    .line 141
    sget-object v1, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    .line 142
    .line 143
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 144
    .line 145
    .line 146
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 147
    .line 148
    const/4 v2, -0x2

    .line 149
    const/high16 v6, 0x3f800000    # 1.0f

    .line 150
    .line 151
    invoke-direct {v1, v4, v2, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 152
    .line 153
    .line 154
    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 155
    .line 156
    .line 157
    new-instance v1, Lp/s1;

    .line 158
    .line 159
    invoke-direct {v1, p0, p2, p1}, Lp/s1;-><init>(Lgringoxp/game/b;ILjava/lang/String;)V

    .line 160
    .line 161
    .line 162
    new-instance p1, Lp/P;

    .line 163
    .line 164
    const/4 p2, 0x4

    .line 165
    invoke-direct {p1, p2, v1}, Lp/P;-><init>(ILjava/lang/Object;)V

    .line 166
    .line 167
    .line 168
    invoke-virtual {v3, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 169
    .line 170
    .line 171
    invoke-virtual {v3, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 172
    .line 173
    .line 174
    iget-object p1, p0, Lgringoxp/game/b;->b:Landroid/widget/LinearLayout;

    .line 175
    .line 176
    invoke-virtual {p1, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 177
    .line 178
    .line 179
    if-eqz p3, :cond_0

    .line 180
    .line 181
    invoke-virtual {v3, v5}, Landroid/view/View;->setVisibility(I)V

    .line 182
    .line 183
    .line 184
    :cond_0
    return-void
.end method

.method public native injectLogoUI(Landroid/content/Context;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/view/View;)V
.end method

.method public final j(Ljava/lang/String;III)V
    .locals 12

    .line 1
    move-object v6, p0

    .line 2
    move-object v0, p1

    .line 3
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 4
    .line 5
    const/16 v2, 0x20

    .line 6
    .line 7
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    const/4 v3, -0x1

    .line 12
    invoke-direct {v1, v3, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 13
    .line 14
    .line 15
    const/4 v2, 0x6

    .line 16
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 17
    .line 18
    .line 19
    move-result v4

    .line 20
    const/4 v5, 0x2

    .line 21
    invoke-static {v5}, Lgringoxp/game/b;->s(I)I

    .line 22
    .line 23
    .line 24
    move-result v7

    .line 25
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 26
    .line 27
    .line 28
    move-result v8

    .line 29
    invoke-static {v5}, Lgringoxp/game/b;->s(I)I

    .line 30
    .line 31
    .line 32
    move-result v5

    .line 33
    invoke-virtual {v1, v4, v7, v8, v5}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 34
    .line 35
    .line 36
    new-instance v7, Landroid/widget/LinearLayout;

    .line 37
    .line 38
    sget-object v4, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 39
    .line 40
    invoke-direct {v7, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 41
    .line 42
    .line 43
    const/4 v4, 0x0

    .line 44
    invoke-virtual {v7, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 45
    .line 46
    .line 47
    const/16 v5, 0x10

    .line 48
    .line 49
    invoke-virtual {v7, v5}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 50
    .line 51
    .line 52
    const/16 v8, 0x8

    .line 53
    .line 54
    invoke-static {v8}, Lgringoxp/game/b;->s(I)I

    .line 55
    .line 56
    .line 57
    move-result v5

    .line 58
    invoke-static {v8}, Lgringoxp/game/b;->s(I)I

    .line 59
    .line 60
    .line 61
    move-result v9

    .line 62
    invoke-virtual {v7, v5, v4, v9, v4}, Landroid/view/View;->setPadding(IIII)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v7, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 66
    .line 67
    .line 68
    invoke-static/range {p4 .. p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    invoke-virtual {v7, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    .line 76
    .line 77
    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 78
    .line 79
    .line 80
    const/16 v5, 0x19

    .line 81
    .line 82
    const/16 v9, 0xff

    .line 83
    .line 84
    invoke-static {v5, v9, v9, v9}, Landroid/graphics/Color;->argb(IIII)I

    .line 85
    .line 86
    .line 87
    move-result v5

    .line 88
    invoke-virtual {v1, v5}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 89
    .line 90
    .line 91
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 92
    .line 93
    .line 94
    move-result v2

    .line 95
    int-to-float v2, v2

    .line 96
    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {v7, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 100
    .line 101
    .line 102
    new-instance v9, Landroid/widget/TextView;

    .line 103
    .line 104
    sget-object v1, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 105
    .line 106
    invoke-direct {v9, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v9, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {v9, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 113
    .line 114
    .line 115
    const/high16 v1, 0x41380000    # 11.5f

    .line 116
    .line 117
    invoke-virtual {v9, v1}, Landroid/widget/TextView;->setTextSize(F)V

    .line 118
    .line 119
    .line 120
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 121
    .line 122
    const/4 v2, -0x2

    .line 123
    const/high16 v3, 0x3f800000    # 1.0f

    .line 124
    .line 125
    invoke-direct {v1, v4, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 126
    .line 127
    .line 128
    invoke-virtual {v9, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 129
    .line 130
    .line 131
    new-instance v10, Landroid/view/View;

    .line 132
    .line 133
    sget-object v1, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 134
    .line 135
    invoke-direct {v10, v1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 136
    .line 137
    .line 138
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 139
    .line 140
    const/16 v2, 0x14

    .line 141
    .line 142
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 143
    .line 144
    .line 145
    move-result v3

    .line 146
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 147
    .line 148
    .line 149
    move-result v2

    .line 150
    invoke-direct {v1, v3, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 151
    .line 152
    .line 153
    const/4 v2, 0x5

    .line 154
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 155
    .line 156
    .line 157
    move-result v3

    .line 158
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 159
    .line 160
    .line 161
    move-result v2

    .line 162
    invoke-virtual {v1, v3, v4, v2, v4}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 163
    .line 164
    .line 165
    invoke-virtual {v10, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 166
    .line 167
    .line 168
    new-instance v3, Landroid/graphics/drawable/GradientDrawable;

    .line 169
    .line 170
    invoke-direct {v3}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 171
    .line 172
    .line 173
    const/4 v1, 0x4

    .line 174
    invoke-static {v1}, Lgringoxp/game/b;->s(I)I

    .line 175
    .line 176
    .line 177
    move-result v1

    .line 178
    int-to-float v1, v1

    .line 179
    invoke-virtual {v3, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 180
    .line 181
    .line 182
    const/4 v1, 0x1

    .line 183
    invoke-static {v1}, Lgringoxp/game/b;->s(I)I

    .line 184
    .line 185
    .line 186
    move-result v1

    .line 187
    const-string v2, "#88FFFFFF"

    .line 188
    .line 189
    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 190
    .line 191
    .line 192
    move-result v2

    .line 193
    invoke-virtual {v3, v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 194
    .line 195
    .line 196
    move v1, p2

    .line 197
    invoke-virtual {v3, p2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 198
    .line 199
    .line 200
    invoke-virtual {v10, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 201
    .line 202
    .line 203
    new-instance v5, Lp/s1;

    .line 204
    .line 205
    move v2, p3

    .line 206
    invoke-direct {v5, p0, p3, p1}, Lp/s1;-><init>(Lgringoxp/game/b;ILjava/lang/String;)V

    .line 207
    .line 208
    .line 209
    filled-new-array {p2}, [I

    .line 210
    .line 211
    .line 212
    move-result-object v2

    .line 213
    new-instance v11, Lp/Ii;

    .line 214
    .line 215
    move-object v0, v11

    .line 216
    move-object v1, p0

    .line 217
    move-object v4, v10

    .line 218
    invoke-direct/range {v0 .. v5}, Lp/Ii;-><init>(Lgringoxp/game/b;[ILandroid/graphics/drawable/GradientDrawable;Landroid/view/View;Lp/s1;)V

    .line 219
    .line 220
    .line 221
    invoke-virtual {v7, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 222
    .line 223
    .line 224
    invoke-virtual {v7, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 225
    .line 226
    .line 227
    invoke-virtual {v7, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 228
    .line 229
    .line 230
    iget-object v0, v6, Lgringoxp/game/b;->b:Landroid/widget/LinearLayout;

    .line 231
    .line 232
    invoke-virtual {v0, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 233
    .line 234
    .line 235
    if-eqz p4, :cond_0

    .line 236
    .line 237
    invoke-virtual {v7, v8}, Landroid/view/View;->setVisibility(I)V

    .line 238
    .line 239
    .line 240
    :cond_0
    return-void
.end method

.method public final k(Ljava/lang/String;III)V
    .locals 6

    .line 1
    new-instance v0, Landroid/widget/CheckBox;

    .line 2
    .line 3
    sget-object v1, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 4
    .line 5
    invoke-direct {v0, v1}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 9
    .line 10
    .line 11
    const/4 v1, -0x1

    .line 12
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 13
    .line 14
    .line 15
    const/high16 v2, 0x41380000    # 11.5f

    .line 16
    .line 17
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextSize(F)V

    .line 18
    .line 19
    .line 20
    const/16 v2, 0x12

    .line 21
    .line 22
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    const/16 v3, 0x8

    .line 27
    .line 28
    invoke-static {v3}, Lgringoxp/game/b;->s(I)I

    .line 29
    .line 30
    .line 31
    move-result v4

    .line 32
    const/4 v5, 0x0

    .line 33
    invoke-virtual {v0, v2, v5, v4, v5}, Landroid/view/View;->setPadding(IIII)V

    .line 34
    .line 35
    .line 36
    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    invoke-virtual {v0, v2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    const/4 v2, 0x1

    .line 44
    if-ne p2, v2, :cond_0

    .line 45
    .line 46
    goto :goto_0

    .line 47
    :cond_0
    move v2, v5

    .line 48
    :goto_0
    invoke-virtual {v0, v2}, Landroid/widget/CompoundButton;->setChecked(Z)V

    .line 49
    .line 50
    .line 51
    sget p2, Lgringoxp/game/b;->h:I

    .line 52
    .line 53
    invoke-static {p2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 54
    .line 55
    .line 56
    move-result-object p2

    .line 57
    invoke-virtual {v0, p2}, Landroid/widget/CompoundButton;->setButtonTintList(Landroid/content/res/ColorStateList;)V

    .line 58
    .line 59
    .line 60
    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    .line 61
    .line 62
    const/16 v2, 0x22

    .line 63
    .line 64
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 65
    .line 66
    .line 67
    move-result v2

    .line 68
    invoke-direct {p2, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 69
    .line 70
    .line 71
    const/16 v1, 0xc

    .line 72
    .line 73
    invoke-static {v1}, Lgringoxp/game/b;->s(I)I

    .line 74
    .line 75
    .line 76
    move-result v1

    .line 77
    const/4 v2, 0x6

    .line 78
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 79
    .line 80
    .line 81
    move-result v2

    .line 82
    invoke-virtual {p2, v1, v5, v2, v5}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {v0, p2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 86
    .line 87
    .line 88
    new-instance p2, Lp/s1;

    .line 89
    .line 90
    invoke-direct {p2, p0, p3, p1}, Lp/s1;-><init>(Lgringoxp/game/b;ILjava/lang/String;)V

    .line 91
    .line 92
    .line 93
    new-instance p1, Lp/u3;

    .line 94
    .line 95
    const/4 p3, 0x1

    .line 96
    invoke-direct {p1, p3, p2}, Lp/u3;-><init>(ILjava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {v0, p1}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 100
    .line 101
    .line 102
    iget-object p1, p0, Lgringoxp/game/b;->b:Landroid/widget/LinearLayout;

    .line 103
    .line 104
    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 105
    .line 106
    .line 107
    if-eqz p4, :cond_1

    .line 108
    .line 109
    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    .line 110
    .line 111
    .line 112
    :cond_1
    return-void
.end method

.method public final l(Ljava/lang/String;I)V
    .locals 5

    .line 1
    new-instance v0, Landroid/widget/TextView;

    .line 2
    .line 3
    sget-object v1, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 4
    .line 5
    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 9
    .line 10
    .line 11
    const-string p1, "#B7C2CF"

    .line 12
    .line 13
    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 18
    .line 19
    .line 20
    const/high16 p1, 0x41280000    # 10.5f

    .line 21
    .line 22
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextSize(F)V

    .line 23
    .line 24
    .line 25
    const/4 p1, 0x0

    .line 26
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setIncludeFontPadding(Z)V

    .line 30
    .line 31
    .line 32
    const/4 p1, 0x2

    .line 33
    invoke-static {p1}, Lgringoxp/game/b;->s(I)I

    .line 34
    .line 35
    .line 36
    move-result p1

    .line 37
    int-to-float p1, p1

    .line 38
    const/high16 v1, 0x3f800000    # 1.0f

    .line 39
    .line 40
    invoke-virtual {v0, p1, v1}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 41
    .line 42
    .line 43
    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    .line 44
    .line 45
    const/4 v1, -0x1

    .line 46
    const/4 v2, -0x2

    .line 47
    invoke-direct {p1, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 48
    .line 49
    .line 50
    const/16 v1, 0xe

    .line 51
    .line 52
    invoke-static {v1}, Lgringoxp/game/b;->s(I)I

    .line 53
    .line 54
    .line 55
    move-result v2

    .line 56
    const/4 v3, 0x1

    .line 57
    invoke-static {v3}, Lgringoxp/game/b;->s(I)I

    .line 58
    .line 59
    .line 60
    move-result v3

    .line 61
    invoke-static {v1}, Lgringoxp/game/b;->s(I)I

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    const/4 v4, 0x7

    .line 66
    invoke-static {v4}, Lgringoxp/game/b;->s(I)I

    .line 67
    .line 68
    .line 69
    move-result v4

    .line 70
    invoke-virtual {p1, v2, v3, v1, v4}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 71
    .line 72
    .line 73
    invoke-virtual {v0, p1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 74
    .line 75
    .line 76
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    invoke-virtual {v0, p1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 81
    .line 82
    .line 83
    if-eqz p2, :cond_0

    .line 84
    .line 85
    const/16 p1, 0x8

    .line 86
    .line 87
    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    .line 88
    .line 89
    .line 90
    :cond_0
    iget-object p1, p0, Lgringoxp/game/b;->b:Landroid/widget/LinearLayout;

    .line 91
    .line 92
    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 93
    .line 94
    .line 95
    return-void
.end method

.method public final m(Ljava/lang/String;I)V
    .locals 9

    .line 1
    new-instance v0, Landroid/widget/LinearLayout;

    .line 2
    .line 3
    sget-object v1, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 4
    .line 5
    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 6
    .line 7
    .line 8
    const/4 v1, 0x1

    .line 9
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 10
    .line 11
    .line 12
    const/16 v2, 0xa

    .line 13
    .line 14
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 15
    .line 16
    .line 17
    move-result v3

    .line 18
    const/16 v4, 0x8

    .line 19
    .line 20
    invoke-static {v4}, Lgringoxp/game/b;->s(I)I

    .line 21
    .line 22
    .line 23
    move-result v5

    .line 24
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    invoke-static {v4}, Lgringoxp/game/b;->s(I)I

    .line 29
    .line 30
    .line 31
    move-result v6

    .line 32
    invoke-virtual {v0, v3, v5, v2, v6}, Landroid/view/View;->setPadding(IIII)V

    .line 33
    .line 34
    .line 35
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    invoke-virtual {v0, v2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    .line 43
    .line 44
    invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 45
    .line 46
    .line 47
    const/16 v3, 0x1e

    .line 48
    .line 49
    const/16 v5, 0x2e

    .line 50
    .line 51
    const/16 v6, 0xcc

    .line 52
    .line 53
    const/16 v7, 0x71

    .line 54
    .line 55
    invoke-static {v3, v5, v6, v7}, Landroid/graphics/Color;->argb(IIII)I

    .line 56
    .line 57
    .line 58
    move-result v3

    .line 59
    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 60
    .line 61
    .line 62
    const/4 v3, 0x7

    .line 63
    invoke-static {v3}, Lgringoxp/game/b;->s(I)I

    .line 64
    .line 65
    .line 66
    move-result v3

    .line 67
    int-to-float v3, v3

    .line 68
    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 69
    .line 70
    .line 71
    invoke-static {v1}, Lgringoxp/game/b;->s(I)I

    .line 72
    .line 73
    .line 74
    move-result v3

    .line 75
    const/16 v8, 0x64

    .line 76
    .line 77
    invoke-static {v8, v5, v6, v7}, Landroid/graphics/Color;->argb(IIII)I

    .line 78
    .line 79
    .line 80
    move-result v5

    .line 81
    invoke-virtual {v2, v3, v5}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 82
    .line 83
    .line 84
    invoke-virtual {v0, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 85
    .line 86
    .line 87
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 88
    .line 89
    const/4 v3, -0x1

    .line 90
    const/4 v5, -0x2

    .line 91
    invoke-direct {v2, v3, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 92
    .line 93
    .line 94
    const/4 v5, 0x6

    .line 95
    invoke-static {v5}, Lgringoxp/game/b;->s(I)I

    .line 96
    .line 97
    .line 98
    move-result v6

    .line 99
    const/4 v7, 0x3

    .line 100
    invoke-static {v7}, Lgringoxp/game/b;->s(I)I

    .line 101
    .line 102
    .line 103
    move-result v8

    .line 104
    invoke-static {v5}, Lgringoxp/game/b;->s(I)I

    .line 105
    .line 106
    .line 107
    move-result v5

    .line 108
    invoke-static {v7}, Lgringoxp/game/b;->s(I)I

    .line 109
    .line 110
    .line 111
    move-result v7

    .line 112
    invoke-virtual {v2, v6, v8, v5, v7}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 113
    .line 114
    .line 115
    invoke-virtual {v0, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 116
    .line 117
    .line 118
    new-instance v2, Landroid/widget/TextView;

    .line 119
    .line 120
    sget-object v5, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 121
    .line 122
    invoke-direct {v2, v5}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 126
    .line 127
    .line 128
    const/high16 v3, 0x41300000    # 11.0f

    .line 129
    .line 130
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextSize(F)V

    .line 131
    .line 132
    .line 133
    sget-object v3, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    .line 134
    .line 135
    invoke-virtual {v2, v3, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 136
    .line 137
    .line 138
    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 139
    .line 140
    .line 141
    new-instance v1, Lp/F3;

    .line 142
    .line 143
    const/4 v3, 0x4

    .line 144
    invoke-direct {v1, v3, p0}, Lp/F3;-><init>(ILjava/lang/Object;)V

    .line 145
    .line 146
    .line 147
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 148
    .line 149
    .line 150
    iget-object v1, p0, Lgringoxp/game/b;->b:Landroid/widget/LinearLayout;

    .line 151
    .line 152
    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 153
    .line 154
    .line 155
    if-eqz p2, :cond_0

    .line 156
    .line 157
    invoke-virtual {v0, v4}, Landroid/view/View;->setVisibility(I)V

    .line 158
    .line 159
    .line 160
    :cond_0
    new-instance p2, Lp/g5;

    .line 161
    .line 162
    invoke-direct {p2, v0, v2, p1}, Lp/g5;-><init>(Landroid/widget/LinearLayout;Landroid/widget/TextView;Ljava/lang/String;)V

    .line 163
    .line 164
    .line 165
    invoke-virtual {v0, p2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 166
    .line 167
    .line 168
    return-void
.end method

.method public final n(Ljava/lang/String;I)V
    .locals 8

    .line 1
    new-instance v6, Landroid/widget/LinearLayout;

    .line 2
    .line 3
    sget-object v0, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 4
    .line 5
    invoke-direct {v6, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 6
    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-virtual {v6, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 10
    .line 11
    .line 12
    const/16 v1, 0xa

    .line 13
    .line 14
    invoke-static {v1}, Lgringoxp/game/b;->s(I)I

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    const/16 v3, 0x8

    .line 19
    .line 20
    invoke-static {v3}, Lgringoxp/game/b;->s(I)I

    .line 21
    .line 22
    .line 23
    move-result v4

    .line 24
    invoke-static {v1}, Lgringoxp/game/b;->s(I)I

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    invoke-static {v3}, Lgringoxp/game/b;->s(I)I

    .line 29
    .line 30
    .line 31
    move-result v5

    .line 32
    invoke-virtual {v6, v2, v4, v1, v5}, Landroid/view/View;->setPadding(IIII)V

    .line 33
    .line 34
    .line 35
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    invoke-virtual {v6, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    .line 43
    .line 44
    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 45
    .line 46
    .line 47
    const/16 v2, 0x19

    .line 48
    .line 49
    const/16 v4, 0xff

    .line 50
    .line 51
    invoke-static {v2, v4, v4, v4}, Landroid/graphics/Color;->argb(IIII)I

    .line 52
    .line 53
    .line 54
    move-result v2

    .line 55
    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 56
    .line 57
    .line 58
    const/4 v2, 0x6

    .line 59
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 60
    .line 61
    .line 62
    move-result v5

    .line 63
    int-to-float v5, v5

    .line 64
    invoke-virtual {v1, v5}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 65
    .line 66
    .line 67
    invoke-static {v0}, Lgringoxp/game/b;->s(I)I

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    const/16 v5, 0x28

    .line 72
    .line 73
    invoke-static {v5, v4, v4, v4}, Landroid/graphics/Color;->argb(IIII)I

    .line 74
    .line 75
    .line 76
    move-result v4

    .line 77
    invoke-virtual {v1, v0, v4}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v6, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 81
    .line 82
    .line 83
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 84
    .line 85
    const/4 v1, -0x1

    .line 86
    const/4 v4, -0x2

    .line 87
    invoke-direct {v0, v1, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 88
    .line 89
    .line 90
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 91
    .line 92
    .line 93
    move-result v4

    .line 94
    const/4 v5, 0x2

    .line 95
    invoke-static {v5}, Lgringoxp/game/b;->s(I)I

    .line 96
    .line 97
    .line 98
    move-result v7

    .line 99
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 100
    .line 101
    .line 102
    move-result v2

    .line 103
    invoke-static {v5}, Lgringoxp/game/b;->s(I)I

    .line 104
    .line 105
    .line 106
    move-result v5

    .line 107
    invoke-virtual {v0, v4, v7, v2, v5}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {v6, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 111
    .line 112
    .line 113
    new-instance v4, Landroid/widget/TextView;

    .line 114
    .line 115
    sget-object v0, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 116
    .line 117
    invoke-direct {v4, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 118
    .line 119
    .line 120
    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 121
    .line 122
    .line 123
    const/high16 v0, 0x41280000    # 10.5f

    .line 124
    .line 125
    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setTextSize(F)V

    .line 126
    .line 127
    .line 128
    sget-object v0, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    .line 129
    .line 130
    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 131
    .line 132
    .line 133
    invoke-virtual {v6, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 134
    .line 135
    .line 136
    iget-object v0, p0, Lgringoxp/game/b;->b:Landroid/widget/LinearLayout;

    .line 137
    .line 138
    invoke-virtual {v0, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 139
    .line 140
    .line 141
    if-eqz p2, :cond_0

    .line 142
    .line 143
    invoke-virtual {v6, v3}, Landroid/view/View;->setVisibility(I)V

    .line 144
    .line 145
    .line 146
    :cond_0
    new-instance p2, Lp/h3;

    .line 147
    .line 148
    const/4 v5, 0x1

    .line 149
    move-object v0, p2

    .line 150
    move-object v1, p0

    .line 151
    move-object v2, v6

    .line 152
    move-object v3, v4

    .line 153
    move-object v4, p1

    .line 154
    invoke-direct/range {v0 .. v5}, Lp/h3;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 155
    .line 156
    .line 157
    invoke-virtual {v6, p2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 158
    .line 159
    .line 160
    return-void
.end method

.method public final o(Ljava/lang/String;II)V
    .locals 4

    .line 1
    iget-object v0, p0, Lgringoxp/game/b;->c:Lp/Ub;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Lp/Ub;

    .line 6
    .line 7
    sget-object v1, Lgringoxp/game/b;->e:Landroid/view/WindowManager;

    .line 8
    .line 9
    new-instance v2, Lp/Di;

    .line 10
    .line 11
    invoke-direct {v2, p0}, Lp/Di;-><init>(Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    sget v3, Lgringoxp/game/b;->h:I

    .line 15
    .line 16
    invoke-direct {v0, p0, v1, v2, v3}, Lp/Ub;-><init>(Lgringoxp/game/b;Landroid/view/WindowManager;Lp/Di;I)V

    .line 17
    .line 18
    .line 19
    iput-object v0, p0, Lgringoxp/game/b;->c:Lp/Ub;

    .line 20
    .line 21
    :cond_0
    iget-object v0, p0, Lgringoxp/game/b;->c:Lp/Ub;

    .line 22
    .line 23
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    new-instance v1, Lp/Pb;

    .line 27
    .line 28
    invoke-direct {v1, v0, p1, p2}, Lp/Pb;-><init>(Lp/Ub;Ljava/lang/String;I)V

    .line 29
    .line 30
    .line 31
    iget-object p1, v0, Lp/Ub;->f:Ljava/util/ArrayList;

    .line 32
    .line 33
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    iget-object p1, v1, Lp/Pb;->b:Ljava/lang/String;

    .line 37
    .line 38
    const-string p2, "_visible"

    .line 39
    .line 40
    invoke-virtual {p1, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    const/4 p2, 0x0

    .line 45
    iget-object v0, v0, Lp/Ub;->d:Landroid/content/SharedPreferences;

    .line 46
    .line 47
    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 48
    .line 49
    .line 50
    move-result p1

    .line 51
    if-eqz p1, :cond_1

    .line 52
    .line 53
    invoke-virtual {v1}, Lp/Pb;->f()V

    .line 54
    .line 55
    .line 56
    :cond_1
    invoke-virtual {v1}, Lp/Pb;->d()V

    .line 57
    .line 58
    .line 59
    iget-object p1, v1, Lp/Pb;->f:Landroid/widget/LinearLayout;

    .line 60
    .line 61
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 62
    .line 63
    .line 64
    move-result-object p2

    .line 65
    invoke-virtual {p1, p2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 66
    .line 67
    .line 68
    iget-object p2, p0, Lgringoxp/game/b;->b:Landroid/widget/LinearLayout;

    .line 69
    .line 70
    invoke-virtual {p2, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 71
    .line 72
    .line 73
    if-eqz p3, :cond_2

    .line 74
    .line 75
    const/16 p2, 0x8

    .line 76
    .line 77
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    .line 78
    .line 79
    .line 80
    :cond_2
    return-void
.end method

.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public final onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, Landroid/app/Service;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, Lgringoxp/game/b;->c:Lp/Ub;

    .line 5
    .line 6
    if-eqz p1, :cond_2

    .line 7
    .line 8
    iget-boolean v0, p1, Lp/Ub;->g:Z

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    goto :goto_1

    .line 13
    :cond_0
    iget-object p1, p1, Lp/Ub;->f:Ljava/util/ArrayList;

    .line 14
    .line 15
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    :cond_1
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_2

    .line 24
    .line 25
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    check-cast v0, Lp/Pb;

    .line 30
    .line 31
    iget-boolean v1, v0, Lp/Pb;->u:Z

    .line 32
    .line 33
    if-eqz v1, :cond_1

    .line 34
    .line 35
    invoke-virtual {v0}, Lp/Pb;->c()V

    .line 36
    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_2
    :goto_1
    return-void
.end method

.method public final onCreate()V
    .locals 4

    .line 1
    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lgringoxp/game/b;->startTelemetryReceiver()V

    .line 5
    .line 6
    .line 7
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 8
    .line 9
    const/16 v1, 0x1a

    .line 10
    .line 11
    if-lt v0, v1, :cond_0

    .line 12
    .line 13
    invoke-static {}, Lp/s;->s()Landroid/app/NotificationChannel;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    invoke-static {v2}, Lp/s;->t(Landroid/app/NotificationChannel;)V

    .line 18
    .line 19
    .line 20
    const-string v3, "notification"

    .line 21
    .line 22
    invoke-virtual {p0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    check-cast v3, Landroid/app/NotificationManager;

    .line 27
    .line 28
    invoke-static {v3, v2}, Lp/s;->i(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    .line 29
    .line 30
    .line 31
    :cond_0
    if-lt v0, v1, :cond_1

    .line 32
    .line 33
    invoke-static {p0}, Lp/s;->c(Lgringoxp/game/b;)Landroid/app/Notification$Builder;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    goto :goto_0

    .line 38
    :cond_1
    new-instance v1, Landroid/app/Notification$Builder;

    .line 39
    .line 40
    invoke-direct {v1, p0}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    .line 41
    .line 42
    .line 43
    :goto_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 44
    .line 45
    .line 46
    move-result-object v2

    .line 47
    iget v2, v2, Landroid/content/pm/ApplicationInfo;->icon:I

    .line 48
    .line 49
    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    const-string v2, "Overlay ativo"

    .line 54
    .line 55
    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    const-string v2, "Controle flutuante em execu\u00e7\u00e3o"

    .line 60
    .line 61
    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    const-string v2, "service"

    .line 66
    .line 67
    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setCategory(Ljava/lang/String;)Landroid/app/Notification$Builder;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    const/4 v2, 0x1

    .line 72
    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    invoke-virtual {v1}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    const/16 v2, 0x22

    .line 81
    .line 82
    if-lt v0, v2, :cond_2

    .line 83
    .line 84
    invoke-static {p0, v1}, Lp/gi;->g(Lgringoxp/game/b;Landroid/app/Notification;)V

    .line 85
    .line 86
    .line 87
    goto :goto_1

    .line 88
    :cond_2
    const/16 v0, 0xc1d

    .line 89
    .line 90
    invoke-virtual {p0, v0, v1}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    .line 91
    .line 92
    .line 93
    :goto_1
    :try_start_0
    invoke-virtual {p0, p0}, Lgringoxp/game/b;->t(Lgringoxp/game/b;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 94
    .line 95
    .line 96
    :catch_0
    return-void
.end method

.method public final onDestroy()V
    .locals 3

    .line 1
    iget-object v0, p0, Lgringoxp/game/b;->c:Lp/Ub;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Lp/Ub;->close()V

    .line 6
    .line 7
    .line 8
    :cond_0
    new-instance v0, Landroid/content/Intent;

    .line 9
    .line 10
    const-string v1, "gringoxp.game.ACTION_STOP_OVERLAY"

    .line 11
    .line 12
    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-static {p0}, Lp/H9;->f(Landroid/app/Service;)Lp/H9;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-virtual {v1, v0}, Lp/H9;->k(Landroid/content/Intent;)V

    .line 20
    .line 21
    .line 22
    new-instance v0, Landroid/content/Intent;

    .line 23
    .line 24
    const-class v1, Lgringoxp/game/EspDraw;

    .line 25
    .line 26
    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p0, v0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 30
    .line 31
    .line 32
    :try_start_0
    invoke-direct {p0}, Lgringoxp/game/b;->stopTelemetryReceiver()V
    :try_end_0
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_0} :catch_0

    .line 33
    .line 34
    .line 35
    :catch_0
    const/4 v0, 0x0

    .line 36
    :try_start_1
    sget-object v1, Lgringoxp/game/b;->e:Landroid/view/WindowManager;

    .line 37
    .line 38
    if-eqz v1, :cond_1

    .line 39
    .line 40
    sget-object v2, Lgringoxp/game/b;->g:Landroid/widget/LinearLayout;

    .line 41
    .line 42
    if-eqz v2, :cond_1

    .line 43
    .line 44
    invoke-interface {v1, v2}, Landroid/view/WindowManager;->removeViewImmediate(Landroid/view/View;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 45
    .line 46
    .line 47
    goto :goto_0

    .line 48
    :catchall_0
    move-exception v1

    .line 49
    goto :goto_1

    .line 50
    :catch_1
    :cond_1
    :goto_0
    sput-object v0, Lgringoxp/game/b;->f:Landroid/widget/FrameLayout;

    .line 51
    .line 52
    sput-object v0, Lgringoxp/game/b;->g:Landroid/widget/LinearLayout;

    .line 53
    .line 54
    sput-object v0, Lgringoxp/game/b;->e:Landroid/view/WindowManager;

    .line 55
    .line 56
    goto :goto_2

    .line 57
    :goto_1
    sput-object v0, Lgringoxp/game/b;->f:Landroid/widget/FrameLayout;

    .line 58
    .line 59
    sput-object v0, Lgringoxp/game/b;->g:Landroid/widget/LinearLayout;

    .line 60
    .line 61
    sput-object v0, Lgringoxp/game/b;->e:Landroid/view/WindowManager;

    .line 62
    .line 63
    throw v1

    .line 64
    :goto_2
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    .line 65
    .line 66
    .line 67
    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .locals 0

    const/4 p1, 0x2

    return p1
.end method

.method public final onTaskRemoved(Landroid/content/Intent;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lgringoxp/game/b;->c:Lp/Ub;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Lp/Ub;->close()V

    .line 6
    .line 7
    .line 8
    :cond_0
    new-instance v0, Landroid/content/Intent;

    .line 9
    .line 10
    const-string v1, "gringoxp.game.ACTION_STOP_OVERLAY"

    .line 11
    .line 12
    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-static {p0}, Lp/H9;->f(Landroid/app/Service;)Lp/H9;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-virtual {v1, v0}, Lp/H9;->k(Landroid/content/Intent;)V

    .line 20
    .line 21
    .line 22
    new-instance v0, Landroid/content/Intent;

    .line 23
    .line 24
    const-class v1, Lgringoxp/game/EspDraw;

    .line 25
    .line 26
    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p0, v0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 30
    .line 31
    .line 32
    :try_start_0
    invoke-direct {p0}, Lgringoxp/game/b;->stopTelemetryReceiver()V
    :try_end_0
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_0} :catch_0

    .line 33
    .line 34
    .line 35
    :catch_0
    const/4 v0, 0x1

    .line 36
    invoke-virtual {p0, v0}, Landroid/app/Service;->stopForeground(I)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    .line 40
    .line 41
    .line 42
    new-instance v0, Landroid/content/Intent;

    .line 43
    .line 44
    const-class v1, Lio/gringoxp/proxy/garena/freefire/FlowVpnService;

    .line 45
    .line 46
    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {p0, v0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 50
    .line 51
    .line 52
    invoke-super {p0, p1}, Landroid/app/Service;->onTaskRemoved(Landroid/content/Intent;)V

    .line 53
    .line 54
    .line 55
    return-void
.end method

.method public final p(Ljava/lang/String;IZ)V
    .locals 8

    .line 1
    new-instance v6, Landroid/widget/LinearLayout;

    .line 2
    .line 3
    sget-object v0, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 4
    .line 5
    invoke-direct {v6, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 6
    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-virtual {v6, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 10
    .line 11
    .line 12
    const/16 v1, 0xa

    .line 13
    .line 14
    invoke-static {v1}, Lgringoxp/game/b;->s(I)I

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    const/16 v3, 0x8

    .line 19
    .line 20
    invoke-static {v3}, Lgringoxp/game/b;->s(I)I

    .line 21
    .line 22
    .line 23
    move-result v4

    .line 24
    invoke-static {v1}, Lgringoxp/game/b;->s(I)I

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    invoke-static {v3}, Lgringoxp/game/b;->s(I)I

    .line 29
    .line 30
    .line 31
    move-result v5

    .line 32
    invoke-virtual {v6, v2, v4, v1, v5}, Landroid/view/View;->setPadding(IIII)V

    .line 33
    .line 34
    .line 35
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    invoke-virtual {v6, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    .line 43
    .line 44
    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 45
    .line 46
    .line 47
    const/16 v2, 0x19

    .line 48
    .line 49
    const/16 v4, 0xff

    .line 50
    .line 51
    invoke-static {v2, v4, v4, v4}, Landroid/graphics/Color;->argb(IIII)I

    .line 52
    .line 53
    .line 54
    move-result v2

    .line 55
    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 56
    .line 57
    .line 58
    const/4 v2, 0x6

    .line 59
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 60
    .line 61
    .line 62
    move-result v5

    .line 63
    int-to-float v5, v5

    .line 64
    invoke-virtual {v1, v5}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 65
    .line 66
    .line 67
    invoke-static {v0}, Lgringoxp/game/b;->s(I)I

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    const/16 v5, 0x28

    .line 72
    .line 73
    invoke-static {v5, v4, v4, v4}, Landroid/graphics/Color;->argb(IIII)I

    .line 74
    .line 75
    .line 76
    move-result v4

    .line 77
    invoke-virtual {v1, v0, v4}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v6, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 81
    .line 82
    .line 83
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 84
    .line 85
    const/4 v1, -0x1

    .line 86
    const/4 v4, -0x2

    .line 87
    invoke-direct {v0, v1, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 88
    .line 89
    .line 90
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 91
    .line 92
    .line 93
    move-result v4

    .line 94
    const/4 v5, 0x2

    .line 95
    invoke-static {v5}, Lgringoxp/game/b;->s(I)I

    .line 96
    .line 97
    .line 98
    move-result v7

    .line 99
    invoke-static {v2}, Lgringoxp/game/b;->s(I)I

    .line 100
    .line 101
    .line 102
    move-result v2

    .line 103
    invoke-static {v5}, Lgringoxp/game/b;->s(I)I

    .line 104
    .line 105
    .line 106
    move-result v5

    .line 107
    invoke-virtual {v0, v4, v7, v2, v5}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {v6, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 111
    .line 112
    .line 113
    new-instance v4, Landroid/widget/TextView;

    .line 114
    .line 115
    sget-object v0, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 116
    .line 117
    invoke-direct {v4, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 118
    .line 119
    .line 120
    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 121
    .line 122
    .line 123
    const/high16 v0, 0x41280000    # 10.5f

    .line 124
    .line 125
    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setTextSize(F)V

    .line 126
    .line 127
    .line 128
    sget-object v0, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    .line 129
    .line 130
    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 131
    .line 132
    .line 133
    invoke-virtual {v6, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 134
    .line 135
    .line 136
    iget-object v0, p0, Lgringoxp/game/b;->b:Landroid/widget/LinearLayout;

    .line 137
    .line 138
    invoke-virtual {v0, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 139
    .line 140
    .line 141
    if-eqz p2, :cond_0

    .line 142
    .line 143
    invoke-virtual {v6, v3}, Landroid/view/View;->setVisibility(I)V

    .line 144
    .line 145
    .line 146
    :cond_0
    new-instance p2, Lp/Hi;

    .line 147
    .line 148
    move-object v0, p2

    .line 149
    move-object v1, p0

    .line 150
    move-object v2, v6

    .line 151
    move v3, p3

    .line 152
    move-object v5, p1

    .line 153
    invoke-direct/range {v0 .. v5}, Lp/Hi;-><init>(Lgringoxp/game/b;Landroid/widget/LinearLayout;ZLandroid/widget/TextView;Ljava/lang/String;)V

    .line 154
    .line 155
    .line 156
    invoke-virtual {v6, p2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 157
    .line 158
    .line 159
    return-void
.end method

.method public final q(Lgringoxp/game/b;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/FrameLayout;Landroid/widget/LinearLayout;)V
    .locals 3

    .line 1
    new-instance v0, Landroid/widget/TextView;

    .line 2
    .line 3
    invoke-direct {v0, p1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 4
    .line 5
    .line 6
    const-string v1, "PROXY GRINGO XP | CUBAN"

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 9
    .line 10
    .line 11
    const/4 v1, -0x1

    .line 12
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 13
    .line 14
    .line 15
    const/high16 v1, 0x41300000    # 11.0f

    .line 16
    .line 17
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextSize(F)V

    .line 18
    .line 19
    .line 20
    const/16 v1, 0x11

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setGravity(I)V

    .line 23
    .line 24
    .line 25
    sget-object v1, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    .line 26
    .line 27
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 28
    .line 29
    .line 30
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 31
    .line 32
    const/4 v2, -0x2

    .line 33
    invoke-direct {v1, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 34
    .line 35
    .line 36
    const/16 v2, 0xc

    .line 37
    .line 38
    invoke-virtual {v1, v2, v2, v2, v2}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {p3, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {p0, p1}, Lgringoxp/game/b;->setupMenu(Landroid/content/Context;)V

    .line 48
    .line 49
    .line 50
    const/4 p1, 0x0

    .line 51
    invoke-virtual {p4, p1, p1}, Landroid/view/View;->measure(II)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {p4}, Landroid/view/View;->getMeasuredWidth()I

    .line 55
    .line 56
    .line 57
    move-result p1

    .line 58
    if-gtz p1, :cond_0

    .line 59
    .line 60
    const/16 p1, 0xf0

    .line 61
    .line 62
    invoke-static {p1}, Lgringoxp/game/b;->s(I)I

    .line 63
    .line 64
    .line 65
    move-result p1

    .line 66
    :cond_0
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 67
    .line 68
    const/4 v1, 0x3

    .line 69
    invoke-static {v1}, Lgringoxp/game/b;->s(I)I

    .line 70
    .line 71
    .line 72
    move-result v1

    .line 73
    invoke-direct {v0, p1, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {p5, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 77
    .line 78
    .line 79
    invoke-virtual {p2, p5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {p2, p3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {p2, p4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 86
    .line 87
    .line 88
    const/16 p1, 0x0

    .line 89
    .line 90
    invoke-virtual {p4, p1}, Landroid/view/View;->setVisibility(I)V

    .line 91
    .line 92
    .line 93
    return-void
.end method

.method public final setupMenu(Landroid/content/Context;)V
    .locals 16

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    :try_start_0
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    .line 7
    .line 8
    .line 9
    move-result-object v3

    .line 10
    const-string v4, "fa-solid-900.ttf"

    .line 11
    .line 12
    invoke-static {v3, v4}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    .line 13
    .line 14
    .line 15
    move-result-object v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 16
    goto :goto_0

    .line 17
    :catch_0
    const/4 v3, 0x0

    .line 18
    :goto_0
    :try_start_1
    new-instance v4, Landroid/graphics/drawable/GradientDrawable;

    .line 19
    .line 20
    invoke-direct {v4}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 21
    .line 22
    .line 23
    const/16 v5, 0xdc

    .line 24
    .line 25
    const/16 v6, 0x28

    .line 26
    .line 27
    invoke-static {v5, v6, v6, v6}, Landroid/graphics/Color;->argb(IIII)I

    .line 28
    .line 29
    .line 30
    move-result v5

    .line 31
    invoke-virtual {v4, v5}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 32
    .line 33
    .line 34
    const/16 v5, 0x8

    .line 35
    .line 36
    new-array v5, v5, [F

    .line 37
    .line 38
    fill-array-data v5, :array_0

    .line 39
    .line 40
    .line 41
    invoke-virtual {v4, v5}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 42
    .line 43
    .line 44
    new-instance v5, Landroid/graphics/drawable/GradientDrawable;

    .line 45
    .line 46
    invoke-direct {v5}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 47
    .line 48
    .line 49
    const/16 v7, 0x1e

    .line 50
    .line 51
    const/16 v8, 0xff

    .line 52
    .line 53
    invoke-static {v7, v8, v8, v8}, Landroid/graphics/Color;->argb(IIII)I

    .line 54
    .line 55
    .line 56
    move-result v7

    .line 57
    invoke-virtual {v5, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 58
    .line 59
    .line 60
    const/4 v7, 0x5

    .line 61
    invoke-static {v7}, Lgringoxp/game/b;->s(I)I

    .line 62
    .line 63
    .line 64
    move-result v8

    .line 65
    int-to-float v8, v8

    .line 66
    invoke-virtual {v5, v8}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 67
    .line 68
    .line 69
    new-instance v8, Landroid/widget/LinearLayout;

    .line 70
    .line 71
    invoke-direct {v8, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 72
    .line 73
    .line 74
    iput-object v8, v1, Lgringoxp/game/b;->a:Landroid/widget/LinearLayout;

    .line 75
    .line 76
    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    .line 77
    .line 78
    const/16 v10, 0xf0

    .line 79
    .line 80
    invoke-static {v10}, Lgringoxp/game/b;->s(I)I

    .line 81
    .line 82
    .line 83
    move-result v10

    .line 84
    const/4 v11, -0x2

    .line 85
    invoke-direct {v9, v10, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {v8, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 89
    .line 90
    .line 91
    iget-object v8, v1, Lgringoxp/game/b;->a:Landroid/widget/LinearLayout;

    .line 92
    .line 93
    invoke-virtual {v8, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 94
    .line 95
    .line 96
    new-instance v8, Landroid/widget/LinearLayout;

    .line 97
    .line 98
    invoke-direct {v8, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 99
    .line 100
    .line 101
    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    .line 102
    .line 103
    const/4 v10, -0x1

    .line 104
    invoke-direct {v9, v10, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 105
    .line 106
    .line 107
    invoke-virtual {v8, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {v8, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 111
    .line 112
    .line 113
    const/4 v4, 0x0

    .line 114
    invoke-virtual {v8, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 115
    .line 116
    .line 117
    invoke-static {v7}, Lgringoxp/game/b;->s(I)I

    .line 118
    .line 119
    .line 120
    move-result v9

    .line 121
    invoke-static {v7}, Lgringoxp/game/b;->s(I)I

    .line 122
    .line 123
    .line 124
    move-result v12

    .line 125
    invoke-static {v7}, Lgringoxp/game/b;->s(I)I

    .line 126
    .line 127
    .line 128
    move-result v13

    .line 129
    invoke-static {v7}, Lgringoxp/game/b;->s(I)I

    .line 130
    .line 131
    .line 132
    move-result v14

    .line 133
    invoke-virtual {v8, v9, v12, v13, v14}, Landroid/view/View;->setPadding(IIII)V

    .line 134
    .line 135
    .line 136
    new-instance v9, Landroid/widget/LinearLayout;

    .line 137
    .line 138
    invoke-direct {v9, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 139
    .line 140
    .line 141
    invoke-virtual {v9, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 142
    .line 143
    .line 144
    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    .line 145
    .line 146
    invoke-static {v6}, Lgringoxp/game/b;->s(I)I

    .line 147
    .line 148
    .line 149
    move-result v6

    .line 150
    invoke-direct {v12, v6, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 151
    .line 152
    .line 153
    invoke-virtual {v9, v12}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 154
    .line 155
    .line 156
    invoke-virtual {v9, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 157
    .line 158
    .line 159
    new-instance v6, Lp/F2;

    .line 160
    .line 161
    invoke-direct {v6, v2}, Lp/F2;-><init>(I)V

    .line 162
    .line 163
    .line 164
    invoke-virtual {v9, v6}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 165
    .line 166
    .line 167
    const-string v6, "\uf11b"

    .line 168
    .line 169
    const-string v11, "\uf06e"

    .line 170
    .line 171
    const-string v12, "\uf013"

    .line 172
    .line 173
    const-string v13, "\uf007"

    .line 174
    .line 175
    filled-new-array {v6, v11, v12, v13}, [Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object v6

    .line 179
    const-string v11, "FUNCOES"

    .line 180
    .line 181
    const-string v12, "ESP"

    .line 182
    .line 183
    const-string v13, "AJUSTES"

    .line 184
    .line 185
    const-string v14, "LOGIN"

    .line 186
    .line 187
    filled-new-array {v11, v12, v13, v14}, [Ljava/lang/String;

    .line 188
    .line 189
    .line 190
    move-result-object v11

    .line 191
    move v12, v4

    .line 192
    :goto_1
    const/4 v13, 0x4

    .line 193
    if-ge v12, v13, :cond_1

    .line 194
    .line 195
    aget-object v14, v11, v12

    .line 196
    .line 197
    new-instance v15, Landroid/widget/TextView;

    .line 198
    .line 199
    invoke-direct {v15, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 200
    .line 201
    .line 202
    aget-object v7, v6, v12

    .line 203
    .line 204
    invoke-virtual {v15, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 205
    .line 206
    .line 207
    invoke-virtual {v15, v14}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 208
    .line 209
    .line 210
    invoke-virtual {v15, v10}, Landroid/widget/TextView;->setTextColor(I)V

    .line 211
    .line 212
    .line 213
    const/high16 v7, 0x41900000    # 18.0f

    .line 214
    .line 215
    invoke-virtual {v15, v7}, Landroid/widget/TextView;->setTextSize(F)V

    .line 216
    .line 217
    .line 218
    const/16 v7, 0x11

    .line 219
    .line 220
    invoke-virtual {v15, v7}, Landroid/widget/TextView;->setGravity(I)V

    .line 221
    .line 222
    .line 223
    invoke-virtual {v15, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 224
    .line 225
    .line 226
    if-eqz v3, :cond_0

    .line 227
    .line 228
    invoke-virtual {v15, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 229
    .line 230
    .line 231
    goto :goto_2

    .line 232
    :catch_1
    move-exception v0

    .line 233
    goto/16 :goto_3

    .line 234
    .line 235
    :cond_0
    :goto_2
    new-instance v7, Lp/Gi;

    .line 236
    .line 237
    invoke-direct {v7, v1, v12}, Lp/Gi;-><init>(Lgringoxp/game/b;I)V

    .line 238
    .line 239
    .line 240
    invoke-virtual {v15, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 241
    .line 242
    .line 243
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    .line 244
    .line 245
    const/16 v14, 0x20

    .line 246
    .line 247
    invoke-static {v14}, Lgringoxp/game/b;->s(I)I

    .line 248
    .line 249
    .line 250
    move-result v10

    .line 251
    invoke-static {v14}, Lgringoxp/game/b;->s(I)I

    .line 252
    .line 253
    .line 254
    move-result v14

    .line 255
    invoke-direct {v7, v10, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 256
    .line 257
    .line 258
    invoke-static {v13}, Lgringoxp/game/b;->s(I)I

    .line 259
    .line 260
    .line 261
    move-result v10

    .line 262
    invoke-static {v13}, Lgringoxp/game/b;->s(I)I

    .line 263
    .line 264
    .line 265
    move-result v13

    .line 266
    invoke-virtual {v7, v4, v10, v4, v13}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 267
    .line 268
    .line 269
    invoke-virtual {v15, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 270
    .line 271
    .line 272
    invoke-virtual {v9, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 273
    .line 274
    .line 275
    add-int/2addr v12, v2

    .line 276
    const/4 v7, 0x5

    .line 277
    const/4 v10, -0x1

    .line 278
    goto :goto_1

    .line 279
    :cond_1
    new-instance v3, Landroid/widget/ScrollView;

    .line 280
    .line 281
    invoke-direct {v3, v0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 282
    .line 283
    .line 284
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    .line 285
    .line 286
    const/16 v6, 0xa0

    .line 287
    .line 288
    invoke-static {v6}, Lgringoxp/game/b;->s(I)I

    .line 289
    .line 290
    .line 291
    move-result v6

    .line 292
    const/4 v7, -0x1

    .line 293
    invoke-direct {v5, v7, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 294
    .line 295
    .line 296
    const/4 v6, 0x5

    .line 297
    invoke-static {v6}, Lgringoxp/game/b;->s(I)I

    .line 298
    .line 299
    .line 300
    move-result v6

    .line 301
    invoke-virtual {v5, v6, v4, v4, v4}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 302
    .line 303
    .line 304
    invoke-virtual {v3, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 305
    .line 306
    .line 307
    new-instance v4, Landroid/widget/LinearLayout;

    .line 308
    .line 309
    invoke-direct {v4, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 310
    .line 311
    .line 312
    iput-object v4, v1, Lgringoxp/game/b;->b:Landroid/widget/LinearLayout;

    .line 313
    .line 314
    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 315
    .line 316
    .line 317
    iget-object v0, v1, Lgringoxp/game/b;->b:Landroid/widget/LinearLayout;

    .line 318
    .line 319
    invoke-virtual {v3, v0}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 320
    .line 321
    .line 322
    invoke-virtual {v8, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 323
    .line 324
    .line 325
    invoke-virtual {v8, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 326
    .line 327
    .line 328
    new-instance v0, Landroid/os/Handler;

    .line 329
    .line 330
    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    .line 331
    .line 332
    .line 333
    new-instance v2, Lp/i0;

    .line 334
    .line 335
    const/16 v3, 0xf

    .line 336
    .line 337
    invoke-direct {v2, v3, v1}, Lp/i0;-><init>(ILjava/lang/Object;)V

    .line 338
    .line 339
    .line 340
    const-wide/16 v3, 0x3e8

    .line 341
    .line 342
    invoke-virtual {v0, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 343
    .line 344
    .line 345
    iget-object v0, v1, Lgringoxp/game/b;->a:Landroid/widget/LinearLayout;

    .line 346
    .line 347
    invoke-virtual {v0, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 348
    .line 349
    .line 350
    sget-object v0, Lgringoxp/game/b;->f:Landroid/widget/FrameLayout;

    .line 351
    .line 352
    iget-object v2, v1, Lgringoxp/game/b;->a:Landroid/widget/LinearLayout;

    .line 353
    .line 354
    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 355
    .line 356
    .line 357
    goto :goto_4

    .line 358
    :goto_3
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 359
    .line 360
    .line 361
    :goto_4
    return-void

    .line 362
    nop

    .line 363
    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x41a00000    # 20.0f
        0x41a00000    # 20.0f
        0x41a00000    # 20.0f
        0x41a00000    # 20.0f
    .end array-data
.end method

.method public final t(Lgringoxp/game/b;)V
    .locals 11

    .line 1
    const/16 v0, 0x8

    .line 2
    .line 3
    :try_start_0
    sput-object p1, Lgringoxp/game/b;->d:Lgringoxp/game/b;

    .line 4
    .line 5
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    .line 6
    .line 7
    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 8
    .line 9
    .line 10
    sget v2, Lgringoxp/game/b;->h:I

    .line 11
    .line 12
    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 13
    .line 14
    .line 15
    new-array v2, v0, [F

    .line 16
    .line 17
    fill-array-data v2, :array_0

    .line 18
    .line 19
    .line 20
    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 21
    .line 22
    .line 23
    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    .line 24
    .line 25
    invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 26
    .line 27
    .line 28
    const/16 v3, 0xdc

    .line 29
    .line 30
    const/16 v4, 0x28

    .line 31
    .line 32
    invoke-static {v3, v4, v4, v4}, Landroid/graphics/Color;->argb(IIII)I

    .line 33
    .line 34
    .line 35
    move-result v3

    .line 36
    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 37
    .line 38
    .line 39
    new-array v0, v0, [F

    .line 40
    .line 41
    fill-array-data v0, :array_1

    .line 42
    .line 43
    .line 44
    invoke-virtual {v2, v0}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 45
    .line 46
    .line 47
    new-instance v0, Landroid/widget/LinearLayout;

    .line 48
    .line 49
    invoke-direct {v0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 50
    .line 51
    .line 52
    sput-object v0, Lgringoxp/game/b;->g:Landroid/widget/LinearLayout;

    .line 53
    .line 54
    const/16 v3, 0x11

    .line 55
    .line 56
    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 57
    .line 58
    .line 59
    sget-object v0, Lgringoxp/game/b;->g:Landroid/widget/LinearLayout;

    .line 60
    .line 61
    const/4 v4, 0x1

    .line 62
    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 63
    .line 64
    .line 65
    new-instance v0, Landroid/widget/LinearLayout;

    .line 66
    .line 67
    invoke-direct {v0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 71
    .line 72
    .line 73
    const/4 v4, 0x0

    .line 74
    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {v0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 78
    .line 79
    .line 80
    new-instance v1, Landroid/widget/LinearLayout;

    .line 81
    .line 82
    invoke-direct {v1, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 92
    .line 93
    .line 94
    new-instance v3, Landroid/widget/FrameLayout;

    .line 95
    .line 96
    invoke-direct {v3, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 97
    .line 98
    .line 99
    sput-object v3, Lgringoxp/game/b;->f:Landroid/widget/FrameLayout;

    .line 100
    .line 101
    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    .line 102
    .line 103
    const/4 v6, -0x2

    .line 104
    invoke-direct {v5, v6, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 105
    .line 106
    .line 107
    invoke-virtual {v3, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 108
    .line 109
    .line 110
    :try_start_1
    new-instance v5, Ljava/lang/UnsatisfiedLinkError;

    invoke-direct {v5}, Ljava/lang/UnsatisfiedLinkError;-><init>()V

    throw v5
    :try_end_1
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 119
    .line 120
    .line 121
    goto :goto_0

    .line 122
    :catch_0
    move-exception p1

    .line 123
    goto :goto_3

    .line 124
    :catch_1
    :try_start_2
    sget-object v7, Lgringoxp/game/b;->g:Landroid/widget/LinearLayout;

    .line 125
    .line 126
    sget-object v9, Lgringoxp/game/b;->f:Landroid/widget/FrameLayout;

    .line 127
    .line 128
    move-object v5, p0

    .line 129
    move-object v6, p1

    .line 130
    move-object v8, v1

    .line 131
    move-object v10, v0

    .line 132
    invoke-virtual/range {v5 .. v10}, Lgringoxp/game/b;->q(Lgringoxp/game/b;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/FrameLayout;Landroid/widget/LinearLayout;)V

    .line 133
    .line 134
    .line 135
    :goto_0
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    const-string v0, "window"

    .line 140
    .line 141
    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object p1

    .line 145
    check-cast p1, Landroid/view/WindowManager;

    .line 146
    .line 147
    sput-object p1, Lgringoxp/game/b;->e:Landroid/view/WindowManager;

    .line 148
    .line 149
    new-instance p1, Landroid/content/Intent;

    .line 150
    .line 151
    const-class v0, Lgringoxp/game/EspDraw;

    .line 152
    .line 153
    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 154
    .line 155
    .line 156
    invoke-virtual {p0, p1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 157
    .line 158
    .line 159
    new-instance p1, Landroid/content/Intent;

    .line 160
    .line 161
    const-string v0, "gringoxp.game.ACTION_START_OVERLAY"

    .line 162
    .line 163
    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    invoke-static {p0}, Lp/H9;->f(Landroid/app/Service;)Lp/H9;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    invoke-virtual {v0, p1}, Lp/H9;->k(Landroid/content/Intent;)V

    .line 171
    .line 172
    .line 173
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 174
    .line 175
    const/16 v0, 0x1a

    .line 176
    .line 177
    if-lt p1, v0, :cond_0

    .line 178
    .line 179
    const/16 p1, 0x7f6

    .line 180
    .line 181
    :goto_1
    move v8, p1

    .line 182
    goto :goto_2

    .line 183
    :cond_0
    const/16 p1, 0x7d2

    .line 184
    .line 185
    goto :goto_1

    .line 186
    :goto_2
    new-instance p1, Landroid/view/WindowManager$LayoutParams;

    .line 187
    .line 188
    const/4 v6, -0x2

    .line 189
    const/4 v7, -0x2

    .line 190
    const/16 v9, 0x108

    .line 191
    .line 192
    const/4 v10, -0x3

    .line 193
    move-object v5, p1

    .line 194
    invoke-direct/range {v5 .. v10}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    .line 195
    .line 196
    .line 197
    const/16 v0, 0x31

    .line 198
    .line 199
    iput v0, p1, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 200
    .line 201
    iput v4, p1, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 202
    .line 203
    const/16 v0, 0x46

    .line 204
    .line 205
    iput v0, p1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 206
    .line 207
    sget-object v0, Lgringoxp/game/b;->e:Landroid/view/WindowManager;

    .line 208
    .line 209
    sget-object v1, Lgringoxp/game/b;->g:Landroid/widget/LinearLayout;

    .line 210
    .line 211
    invoke-interface {v0, v1, p1}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 212
    .line 213
    .line 214
    sget-object v0, Lgringoxp/game/b;->g:Landroid/widget/LinearLayout;

    .line 215
    .line 216
    new-instance v1, Lp/Ob;

    .line 217
    .line 218
    invoke-direct {v1, p1, v2}, Lp/Ob;-><init>(Landroid/view/WindowManager$LayoutParams;Landroid/graphics/drawable/GradientDrawable;)V

    .line 219
    .line 220
    .line 221
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 222
    .line 223
    .line 224
    goto :goto_4

    .line 225
    :goto_3
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 226
    .line 227
    .line 228
    :goto_4
    return-void

    nop

    .line 229
    :array_0
    .array-data 4
        0x41a00000    # 20.0f
        0x41a00000    # 20.0f
        0x41a00000    # 20.0f
        0x41a00000    # 20.0f
        0x0
        0x0
        0x0
        0x0
    .end array-data

    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    :array_1
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x41200000    # 10.0f
        0x41200000    # 10.0f
        0x41200000    # 10.0f
        0x41200000    # 10.0f
    .end array-data
.end method
