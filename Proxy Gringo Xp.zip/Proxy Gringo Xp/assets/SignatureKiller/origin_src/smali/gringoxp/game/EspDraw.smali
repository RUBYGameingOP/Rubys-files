.class public Lgringoxp/game/EspDraw;
.super Landroid/app/Service;
.source "SourceFile"


# static fields
.field public static final synthetic d:I


# instance fields
.field public a:Landroid/view/WindowManager;

.field public b:Lgringoxp/game/ESPView;

.field public final c:Lp/g1;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lp/g1;

    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    invoke-direct {v0, v1, p0}, Lp/g1;-><init>(ILjava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lgringoxp/game/EspDraw;->c:Lp/g1;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 8

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    return-void

    .line 10
    :cond_0
    const/16 v1, 0x1a

    .line 11
    .line 12
    if-lt v0, v1, :cond_1

    .line 13
    .line 14
    const/16 v1, 0x7f6

    .line 15
    .line 16
    :goto_0
    move v5, v1

    .line 17
    goto :goto_1

    .line 18
    :cond_1
    const/16 v1, 0x7d2

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :goto_1
    new-instance v1, Landroid/view/WindowManager$LayoutParams;

    .line 22
    .line 23
    const/4 v3, -0x1

    .line 24
    const/4 v4, -0x1

    .line 25
    const v6, 0x1000318

    .line 26
    .line 27
    .line 28
    const/4 v7, -0x3

    .line 29
    move-object v2, v1

    .line 30
    invoke-direct/range {v2 .. v7}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    .line 31
    .line 32
    .line 33
    const/16 v2, 0x1c

    .line 34
    .line 35
    if-lt v0, v2, :cond_2

    .line 36
    .line 37
    invoke-static {v1}, Lp/r;->p(Landroid/view/WindowManager$LayoutParams;)V

    .line 38
    .line 39
    .line 40
    :cond_2
    const/high16 v0, 0x3f800000    # 1.0f

    .line 41
    .line 42
    iput v0, v1, Landroid/view/WindowManager$LayoutParams;->alpha:F

    .line 43
    .line 44
    const v0, 0x800033

    .line 45
    .line 46
    .line 47
    iput v0, v1, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 48
    .line 49
    new-instance v0, Lgringoxp/game/ESPView;

    .line 50
    .line 51
    invoke-direct {v0, p0}, Lgringoxp/game/ESPView;-><init>(Lgringoxp/game/EspDraw;)V

    .line 52
    .line 53
    .line 54
    iput-object v0, p0, Lgringoxp/game/EspDraw;->b:Lgringoxp/game/ESPView;

    .line 55
    .line 56
    const/4 v2, 0x0

    .line 57
    invoke-virtual {v0, v2}, Landroid/view/View;->setFocusable(Z)V

    .line 58
    .line 59
    .line 60
    iget-object v0, p0, Lgringoxp/game/EspDraw;->b:Lgringoxp/game/ESPView;

    .line 61
    .line 62
    invoke-virtual {v0, v2}, Landroid/view/View;->setClickable(Z)V

    .line 63
    .line 64
    .line 65
    iget-object v0, p0, Lgringoxp/game/EspDraw;->b:Lgringoxp/game/ESPView;

    .line 66
    .line 67
    const/4 v3, 0x1

    .line 68
    invoke-virtual {v0, v3}, Landroid/view/View;->setEnabled(Z)V

    .line 69
    .line 70
    .line 71
    iget-object v0, p0, Lgringoxp/game/EspDraw;->b:Lgringoxp/game/ESPView;

    .line 72
    .line 73
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 74
    .line 75
    .line 76
    iget-object v0, p0, Lgringoxp/game/EspDraw;->b:Lgringoxp/game/ESPView;

    .line 77
    .line 78
    invoke-virtual {v0, v2}, Landroid/view/View;->setFilterTouchesWhenObscured(Z)V

    .line 79
    .line 80
    .line 81
    iget-object v0, p0, Lgringoxp/game/EspDraw;->a:Landroid/view/WindowManager;

    .line 82
    .line 83
    if-eqz v0, :cond_3

    .line 84
    .line 85
    iget-object v2, p0, Lgringoxp/game/EspDraw;->b:Lgringoxp/game/ESPView;

    .line 86
    .line 87
    invoke-interface {v0, v2, v1}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 88
    .line 89
    .line 90
    :cond_3
    return-void
.end method

.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public final onCreate()V
    .locals 9

    .line 1
    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    .line 2
    .line 3
    .line 4
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 5
    .line 6
    const-string v1, "ESP ativo"

    .line 7
    .line 8
    const/16 v2, 0x1a

    .line 9
    .line 10
    if-lt v0, v2, :cond_0

    .line 11
    .line 12
    invoke-static {}, Lp/s;->e()Landroid/app/NotificationChannel;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    invoke-static {v3}, Lp/s;->h(Landroid/app/NotificationChannel;)V

    .line 17
    .line 18
    .line 19
    const-string v4, "notification"

    .line 20
    .line 21
    invoke-virtual {p0, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v4

    .line 25
    check-cast v4, Landroid/app/NotificationManager;

    .line 26
    .line 27
    invoke-static {v4, v3}, Lp/s;->i(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    .line 28
    .line 29
    .line 30
    :cond_0
    if-lt v0, v2, :cond_1

    .line 31
    .line 32
    invoke-static {p0}, Lp/s;->b(Lgringoxp/game/EspDraw;)Landroid/app/Notification$Builder;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    goto :goto_0

    .line 37
    :cond_1
    new-instance v2, Landroid/app/Notification$Builder;

    .line 38
    .line 39
    invoke-direct {v2, p0}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    .line 40
    .line 41
    .line 42
    :goto_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 43
    .line 44
    .line 45
    move-result-object v3

    .line 46
    iget v3, v3, Landroid/content/pm/ApplicationInfo;->icon:I

    .line 47
    .line 48
    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    .line 49
    .line 50
    .line 51
    move-result-object v2

    .line 52
    invoke-virtual {v2, v1}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    const-string v2, "Superposici\u00f3n en ejecuci\u00f3n"

    .line 57
    .line 58
    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    const-string v2, "service"

    .line 63
    .line 64
    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setCategory(Ljava/lang/String;)Landroid/app/Notification$Builder;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    const/4 v2, 0x1

    .line 69
    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    invoke-virtual {v1}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    const/16 v3, 0x22

    .line 78
    .line 79
    if-lt v0, v3, :cond_2

    .line 80
    .line 81
    invoke-static {p0, v1}, Lp/t;->p(Lgringoxp/game/EspDraw;Landroid/app/Notification;)V

    .line 82
    .line 83
    .line 84
    goto :goto_1

    .line 85
    :cond_2
    const/16 v0, 0xc1e

    .line 86
    .line 87
    invoke-virtual {p0, v0, v1}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    .line 88
    .line 89
    .line 90
    :goto_1
    const-string v0, "window"

    .line 91
    .line 92
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    check-cast v0, Landroid/view/WindowManager;

    .line 97
    .line 98
    iput-object v0, p0, Lgringoxp/game/EspDraw;->a:Landroid/view/WindowManager;

    .line 99
    .line 100
    new-instance v0, Landroid/content/IntentFilter;

    .line 101
    .line 102
    invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V

    .line 103
    .line 104
    .line 105
    const-string v1, "gringoxp.game.ACTION_START_OVERLAY"

    .line 106
    .line 107
    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    const-string v1, "gringoxp.game.ACTION_STOP_OVERLAY"

    .line 111
    .line 112
    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    invoke-static {p0}, Lp/H9;->f(Landroid/app/Service;)Lp/H9;

    .line 116
    .line 117
    .line 118
    move-result-object v1

    .line 119
    iget-object v3, p0, Lgringoxp/game/EspDraw;->c:Lp/g1;

    .line 120
    .line 121
    iget-object v4, v1, Lp/H9;->d:Ljava/io/Serializable;

    .line 122
    .line 123
    check-cast v4, Ljava/util/HashMap;

    .line 124
    .line 125
    monitor-enter v4

    .line 126
    :try_start_0
    new-instance v5, Lp/G9;

    .line 127
    .line 128
    invoke-direct {v5, v0, v3}, Lp/G9;-><init>(Landroid/content/IntentFilter;Lp/g1;)V

    .line 129
    .line 130
    .line 131
    iget-object v6, v1, Lp/H9;->d:Ljava/io/Serializable;

    .line 132
    .line 133
    check-cast v6, Ljava/util/HashMap;

    .line 134
    .line 135
    invoke-virtual {v6, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    move-result-object v6

    .line 139
    check-cast v6, Ljava/util/ArrayList;

    .line 140
    .line 141
    if-nez v6, :cond_3

    .line 142
    .line 143
    new-instance v6, Ljava/util/ArrayList;

    .line 144
    .line 145
    invoke-direct {v6, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 146
    .line 147
    .line 148
    iget-object v7, v1, Lp/H9;->d:Ljava/io/Serializable;

    .line 149
    .line 150
    check-cast v7, Ljava/util/HashMap;

    .line 151
    .line 152
    invoke-virtual {v7, v3, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 153
    .line 154
    .line 155
    goto :goto_2

    .line 156
    :catchall_0
    move-exception v0

    .line 157
    goto :goto_4

    .line 158
    :cond_3
    :goto_2
    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 159
    .line 160
    .line 161
    const/4 v3, 0x0

    .line 162
    :goto_3
    invoke-virtual {v0}, Landroid/content/IntentFilter;->countActions()I

    .line 163
    .line 164
    .line 165
    move-result v6

    .line 166
    if-ge v3, v6, :cond_5

    .line 167
    .line 168
    invoke-virtual {v0, v3}, Landroid/content/IntentFilter;->getAction(I)Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object v6

    .line 172
    iget-object v7, v1, Lp/H9;->e:Ljava/lang/Object;

    .line 173
    .line 174
    check-cast v7, Ljava/util/HashMap;

    .line 175
    .line 176
    invoke-virtual {v7, v6}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 177
    .line 178
    .line 179
    move-result-object v7

    .line 180
    check-cast v7, Ljava/util/ArrayList;

    .line 181
    .line 182
    if-nez v7, :cond_4

    .line 183
    .line 184
    new-instance v7, Ljava/util/ArrayList;

    .line 185
    .line 186
    invoke-direct {v7, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 187
    .line 188
    .line 189
    iget-object v8, v1, Lp/H9;->e:Ljava/lang/Object;

    .line 190
    .line 191
    check-cast v8, Ljava/util/HashMap;

    .line 192
    .line 193
    invoke-virtual {v8, v6, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 194
    .line 195
    .line 196
    :cond_4
    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 197
    .line 198
    .line 199
    add-int/lit8 v3, v3, 0x1

    .line 200
    .line 201
    goto :goto_3

    .line 202
    :cond_5
    monitor-exit v4

    .line 203
    return-void

    .line 204
    :goto_4
    monitor-exit v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 205
    throw v0
.end method

.method public final onDestroy()V
    .locals 13

    .line 1
    invoke-static {p0}, Lp/H9;->f(Landroid/app/Service;)Lp/H9;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, Lgringoxp/game/EspDraw;->c:Lp/g1;

    .line 6
    .line 7
    iget-object v2, v0, Lp/H9;->d:Ljava/io/Serializable;

    .line 8
    .line 9
    check-cast v2, Ljava/util/HashMap;

    .line 10
    .line 11
    monitor-enter v2

    .line 12
    :try_start_0
    iget-object v3, v0, Lp/H9;->d:Ljava/io/Serializable;

    .line 13
    .line 14
    check-cast v3, Ljava/util/HashMap;

    .line 15
    .line 16
    invoke-virtual {v3, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v3

    .line 20
    check-cast v3, Ljava/util/ArrayList;

    .line 21
    .line 22
    const/4 v4, 0x1

    .line 23
    if-nez v3, :cond_0

    .line 24
    .line 25
    monitor-exit v2

    .line 26
    goto :goto_3

    .line 27
    :catchall_0
    move-exception v0

    .line 28
    goto :goto_4

    .line 29
    :cond_0
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 30
    .line 31
    .line 32
    move-result v5

    .line 33
    sub-int/2addr v5, v4

    .line 34
    :goto_0
    if-ltz v5, :cond_5

    .line 35
    .line 36
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v6

    .line 40
    check-cast v6, Lp/G9;

    .line 41
    .line 42
    iput-boolean v4, v6, Lp/G9;->d:Z

    .line 43
    .line 44
    const/4 v7, 0x0

    .line 45
    :goto_1
    iget-object v8, v6, Lp/G9;->a:Landroid/content/IntentFilter;

    .line 46
    .line 47
    invoke-virtual {v8}, Landroid/content/IntentFilter;->countActions()I

    .line 48
    .line 49
    .line 50
    move-result v8

    .line 51
    if-ge v7, v8, :cond_4

    .line 52
    .line 53
    iget-object v8, v6, Lp/G9;->a:Landroid/content/IntentFilter;

    .line 54
    .line 55
    invoke-virtual {v8, v7}, Landroid/content/IntentFilter;->getAction(I)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v8

    .line 59
    iget-object v9, v0, Lp/H9;->e:Ljava/lang/Object;

    .line 60
    .line 61
    check-cast v9, Ljava/util/HashMap;

    .line 62
    .line 63
    invoke-virtual {v9, v8}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v9

    .line 67
    check-cast v9, Ljava/util/ArrayList;

    .line 68
    .line 69
    if-eqz v9, :cond_3

    .line 70
    .line 71
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    .line 72
    .line 73
    .line 74
    move-result v10

    .line 75
    sub-int/2addr v10, v4

    .line 76
    :goto_2
    if-ltz v10, :cond_2

    .line 77
    .line 78
    invoke-virtual {v9, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v11

    .line 82
    check-cast v11, Lp/G9;

    .line 83
    .line 84
    iget-object v12, v11, Lp/G9;->b:Lp/g1;

    .line 85
    .line 86
    if-ne v12, v1, :cond_1

    .line 87
    .line 88
    iput-boolean v4, v11, Lp/G9;->d:Z

    .line 89
    .line 90
    invoke-virtual {v9, v10}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    :cond_1
    add-int/lit8 v10, v10, -0x1

    .line 94
    .line 95
    goto :goto_2

    .line 96
    :cond_2
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    .line 97
    .line 98
    .line 99
    move-result v9

    .line 100
    if-gtz v9, :cond_3

    .line 101
    .line 102
    iget-object v9, v0, Lp/H9;->e:Ljava/lang/Object;

    .line 103
    .line 104
    check-cast v9, Ljava/util/HashMap;

    .line 105
    .line 106
    invoke-virtual {v9, v8}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    :cond_3
    add-int/lit8 v7, v7, 0x1

    .line 110
    .line 111
    goto :goto_1

    .line 112
    :cond_4
    add-int/lit8 v5, v5, -0x1

    .line 113
    .line 114
    goto :goto_0

    .line 115
    :cond_5
    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 116
    :goto_3
    iget-object v0, p0, Lgringoxp/game/EspDraw;->a:Landroid/view/WindowManager;

    .line 117
    .line 118
    if-eqz v0, :cond_6

    .line 119
    .line 120
    iget-object v1, p0, Lgringoxp/game/EspDraw;->b:Lgringoxp/game/ESPView;

    .line 121
    .line 122
    if-eqz v1, :cond_6

    .line 123
    .line 124
    invoke-interface {v0, v1}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V

    .line 125
    .line 126
    .line 127
    const/4 v0, 0x0

    .line 128
    iput-object v0, p0, Lgringoxp/game/EspDraw;->b:Lgringoxp/game/ESPView;

    .line 129
    .line 130
    :cond_6
    invoke-virtual {p0, v4}, Landroid/app/Service;->stopForeground(I)V

    .line 131
    .line 132
    .line 133
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    .line 134
    .line 135
    .line 136
    return-void

    .line 137
    :goto_4
    :try_start_1
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 138
    throw v0
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .locals 0

    .line 1
    iget-object p1, p0, Lgringoxp/game/EspDraw;->b:Lgringoxp/game/ESPView;

    .line 2
    .line 3
    if-nez p1, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0}, Lgringoxp/game/EspDraw;->a()V

    .line 6
    .line 7
    .line 8
    :cond_0
    const/4 p1, 0x2

    .line 9
    return p1
.end method

.method public final onTaskRemoved(Landroid/content/Intent;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lgringoxp/game/EspDraw;->a:Landroid/view/WindowManager;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-object v1, p0, Lgringoxp/game/EspDraw;->b:Lgringoxp/game/ESPView;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    invoke-interface {v0, v1}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V

    .line 10
    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    iput-object v0, p0, Lgringoxp/game/EspDraw;->b:Lgringoxp/game/ESPView;

    .line 14
    .line 15
    :cond_0
    const/4 v0, 0x1

    .line 16
    invoke-virtual {p0, v0}, Landroid/app/Service;->stopForeground(I)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    .line 20
    .line 21
    .line 22
    invoke-super {p0, p1}, Landroid/app/Service;->onTaskRemoved(Landroid/content/Intent;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method
