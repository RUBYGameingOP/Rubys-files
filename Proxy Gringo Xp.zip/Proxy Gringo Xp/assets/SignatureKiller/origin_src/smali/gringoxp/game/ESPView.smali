.class public final Lgringoxp/game/ESPView;
.super Landroid/view/View;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field public static volatile n:I


# instance fields
.field public final a:Landroid/graphics/Paint;

.field public final b:Landroid/graphics/Paint;

.field public final c:Landroid/graphics/Paint;

.field public final d:Landroid/graphics/Paint;

.field public final e:Landroid/graphics/Paint;

.field public final f:Landroid/graphics/Paint;

.field public final g:Landroid/graphics/Paint;

.field public final h:Landroid/graphics/Paint;

.field public final i:Landroid/graphics/Paint;

.field public final j:Landroid/graphics/Paint;

.field public final k:Landroid/graphics/Paint;

.field public final l:Ljava/lang/Thread;

.field public m:J


# direct methods
.method public constructor <init>(Lgringoxp/game/EspDraw;)V
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    invoke-direct {p0, p1, v0, v1}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 4
    .line 5
    .line 6
    new-instance p1, Landroid/graphics/Paint;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-direct {p1, v0}, Landroid/graphics/Paint;-><init>(I)V

    .line 10
    .line 11
    .line 12
    iput-object p1, p0, Lgringoxp/game/ESPView;->i:Landroid/graphics/Paint;

    .line 13
    .line 14
    new-instance p1, Landroid/graphics/Paint;

    .line 15
    .line 16
    invoke-direct {p1, v0}, Landroid/graphics/Paint;-><init>(I)V

    .line 17
    .line 18
    .line 19
    iput-object p1, p0, Lgringoxp/game/ESPView;->j:Landroid/graphics/Paint;

    .line 20
    .line 21
    new-instance p1, Landroid/graphics/Paint;

    .line 22
    .line 23
    invoke-direct {p1, v0}, Landroid/graphics/Paint;-><init>(I)V

    .line 24
    .line 25
    .line 26
    iput-object p1, p0, Lgringoxp/game/ESPView;->k:Landroid/graphics/Paint;

    .line 27
    .line 28
    new-instance p1, Landroid/graphics/Paint;

    .line 29
    .line 30
    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    .line 31
    .line 32
    .line 33
    iput-object p1, p0, Lgringoxp/game/ESPView;->a:Landroid/graphics/Paint;

    .line 34
    .line 35
    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 36
    .line 37
    .line 38
    new-instance p1, Landroid/graphics/Paint;

    .line 39
    .line 40
    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    .line 41
    .line 42
    .line 43
    iput-object p1, p0, Lgringoxp/game/ESPView;->b:Landroid/graphics/Paint;

    .line 44
    .line 45
    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 46
    .line 47
    invoke-virtual {p1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 48
    .line 49
    .line 50
    iget-object p1, p0, Lgringoxp/game/ESPView;->b:Landroid/graphics/Paint;

    .line 51
    .line 52
    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 53
    .line 54
    .line 55
    new-instance p1, Landroid/graphics/Paint;

    .line 56
    .line 57
    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    .line 58
    .line 59
    .line 60
    iput-object p1, p0, Lgringoxp/game/ESPView;->c:Landroid/graphics/Paint;

    .line 61
    .line 62
    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    .line 63
    .line 64
    invoke-virtual {p1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 65
    .line 66
    .line 67
    iget-object p1, p0, Lgringoxp/game/ESPView;->c:Landroid/graphics/Paint;

    .line 68
    .line 69
    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 70
    .line 71
    .line 72
    new-instance p1, Landroid/graphics/Paint;

    .line 73
    .line 74
    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    .line 75
    .line 76
    .line 77
    iput-object p1, p0, Lgringoxp/game/ESPView;->d:Landroid/graphics/Paint;

    .line 78
    .line 79
    invoke-virtual {p1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 80
    .line 81
    .line 82
    iget-object p1, p0, Lgringoxp/game/ESPView;->d:Landroid/graphics/Paint;

    .line 83
    .line 84
    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 85
    .line 86
    .line 87
    iget-object p1, p0, Lgringoxp/game/ESPView;->d:Landroid/graphics/Paint;

    .line 88
    .line 89
    invoke-static {v1, v1, v1}, Landroid/graphics/Color;->rgb(III)I

    .line 90
    .line 91
    .line 92
    move-result v2

    .line 93
    invoke-virtual {p1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 94
    .line 95
    .line 96
    new-instance p1, Landroid/graphics/Paint;

    .line 97
    .line 98
    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    .line 99
    .line 100
    .line 101
    iput-object p1, p0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    .line 102
    .line 103
    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 104
    .line 105
    .line 106
    iget-object p1, p0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    .line 107
    .line 108
    sget-object v2, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    .line 109
    .line 110
    invoke-virtual {p1, v2}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 111
    .line 112
    .line 113
    new-instance p1, Landroid/graphics/Paint;

    .line 114
    .line 115
    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    .line 116
    .line 117
    .line 118
    iput-object p1, p0, Lgringoxp/game/ESPView;->f:Landroid/graphics/Paint;

    .line 119
    .line 120
    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 121
    .line 122
    .line 123
    iget-object p1, p0, Lgringoxp/game/ESPView;->f:Landroid/graphics/Paint;

    .line 124
    .line 125
    invoke-virtual {p1, v2}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 126
    .line 127
    .line 128
    new-instance p1, Landroid/graphics/Paint;

    .line 129
    .line 130
    invoke-direct {p1, v0}, Landroid/graphics/Paint;-><init>(I)V

    .line 131
    .line 132
    .line 133
    iput-object p1, p0, Lgringoxp/game/ESPView;->g:Landroid/graphics/Paint;

    .line 134
    .line 135
    const/high16 v2, -0x1000000

    .line 136
    .line 137
    invoke-virtual {p1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 138
    .line 139
    .line 140
    iget-object p1, p0, Lgringoxp/game/ESPView;->g:Landroid/graphics/Paint;

    .line 141
    .line 142
    const/16 v2, 0xa0

    .line 143
    .line 144
    invoke-virtual {p1, v2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 145
    .line 146
    .line 147
    new-instance p1, Landroid/graphics/Paint;

    .line 148
    .line 149
    invoke-direct {p1, v0}, Landroid/graphics/Paint;-><init>(I)V

    .line 150
    .line 151
    .line 152
    iput-object p1, p0, Lgringoxp/game/ESPView;->h:Landroid/graphics/Paint;

    .line 153
    .line 154
    const/high16 v0, -0x10000

    .line 155
    .line 156
    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 157
    .line 158
    .line 159
    iget-object p1, p0, Lgringoxp/game/ESPView;->h:Landroid/graphics/Paint;

    .line 160
    .line 161
    const/16 v0, 0xdc

    .line 162
    .line 163
    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 164
    .line 165
    .line 166
    invoke-virtual {p0, v1}, Landroid/view/View;->setFocusableInTouchMode(Z)V

    .line 167
    .line 168
    .line 169
    invoke-virtual {p0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 170
    .line 171
    .line 172
    new-instance p1, Ljava/lang/Thread;

    .line 173
    .line 174
    invoke-direct {p1, p0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 175
    .line 176
    .line 177
    iput-object p1, p0, Lgringoxp/game/ESPView;->l:Ljava/lang/Thread;

    .line 178
    .line 179
    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    .line 180
    .line 181
    .line 182
    return-void
.end method

.method public static setFrameIntervalMs(I)V
    .locals 1

    .line 1
    const/16 v0, 0x64

    .line 2
    .line 3
    invoke-static {p0, v0}, Ljava/lang/Math;->min(II)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    const/4 v0, 0x0

    .line 8
    invoke-static {v0, p0}, Ljava/lang/Math;->max(II)I

    .line 9
    .line 10
    .line 11
    move-result p0

    .line 12
    sput p0, Lgringoxp/game/ESPView;->n:I

    .line 13
    .line 14
    return-void
.end method

.method public static setTargetFps(I)V
    .locals 1

    .line 1
    const/16 v0, 0x90

    .line 2
    .line 3
    invoke-static {p0, v0}, Ljava/lang/Math;->min(II)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    const/16 v0, 0x1e

    .line 8
    .line 9
    invoke-static {v0, p0}, Ljava/lang/Math;->max(II)I

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    const/16 v0, 0x3e8

    .line 14
    .line 15
    div-int/2addr v0, p0

    .line 16
    const/4 p0, 0x1

    .line 17
    invoke-static {p0, v0}, Ljava/lang/Math;->max(II)I

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    sput p0, Lgringoxp/game/ESPView;->n:I

    .line 22
    .line 23
    return-void
.end method


# virtual methods
.method public final DrawCircle(Landroid/graphics/Canvas;IIIIFFFF)V
    .locals 1

    .line 1
    iget-object v0, p0, Lgringoxp/game/ESPView;->b:Landroid/graphics/Paint;

    .line 2
    .line 3
    invoke-static {p3, p4, p5}, Landroid/graphics/Color;->rgb(III)I

    .line 4
    .line 5
    .line 6
    move-result p3

    .line 7
    invoke-virtual {v0, p3}, Landroid/graphics/Paint;->setColor(I)V

    .line 8
    .line 9
    .line 10
    iget-object p3, p0, Lgringoxp/game/ESPView;->b:Landroid/graphics/Paint;

    .line 11
    .line 12
    invoke-virtual {p3, p2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 13
    .line 14
    .line 15
    iget-object p2, p0, Lgringoxp/game/ESPView;->b:Landroid/graphics/Paint;

    .line 16
    .line 17
    invoke-virtual {p2, p6}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 18
    .line 19
    .line 20
    iget-object p2, p0, Lgringoxp/game/ESPView;->b:Landroid/graphics/Paint;

    .line 21
    .line 22
    invoke-virtual {p1, p7, p8, p9, p2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method

.method public final DrawFilledCircle(Landroid/graphics/Canvas;IIIIFFF)V
    .locals 1

    .line 1
    iget-object v0, p0, Lgringoxp/game/ESPView;->c:Landroid/graphics/Paint;

    .line 2
    .line 3
    invoke-static {p3, p4, p5}, Landroid/graphics/Color;->rgb(III)I

    .line 4
    .line 5
    .line 6
    move-result p3

    .line 7
    invoke-virtual {v0, p3}, Landroid/graphics/Paint;->setColor(I)V

    .line 8
    .line 9
    .line 10
    iget-object p3, p0, Lgringoxp/game/ESPView;->c:Landroid/graphics/Paint;

    .line 11
    .line 12
    invoke-virtual {p3, p2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 13
    .line 14
    .line 15
    iget-object p2, p0, Lgringoxp/game/ESPView;->c:Landroid/graphics/Paint;

    .line 16
    .line 17
    invoke-virtual {p1, p6, p7, p8, p2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final DrawFilledRect(Landroid/graphics/Canvas;IIIIFFFF)V
    .locals 6

    .line 1
    iget-object v0, p0, Lgringoxp/game/ESPView;->c:Landroid/graphics/Paint;

    .line 2
    .line 3
    invoke-static {p3, p4, p5}, Landroid/graphics/Color;->rgb(III)I

    .line 4
    .line 5
    .line 6
    move-result p3

    .line 7
    invoke-virtual {v0, p3}, Landroid/graphics/Paint;->setColor(I)V

    .line 8
    .line 9
    .line 10
    iget-object p3, p0, Lgringoxp/game/ESPView;->c:Landroid/graphics/Paint;

    .line 11
    .line 12
    invoke-virtual {p3, p2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 13
    .line 14
    .line 15
    add-float v3, p6, p8

    .line 16
    .line 17
    add-float v4, p7, p9

    .line 18
    .line 19
    iget-object v5, p0, Lgringoxp/game/ESPView;->c:Landroid/graphics/Paint;

    .line 20
    .line 21
    move-object v0, p1

    .line 22
    move v1, p6

    .line 23
    move v2, p7

    .line 24
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 25
    .line 26
    .line 27
    return-void
.end method

.method public final DrawLine(Landroid/graphics/Canvas;IIIIFFFFF)V
    .locals 2

    .line 1
    iget-object v0, p0, Lgringoxp/game/ESPView;->a:Landroid/graphics/Paint;

    .line 2
    .line 3
    invoke-static {p3, p4, p5}, Landroid/graphics/Color;->rgb(III)I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 8
    .line 9
    .line 10
    iget-object v0, p0, Lgringoxp/game/ESPView;->a:Landroid/graphics/Paint;

    .line 11
    .line 12
    invoke-virtual {v0, p2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 13
    .line 14
    .line 15
    iget-object v0, p0, Lgringoxp/game/ESPView;->a:Landroid/graphics/Paint;

    .line 16
    .line 17
    invoke-virtual {v0, p6}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 18
    .line 19
    .line 20
    iget-object v0, p0, Lgringoxp/game/ESPView;->a:Landroid/graphics/Paint;

    .line 21
    .line 22
    move p2, p7

    .line 23
    move p3, p8

    .line 24
    move p4, p9

    .line 25
    move p5, p10

    .line 26
    move-object p6, v0

    .line 27
    invoke-virtual/range {p1 .. p6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 28
    .line 29
    .line 30
    return-void
.end method

.method public final DrawName(Landroid/graphics/Canvas;IIIILjava/lang/String;IFFF)V
    .locals 13

    move-object v0, p0

    move-object v7, p1

    move/from16 v8, p8

    move/from16 v9, p9

    .line 1
    iget-object v1, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    move v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    invoke-virtual {v1, p2, v3, v4, v5}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 2
    iget-object v1, v0, Lgringoxp/game/ESPView;->f:Landroid/graphics/Paint;

    const/16 v2, 0x9a

    const/4 v10, 0x0

    invoke-static {v2, v10, v10, v10}, Landroid/graphics/Color;->argb(IIII)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v1, 0x42f00000    # 120.0f

    sub-float v1, v8, v1

    const/high16 v2, 0x41500000    # 13.0f

    add-float v2, p10, v2

    sub-float v2, v1, v2

    const/high16 v1, 0x41900000    # 18.0f

    sub-float v1, v9, v1

    sub-float v3, v1, p10

    const/high16 v1, 0x42480000    # 50.0f

    add-float/2addr v1, v8

    const/high16 v11, 0x41700000    # 15.0f

    add-float v12, p10, v11

    add-float v4, v1, v12

    const/high16 v1, 0x41200000    # 10.0f

    add-float v5, v9, v1

    .line 3
    iget-object v6, v0, Lgringoxp/game/ESPView;->f:Landroid/graphics/Paint;

    move-object v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 4
    iget-object v1, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    const/16 v2, 0xff

    invoke-static {v2, v10, v2, v10}, Landroid/graphics/Color;->argb(IIII)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v1, 0x43070000    # 135.0f

    sub-float v1, v8, v1

    sub-float v2, v1, p10

    sub-float v1, v9, v11

    sub-float v3, v1, p10

    const/high16 v1, 0x43000000    # 128.0f

    sub-float v1, v8, v1

    add-float v4, v1, p10

    const/high16 v1, 0x40c00000    # 6.0f

    add-float v5, v9, v1

    .line 5
    iget-object v6, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    move-object v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 6
    iget-object v1, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    invoke-virtual {v1, v12}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 7
    iget-object v1, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    const/4 v2, -0x1

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 8
    iget-object v1, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    move-object/from16 v2, p6

    invoke-virtual {p1, v2, v8, v9, v1}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 9
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, " "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move/from16 v2, p7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/high16 v2, 0x43060000    # 134.0f

    sub-float v2, v8, v2

    iget-object v3, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    invoke-virtual {p1, v1, v2, v9, v3}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final DrawPlayerInfo(Landroid/graphics/Canvas;IIIILjava/lang/String;FFFZ)V
    .locals 24

    move-object/from16 v0, p0

    move-object/from16 v9, p1

    move/from16 v10, p3

    move/from16 v11, p4

    move/from16 v12, p5

    move-object/from16 v1, p6

    if-eqz v1, :cond_5

    .line 1
    invoke-virtual/range {p6 .. p6}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_5

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->getWidth()I

    move-result v2

    const/16 v3, 0x28

    if-lt v2, v3, :cond_5

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->getHeight()I

    move-result v2

    if-ge v2, v3, :cond_0

    goto/16 :goto_2

    :cond_0
    const/high16 v2, 0x41f00000    # 30.0f

    move/from16 v3, p9

    .line 2
    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v2

    const/high16 v3, 0x41100000    # 9.0f

    invoke-static {v3, v2}, Ljava/lang/Math;->max(FF)F

    move-result v2

    const v3, 0x3f266666    # 0.65f

    mul-float v13, v2, v3

    .line 3
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->getWidth()I

    move-result v3

    int-to-float v3, v3

    const/high16 v4, 0x41a00000    # 20.0f

    sub-float/2addr v3, v4

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->getWidth()I

    move-result v4

    int-to-float v4, v4

    const v5, 0x3f51eb85    # 0.82f

    mul-float/2addr v4, v5

    invoke-static {v3, v4}, Ljava/lang/Math;->min(FF)F

    move-result v3

    .line 4
    iget-object v14, v0, Lgringoxp/game/ESPView;->i:Landroid/graphics/Paint;

    invoke-virtual {v14, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 5
    sget-object v2, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v14, v2}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    const/4 v2, 0x1

    .line 6
    invoke-virtual {v14, v2}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 7
    invoke-virtual {v14, v1}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v4

    const/high16 v15, 0x40000000    # 2.0f

    mul-float v5, v13, v15

    sub-float/2addr v3, v5

    cmpl-float v4, v4, v3

    const/4 v8, 0x0

    if-lez v4, :cond_2

    .line 8
    const-string v4, "\u2026"

    invoke-virtual {v14, v4}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v6

    sub-float/2addr v3, v6

    const/4 v6, 0x0

    invoke-static {v6, v3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    const/4 v6, 0x0

    .line 9
    invoke-virtual {v14, v1, v2, v3, v6}, Landroid/graphics/Paint;->breakText(Ljava/lang/String;ZF[F)I

    move-result v2

    if-lez v2, :cond_1

    add-int/lit8 v3, v2, -0x1

    .line 10
    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    invoke-static {v3}, Ljava/lang/Character;->isHighSurrogate(C)Z

    move-result v3

    if-eqz v3, :cond_1

    add-int/lit8 v2, v2, -0x1

    .line 11
    :cond_1
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v8, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_2
    move-object v7, v1

    .line 12
    invoke-virtual {v14, v7}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v1

    add-float/2addr v1, v5

    .line 13
    invoke-virtual {v14}, Landroid/graphics/Paint;->getFontMetrics()Landroid/graphics/Paint$FontMetrics;

    move-result-object v2

    .line 14
    iget v3, v2, Landroid/graphics/Paint$FontMetrics;->descent:F

    iget v4, v2, Landroid/graphics/Paint$FontMetrics;->ascent:F

    sub-float/2addr v3, v4

    add-float/2addr v3, v13

    .line 15
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->getWidth()I

    move-result v4

    int-to-float v4, v4

    sub-float/2addr v4, v1

    const/high16 v5, 0x41000000    # 8.0f

    sub-float/2addr v4, v5

    const/high16 v6, 0x3f000000    # 0.5f

    mul-float v16, v1, v6

    sub-float v15, p7, v16

    invoke-static {v4, v15}, Ljava/lang/Math;->min(FF)F

    move-result v4

    invoke-static {v5, v4}, Ljava/lang/Math;->max(FF)F

    move-result v15

    .line 16
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->getHeight()I

    move-result v4

    int-to-float v4, v4

    sub-float/2addr v4, v3

    const/high16 v5, 0x40800000    # 4.0f

    sub-float/2addr v4, v5

    iget v8, v2, Landroid/graphics/Paint$FontMetrics;->ascent:F

    add-float v8, p8, v8

    mul-float/2addr v6, v13

    sub-float/2addr v8, v6

    invoke-static {v4, v8}, Ljava/lang/Math;->min(FF)F

    move-result v4

    invoke-static {v5, v4}, Ljava/lang/Math;->max(FF)F

    move-result v17

    add-float v6, v17, v6

    .line 17
    iget v2, v2, Landroid/graphics/Paint$FontMetrics;->ascent:F

    sub-float v8, v6, v2

    const/16 v2, 0xff

    move/from16 v4, p2

    .line 18
    invoke-static {v2, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    const/4 v6, 0x0

    invoke-static {v6, v4}, Ljava/lang/Math;->max(II)I

    move-result v5

    .line 19
    iget-object v4, v0, Lgringoxp/game/ESPView;->j:Landroid/graphics/Paint;

    const/16 v6, 0xcd

    invoke-static {v5, v6}, Ljava/lang/Math;->min(II)I

    move-result v6

    const/16 v2, 0x12

    move-object/from16 v18, v7

    const/16 v7, 0x1a

    move/from16 p7, v8

    const/16 v8, 0xd

    invoke-static {v6, v8, v2, v7}, Landroid/graphics/Color;->argb(IIII)I

    move-result v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 20
    iget-object v8, v0, Lgringoxp/game/ESPView;->k:Landroid/graphics/Paint;

    if-eqz p10, :cond_3

    const/16 v2, 0x5c

    const/16 v6, 0xff

    invoke-static {v5, v6, v2, v2}, Landroid/graphics/Color;->argb(IIII)I

    move-result v2

    goto :goto_0

    .line 21
    :cond_3
    invoke-static {v5, v10, v11, v12}, Landroid/graphics/Color;->argb(IIII)I

    move-result v2

    .line 22
    :goto_0
    invoke-virtual {v8, v2}, Landroid/graphics/Paint;->setColor(I)V

    add-float v6, v15, v1

    add-float v19, v17, v3

    const/high16 v7, 0x40a00000    # 5.0f

    const/high16 v20, 0x40a00000    # 5.0f

    move-object/from16 v1, p1

    move v2, v15

    move/from16 v3, v17

    move-object/from16 v21, v4

    move v4, v6

    move v6, v5

    move/from16 v5, v19

    move v0, v6

    const/16 v16, 0x0

    move/from16 v6, v20

    move-object/from16 v22, v18

    move/from16 v23, p7

    move/from16 v9, v16

    move-object/from16 v16, v8

    move-object/from16 v8, v21

    .line 23
    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    const/high16 v1, 0x40400000    # 3.0f

    add-float v3, v17, v1

    const/high16 v2, 0x40000000    # 2.0f

    add-float v4, v15, v2

    sub-float v5, v19, v1

    const/high16 v7, 0x3f800000    # 1.0f

    const/high16 v6, 0x3f800000    # 1.0f

    move-object/from16 v1, p1

    move v2, v15

    move-object/from16 v8, v16

    .line 24
    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 25
    const-string v1, " | "

    move-object/from16 v2, v22

    invoke-virtual {v2, v1}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v1

    if-gez v1, :cond_4

    move-object v7, v2

    goto :goto_1

    .line 26
    :cond_4
    invoke-virtual {v2, v9, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v7

    .line 27
    :goto_1
    invoke-static {v0, v10, v11, v12}, Landroid/graphics/Color;->argb(IIII)I

    move-result v3

    invoke-virtual {v14, v3}, Landroid/graphics/Paint;->setColor(I)V

    add-float/2addr v15, v13

    move-object/from16 v3, p1

    move v4, v9

    move/from16 v6, v23

    .line 28
    invoke-virtual {v3, v7, v15, v6, v14}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    if-ltz v1, :cond_5

    .line 29
    invoke-virtual {v14, v7}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v5

    .line 30
    invoke-virtual {v14, v4}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    const/16 v4, 0xbe

    .line 31
    invoke-static {v0, v4}, Ljava/lang/Math;->min(II)I

    move-result v0

    invoke-static {v0, v10, v11, v12}, Landroid/graphics/Color;->argb(IIII)I

    move-result v0

    invoke-virtual {v14, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 32
    invoke-virtual {v2, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    add-float/2addr v15, v5

    invoke-virtual {v3, v0, v15, v6, v14}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    :cond_5
    :goto_2
    return-void
.end method

.method public final DrawText(Landroid/graphics/Canvas;IIIILjava/lang/String;FFF)V
    .locals 1

    .line 1
    iget-object v0, p0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    .line 2
    .line 3
    invoke-static {p3, p4, p5}, Landroid/graphics/Color;->rgb(III)I

    .line 4
    .line 5
    .line 6
    move-result p3

    .line 7
    invoke-virtual {v0, p3}, Landroid/graphics/Paint;->setColor(I)V

    .line 8
    .line 9
    .line 10
    iget-object p3, p0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    .line 11
    .line 12
    invoke-virtual {p3, p2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p0}, Landroid/view/View;->getRight()I

    .line 16
    .line 17
    .line 18
    move-result p2

    .line 19
    const/16 p3, 0x780

    .line 20
    .line 21
    if-gt p2, p3, :cond_3

    .line 22
    .line 23
    invoke-virtual {p0}, Landroid/view/View;->getBottom()I

    .line 24
    .line 25
    .line 26
    move-result p2

    .line 27
    if-le p2, p3, :cond_0

    .line 28
    .line 29
    goto :goto_1

    .line 30
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getRight()I

    .line 31
    .line 32
    .line 33
    move-result p2

    .line 34
    if-eq p2, p3, :cond_2

    .line 35
    .line 36
    invoke-virtual {p0}, Landroid/view/View;->getBottom()I

    .line 37
    .line 38
    .line 39
    move-result p2

    .line 40
    if-ne p2, p3, :cond_1

    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_1
    iget-object p2, p0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    .line 44
    .line 45
    invoke-virtual {p2, p9}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 46
    .line 47
    .line 48
    goto :goto_2

    .line 49
    :cond_2
    :goto_0
    iget-object p2, p0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    .line 50
    .line 51
    const/high16 p3, 0x40000000    # 2.0f

    .line 52
    .line 53
    add-float/2addr p9, p3

    .line 54
    invoke-virtual {p2, p9}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 55
    .line 56
    .line 57
    goto :goto_2

    .line 58
    :cond_3
    :goto_1
    iget-object p2, p0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    .line 59
    .line 60
    const/high16 p3, 0x40800000    # 4.0f

    .line 61
    .line 62
    add-float/2addr p9, p3

    .line 63
    invoke-virtual {p2, p9}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 64
    .line 65
    .line 66
    :goto_2
    iget-object p2, p0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    .line 67
    .line 68
    invoke-virtual {p1, p6, p7, p8, p2}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 69
    .line 70
    .line 71
    return-void
.end method

.method public final DrawTextv2(Landroid/graphics/Canvas;IIIILjava/lang/String;FFF)V
    .locals 22

    move-object/from16 v0, p0

    move-object/from16 v9, p1

    move-object/from16 v1, p6

    move/from16 v10, p8

    .line 1
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getRight()I

    move-result v2

    const/high16 v11, 0x40000000    # 2.0f

    const/16 v3, 0x780

    if-gt v2, v3, :cond_3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getBottom()I

    move-result v2

    if-le v2, v3, :cond_0

    goto :goto_2

    .line 2
    :cond_0
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getRight()I

    move-result v2

    if-eq v2, v3, :cond_2

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getBottom()I

    move-result v2

    if-ne v2, v3, :cond_1

    goto :goto_0

    :cond_1
    move/from16 v12, p9

    goto :goto_3

    :cond_2
    :goto_0
    add-float v2, p9, v11

    :goto_1
    move v12, v2

    goto :goto_3

    :cond_3
    :goto_2
    const/high16 v2, 0x40800000    # 4.0f

    add-float v2, p9, v2

    goto :goto_1

    .line 3
    :goto_3
    iget-object v2, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    invoke-virtual {v2, v12}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 4
    const-string v2, "["

    invoke-virtual {v1, v2}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v2

    add-int/lit8 v3, v2, 0x1

    .line 5
    const-string v4, "]"

    invoke-virtual {v1, v4, v3}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v4

    const/4 v13, 0x1

    if-ltz v2, :cond_5

    if-le v4, v2, :cond_5

    const/4 v5, 0x0

    .line 6
    invoke-virtual {v1, v5, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    .line 7
    invoke-virtual {v1, v3, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    add-int/2addr v4, v13

    .line 8
    invoke-virtual {v1, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 9
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_4

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " "

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :goto_4
    move-object v14, v1

    :goto_5
    move-object v15, v3

    goto :goto_6

    :cond_4
    move-object v14, v2

    goto :goto_5

    .line 10
    :cond_5
    const-string v3, ""

    goto :goto_4

    :goto_6
    iget-object v1, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    invoke-virtual {v1, v14}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v16

    const/high16 v1, 0x3f400000    # 0.75f

    mul-float v8, v12, v1

    .line 11
    iget-object v1, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    invoke-virtual {v1, v8}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 12
    invoke-virtual {v15}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_6

    move/from16 v17, v2

    goto :goto_7

    :cond_6
    iget-object v1, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    invoke-virtual {v1, v15}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v1

    move/from16 v17, v1

    .line 13
    :goto_7
    iget-object v1, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    invoke-virtual {v1}, Landroid/graphics/Paint;->getFontMetrics()Landroid/graphics/Paint$FontMetrics;

    move-result-object v1

    .line 14
    invoke-virtual {v15}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    const/high16 v4, 0x41400000    # 12.0f

    const/high16 v18, 0x41000000    # 8.0f

    if-eqz v3, :cond_7

    goto :goto_8

    :cond_7
    add-float v2, v17, v4

    add-float v2, v2, v18

    :goto_8
    add-float v2, v16, v2

    div-float v3, v2, v11

    sub-float v7, p7, v3

    sub-float v3, v7, v4

    .line 15
    iget v5, v1, Landroid/graphics/Paint$FontMetrics;->ascent:F

    add-float/2addr v5, v10

    const/high16 v19, 0x40c00000    # 6.0f

    sub-float v5, v5, v19

    add-float/2addr v2, v7

    add-float/2addr v4, v2

    iget v1, v1, Landroid/graphics/Paint$FontMetrics;->descent:F

    add-float/2addr v1, v10

    add-float v6, v1, v19

    iget-object v2, v0, Lgringoxp/game/ESPView;->g:Landroid/graphics/Paint;

    const/high16 v20, 0x40400000    # 3.0f

    move-object/from16 v1, p1

    move-object/from16 v21, v2

    move v2, v3

    move v3, v5

    move v5, v6

    move/from16 v6, v20

    move v11, v7

    move/from16 v7, v20

    move/from16 v20, v8

    move-object/from16 v8, v21

    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 16
    iget-object v1, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    invoke-virtual {v1, v12}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 17
    iget-object v1, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    invoke-static/range {p3 .. p5}, Landroid/graphics/Color;->rgb(III)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 18
    iget-object v1, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    move/from16 v2, p2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 19
    iget-object v1, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    invoke-virtual {v1, v13}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 20
    iget-object v1, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 21
    iget-object v1, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    invoke-virtual {v9, v14, v11, v10, v1}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 22
    invoke-virtual {v15}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_8

    add-float v7, v11, v16

    add-float v7, v7, v18

    add-float v7, v7, v18

    const v1, 0x3f59999a    # 0.85f

    mul-float v8, v20, v1

    .line 23
    iget-object v1, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    invoke-virtual {v1, v8}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 24
    iget-object v1, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    invoke-virtual {v1}, Landroid/graphics/Paint;->getFontMetrics()Landroid/graphics/Paint$FontMetrics;

    move-result-object v1

    .line 25
    iget v2, v1, Landroid/graphics/Paint$FontMetrics;->descent:F

    iget v1, v1, Landroid/graphics/Paint$FontMetrics;->ascent:F

    sub-float/2addr v2, v1

    const v3, 0x3f933333    # 1.15f

    mul-float/2addr v2, v3

    add-float/2addr v1, v10

    const/high16 v3, 0x40400000    # 3.0f

    sub-float/2addr v1, v3

    add-float v17, v7, v17

    add-float v17, v17, v18

    add-float/2addr v2, v1

    add-float v2, v2, v19

    .line 26
    iget-object v3, v0, Lgringoxp/game/ESPView;->h:Landroid/graphics/Paint;

    move-object/from16 p2, p1

    move/from16 p3, v7

    move/from16 p4, v1

    move/from16 p5, v17

    move/from16 p6, v2

    move-object/from16 p7, v3

    invoke-virtual/range {p2 .. p7}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 27
    iget-object v3, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    const/4 v4, -0x1

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 28
    iget-object v3, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    add-float/2addr v1, v2

    const/high16 v2, 0x3f000000    # 0.5f

    mul-float/2addr v1, v2

    .line 29
    iget-object v3, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    .line 30
    invoke-virtual {v3}, Landroid/graphics/Paint;->descent()F

    move-result v3

    iget-object v4, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    invoke-virtual {v4}, Landroid/graphics/Paint;->ascent()F

    move-result v4

    add-float/2addr v4, v3

    const/high16 v3, 0x40000000    # 2.0f

    div-float/2addr v4, v3

    sub-float/2addr v1, v4

    add-float v7, v7, v17

    mul-float/2addr v7, v2

    .line 31
    iget-object v2, v0, Lgringoxp/game/ESPView;->e:Landroid/graphics/Paint;

    invoke-virtual {v9, v15, v7, v1, v2}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    :cond_8
    return-void
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 8

    .line 1
    if-eqz p1, :cond_1

    .line 2
    .line 3
    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_1

    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    sget-object v1, Landroid/graphics/PorterDuff$Mode;->CLEAR:Landroid/graphics/PorterDuff$Mode;

    .line 11
    .line 12
    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->drawColor(ILandroid/graphics/PorterDuff$Mode;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 24
    .line 25
    .line 26
    move-result-wide v2

    .line 27
    iget-wide v4, p0, Lgringoxp/game/ESPView;->m:J

    .line 28
    .line 29
    sub-long v4, v2, v4

    .line 30
    .line 31
    const-wide/16 v6, 0x7d0

    .line 32
    .line 33
    cmp-long v4, v4, v6

    .line 34
    .line 35
    if-ltz v4, :cond_0

    .line 36
    .line 37
    iput-wide v2, p0, Lgringoxp/game/ESPView;->m:J

    .line 38
    .line 39
    :cond_0
    invoke-static {p0, p1, v0, v1}, Lgringoxp/game/b;->PxbftKZXivSr(Lgringoxp/game/ESPView;Landroid/graphics/Canvas;II)V

    .line 40
    .line 41
    .line 42
    :cond_1
    return-void
.end method

.method public final run()V
    .locals 6

    .line 1
    const/4 v0, -0x4

    .line 2
    invoke-static {v0}, Landroid/os/Process;->setThreadPriority(I)V

    .line 3
    .line 4
    .line 5
    :goto_0
    iget-object v0, p0, Lgringoxp/game/ESPView;->l:Ljava/lang/Thread;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Thread;->isAlive()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    iget-object v0, p0, Lgringoxp/game/ESPView;->l:Ljava/lang/Thread;

    .line 14
    .line 15
    invoke-virtual {v0}, Ljava/lang/Thread;->isInterrupted()Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_1

    .line 20
    .line 21
    :try_start_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 22
    .line 23
    .line 24
    move-result-wide v0

    .line 25
    invoke-virtual {p0}, Landroid/view/View;->postInvalidateOnAnimation()V

    .line 26
    .line 27
    .line 28
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 29
    .line 30
    .line 31
    move-result-wide v2

    .line 32
    sub-long/2addr v2, v0

    .line 33
    sget v0, Lgringoxp/game/ESPView;->n:I

    .line 34
    .line 35
    if-gtz v0, :cond_0

    .line 36
    .line 37
    const-wide/16 v0, 0x8

    .line 38
    .line 39
    goto :goto_1

    .line 40
    :cond_0
    sget v0, Lgringoxp/game/ESPView;->n:I

    .line 41
    .line 42
    int-to-long v0, v0

    .line 43
    :goto_1
    const-wide/16 v4, 0x1

    .line 44
    .line 45
    sub-long/2addr v0, v2

    .line 46
    invoke-static {v4, v5, v0, v1}, Ljava/lang/Math;->max(JJ)J

    .line 47
    .line 48
    .line 49
    move-result-wide v0

    .line 50
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 51
    .line 52
    .line 53
    goto :goto_0

    .line 54
    :catch_0
    move-exception v0

    .line 55
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    goto :goto_0

    .line 59
    :cond_1
    return-void
.end method
